# بستهٔ کامل ممیزی MP — ۲۰۲۶‑۱۱‑۲۰ (بازنگریِ ۲۰۲۶‑۱۱‑۲۱: +F‑28/F‑29 +ruff)

این ZIP **همه‌چیز** را یکجا دارد: هر دو سند اصلی، فهرست مشکلات، بریف اجرایی،
همهٔ اسکریپت‌های هارنس، و همهٔ فایل‌های شاهد خام.

## چرا این بسته

تا یک ممیزیِ دیگر بتواند **بدون دسترسی به جلسهٔ قبلی** هر عدد را بازآزمایی کند:
فرمان‌ها در `§۱۰` پروندهٔ شواهد هست، خروجی‌های خام در `evidence/`، و hash هر فایل
در `MANIFEST.sha256`.

## آنچه داخل است

| مسیر | محتوا |
|---|---|
| `reports/MP-EVIDENCE-DOSSIER-2026-11-20.md` | **پروندهٔ شواهد** — **۵۰** اجرای ثبت‌شده (T‑01…T‑50)، نتایج خام هر تست، **۵ یافتهٔ جدید** (F‑25…F‑29)، **۱۳ تصحیح** بر گزارش اصلی، manifest با SHA‑256، منابع کامل، ماتریس ردیابی، بازتولید قدم‌به‌قدم |
| `reports/MP-FINAL-AUDIT-REPORT-2026-11-20.md` | **گزارش نقص** — **۲۹** یافته (F‑01…F‑29) با زنجیرهٔ علّی `file:line`، ۲۷ خاصیت سالمِ تأییدشده، ۱۲ یافتهٔ کاذبِ رد‌شده، **۲۷ ردیف** نقشهٔ رفع با شاهد پذیرش |
| `reports/MP-PROBLEMS-2026-11-20.md` | فهرست یکپارچهٔ ۶۳ مشکل برای کپی/پیست به AI مجری |
| `reports/MP-AGENT-BRIEF.md` | بریف اجرایی v2.1 — ۲۷ بستهٔ کاری (WP‑00…WP‑26) + پیوست E |
| `reports/MP-BUILDER-PROMPT-2026-11-21.md` | **پرامپتِ نشستِ بیلدر** — متنِ کپی‌شدنی برای اجرای همهٔ ۲۷ یافته: ۵ فازِ وابستگی‌محور، گیتِ عددیِ هر اصلاح، فهرست تله‌ها، قراردادِ خروجیِ هر PR، و تعریفِ «انجام شد» |
| `harness/*.py` | اسکریپت‌های پراب: `serve_backend.py`, `serve_plain.py`, `harness_common.py`, `probe_contract.py`, `probe_invalid_authed.py`, `probe_load.py`, `probe_live_security.py`, `probe_otp_limits.py`, `probe_concurrency.py`, `repro_rbac_systemerror.py`, `bench_logging.py`, `scan_ui_wiring.py` |
| `harness/semgrep-mp.yml` | **۱۷ قاعدهٔ اختصاصی Semgrep** (آفلاین) — آمادهٔ commit در CI |
| `harness/eslint-studio.flat.mjs` | flat config ‏ESLint 9 — آمادهٔ commit در استودیو |
| `harness/ruff-recommended.toml` | **پیکربندی پیشنهادی ruff** — ۴۳۰ یافته در برابر **۰** با پیکربندی فعلی و ۱۱٬۷۷۸ با `--select ALL`؛ با دلیلِ فارسی برای هر `ignore` و per-file-ignores برای tests/scripts/migrations. آمادهٔ جایگزینی در `[tool.ruff]` بک‌اند |
| `evidence/*.json,*.xml,*.txt,*.jsonl` | **۴۴ فایل شاهد خام** — از `backend-coverage.xml` تا `pool-events.jsonl`، `contract-matrix-raw.json` و چهار خروجی ruff (`ruff-recommended-findings.txt` با ۴۳۰ ردیف) |
| `MANIFEST.sha256` | hash هر فایل داخل بسته |

## سه نکتهٔ مهم پیش از خواندن

0. **دو باگِ تازه (F‑28 و F‑29) با ruff پیدا شدند** — `date.today()` با UTC در برابر
   `Asia/Tehran` در nutrition و axis_assessment، و `logging.error` بدون traceback در `app/sms.py`.
   جزئیات و اثباتِ مرز: پروندهٔ شواهد `§۴‑۴` و `§۴‑۵`.
1. **اگر عددی در گزارش با پروندهٔ شواهد تفاوت داشت، پروندهٔ شواهد معتبر است**؛
   **سیزده** تصحیحِ وارد‌شده در `§۵` همان پرونده فهرست شده‌اند.
2. در `evidence/live-security-verdicts.json` مقدار `"status": "PASS"` یعنی
   «آزمون اجرا شد و پاسخ قطعی داد» — **نه** «سالم». در مورد T2 پاسخ قطعی این بود که
   **فرضیه رد شد** (همان F‑01).
3. دو فایل شاهد عمداً نگه داشته شده‌اند با اینکه **نادرس‌نتیجه**اند:
   `evidence/contract-invalid-findings.json` (پاس نخست با توکن باطل‌شده) و
   `evidence/mutmut-manual-transfer-policy.json` (بر پایهٔ خروجی اشتباه mutmut).
   معتبرِ جایگزین آن‌ها: `contract-invalid-authed.json` و `mutmut-verified.json`.

## مهم‌ترین اعداد در یک نگاه

| کمیت | مقدار |
|---|---|
| یافته‌ها | **۲۹** — ۳ Critical، ۶ High، **۱۰** Medium، **۱۰** Low/Info |
| خاصیت‌های سالمِ تأییدشده با اجرا | ۲۷ |
| یافتهٔ کاذبِ خودم که با اجرا رد شد | ۱۲ + ۱ نقص روش‌شناختیِ اصلاح‌شده + **۱ تصحیح تازه** (ruff `S608` روی F‑22 fire نمی‌شود) |
| حوزه‌های BLOCKED | ۱۱ |
| تست بک‌اند | ۱۰۹۵ پاس / ۲ skip / ۴۶۱٫۸۲ ثانیه · پوشش **۸۳٫۷۳٪** (مستند: ۹۴٫۲۸٪) |
| تست استودیو | ۲۸۲ پاس / ۹ skip · `tsc --noEmit` تمیز |
| ماتریس مجوز | ۱٬۱۴۱ سلول · **۰ × 5xx** · ۶۰۲ سلول مخالف قرارداد |
| پاس ورودی خصمانهٔ معتبر | ۸۷۲ سلول · **۰ × 5xx** · **۰ نشت stack trace** · ۴۸ × ۲۰۰ روی شناسهٔ غیرمجزا |
| بار ۸۰ کلاینت همزمان | ۹۴٫۷ rps · p99 ‏۳۰٬۰۲۷ ms · بازیابی ۴۳٫۶۳ s · لاگ ۳۷ MB از **یک** خطا |
| آزمون جهش (راستی‌آزمایی‌شده) | ۲۶/۴۵ کشته = **۵۷٫۸٪** |
| ممیزی ایستا با ruff | پیکربندی فعلی پروژه ⇒ **۰** یافته؛ `--select ALL` ⇒ ۱۱٬۷۷۸/۱۰۸ قاعده؛ پیشنهادی ⇒ **۴۳۰/۵۲ قاعده** (۴۷ قابل‌رفع خودکار) |
| مخزن `MP` | **بدون هیچ تغییر** — HEAD `662ff88`، `git status --porcelain` روی فایل‌های track‌شده = ۰ (تنها artefactهای اجراییِ untracked در کپیِ `/tmp/run/MP`) |

## تأیید یکپارچگی

```bash
unzip MP-AUDIT-BUNDLE-2026-11-20.zip && cd MP-AUDIT-BUNDLE-2026-11-20
sha256sum -c MANIFEST.sha256 --quiet && echo "OK — همهٔ فایل‌ها سالم‌اند"
```

## بازتولید از صفر

`reports/MP-EVIDENCE-DOSSIER-2026-11-20.md` → `§۱۰` (۱۰ گام، از کپی مخزن تا هر عدد).

---
*پنجرهٔ اجرا: ۲۰۲۶‑۱۱‑۲۰ ۲۲:۱۰ تا ۲۰۲۶‑۱۱‑۲۱ ۰۸:۱۰ UTC · داده‌ها کاملاً مصنوعی ·
مخزن میزبان: `yousefghorbanian98-create/Chat2DB` شاخهٔ `arena/2cde32d6-chat2db`*
