#!/usr/bin/env node
/** Optional isolated kit smoke. Requires npm ci IN THE KIT and separate browser tooling.
 * KIT_BROWSER_TOOLS=/absolute/path/to/tooling node scripts/browser_smoke.mjs
 * Tooling used for this artifact: playwright-core 1.65.1, @sparticuz/chromium 158.0.0,
 * esbuild 0.28.2. No MP checkout, external API, production data, or server required.
 * The report is self-check evidence, NOT an independent reviewer or product QA.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const tools = process.env.KIT_BROWSER_TOOLS || resolve(root, '../../.cache/ui-motion-kit-work/tooling');
const out = process.env.KIT_BROWSER_OUT || resolve(tools, '../browser-output');
const require = createRequire(join(tools, 'package.json'));
const { chromium } = require('playwright-core');
const { build } = require('esbuild');
const sparticuz = (await import(pathToFileURL(require.resolve('@sparticuz/chromium')).href)).default;
const libs = join(tools, 'chromium-libs/lib');
if (existsSync(libs)) process.env.LD_LIBRARY_PATH = libs + ':' + (process.env.LD_LIBRARY_PATH || '');
mkdirSync(out, { recursive: true });
const bindings = {};
for (const name of ['preview/index.html', 'preview/preview.js', 'preview/preview.css', 'preview/template.html', 'preview/receipt-states.json', 'TOKENS.json', 'recipes/StudioRecipes.tsx', 'recipes/motion-policy.ts', 'recipes/live-preference.ts', 'assets/mp-motion.css', 'tests/browser-harness.tsx', 'scripts/browser_smoke.mjs', 'package.json', 'package-lock.json', 'START_HERE_BUILDER.fa.md', 'OPEN_SOURCE_TOOLS.fa.md', 'DESIGN_WORKFLOW.fa.md', 'references/OPEN_SOURCE_TOOLS.json']) {
  bindings[name] = createHash('sha256').update(readFileSync(join(root, name))).digest('hex');
}
const toolsLock = JSON.parse(readFileSync(join(tools, 'package-lock.json')));
const toolIdentities = {};
for (const name of ['playwright-core', '@sparticuz/chromium', 'esbuild']) {
  const entry = toolsLock.packages['node_modules/' + name];
  toolIdentities[name] = { version: entry.version, integrity: entry.integrity, license: entry.license };
}
const report = {
  kit_version: '1.1.0', scope: 'SYNTHETIC_KIT_BROWSER_SMOKE_ONLY_NOT_MP_QA_OR_INDEPENDENT_REVIEW',
  status: 'NOT_RUN', runtime_clock_utc: new Date().toISOString(), tools: toolIdentities,
  browser: null, external_network_attempts: [], page_errors: [], console_errors: [], cases: [], bindings,
  not_run: ['MP build/backend/CI', 'authentication and authorization', 'real receipt, bank, persistence, QR', 'PWA install/update/offline/service worker', 'physical Android/iOS', 'Firefox/WebKit/Safari', 'screen reader', 'browser zoom and human accessibility audit', 'performance budget on target device', 'independent review and human approval'],
};
let browser;
function attach(page) {
  page.on('pageerror', error => report.page_errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') report.console_errors.push(message.text()); });
}
async function isolated(options = {}) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'no-preference', ...options });
  await context.route(/^https?:/, route => { report.external_network_attempts.push(route.request().url()); return route.abort(); });
  await context.setOffline(true);
  return context;
}
async function checked(name, run) {
  try { const detail = await run(); report.cases.push({ name, status: 'PASS', ...(detail ? { detail } : {}) }); }
  catch (error) { report.cases.push({ name, status: 'FAIL', error: error.message }); throw error; }
}
async function reducedState(page, value) {
  await page.waitForFunction(expected => document.documentElement.dataset.reduced === String(expected), value);
}
const url = pathToFileURL(join(root, 'preview/index.html')).href;
try {
  const args = sparticuz.args.filter(a => !a.startsWith('--disable-web-security') && !a.startsWith('--allow-running-insecure-content'));
  browser = await chromium.launch({ headless: true, executablePath: process.env.KIT_CHROMIUM_EXECUTABLE || await sparticuz.executablePath(), args });
  report.browser = browser.version();
  report.launch = { sandbox: false, headless: true, web_security_disabled: false, note: 'serverless test binary; no external HTTP/S allowed; not a security test' };
  const context = await isolated();
  const page = await context.newPage(); attach(page);
  await page.goto(url); await page.evaluate(() => document.fonts.ready);
  await checked('offline self-contained fa/RTL document and embedded font loads', async () => {
    assert.equal(await page.locator('html').getAttribute('lang'), 'fa');
    assert.equal(await page.locator('html').getAttribute('dir'), 'rtl');
    assert.equal(await page.locator('#view-title').textContent(), 'فضای امروزِ عضو');
    const fonts = await page.evaluate(() => [...document.fonts].map(f => ({ status: f.status, family: f.family })));
    assert.ok(fonts.some(f => f.status === 'loaded' && f.family.includes('Vazirmatn Kit')));
    return { loaded_font_faces: fonts.filter(f => f.status === 'loaded').length };
  });
  await checked('selected tool decisions and primary builder entry are explicit, not installed integrations', async () => {
    assert.equal(await page.locator('#toolchain [data-tool]').count(), 4);
    assert.match(await page.locator('#toolchain [data-tool="style-dictionary"]').innerText(), /defer/);
    assert.match(await page.locator('#toolchain [data-tool="storybook"]').innerText(), /اختیاری/);
    assert.equal(await page.locator('#builder-start-link').getAttribute('href'), '../START_HERE_BUILDER.fa.md');
  });
  for (const width of [320, 390, 1440]) {
    await checked('RTL viewport and action targets at ' + width + ' CSS px', async () => {
      await page.setViewportSize({ width, height: 1000 });
      const geometry = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > innerWidth,
        undersized: [...document.querySelectorAll('a.button,button,select,.rail-nav a,.file-links a,.motion-control label')].filter(el => { const r = el.getBoundingClientRect(); return r.width < 44 || r.height < 44; }).map(el => el.id || el.textContent.trim()),
      }));
      assert.equal(geometry.overflow, false); assert.deepEqual(geometry.undersized, []);
      if (width !== 320) await page.screenshot({ path: join(out, 'preview-' + width + '.png'), fullPage: true });
      return geometry;
    });
  }
  await checked('12 synthetic member/staff state combinations stay explicit', async () => {
    for (const mode of ['staff', 'member']) {
      await page.locator('[data-mode="' + mode + '"]').click();
      for (const state of ['ready', 'loading', 'empty', 'error', 'unknown', 'offline']) {
        await page.locator('#view-state').selectOption(state);
        assert.ok((await page.locator('#view-content').innerText()).length > 20);
        assert.equal(await page.locator('#view-content').getAttribute('aria-busy'), String(state === 'loading'));
      }
    }
  });
  await checked('7 receipt states equal display-only policy fixtures; no pending approval', async () => {
    const states = JSON.parse(readFileSync(join(root, 'preview/receipt-states.json')));
    for (const phase of ['pending_review', 'not_sent', 'submitting', 'approved', 'rejected', 'unknown', 'offline']) {
      await page.locator('#receipt-state').selectOption(phase);
      assert.equal(await page.locator('#receipt-title').textContent(), states[phase].title);
      assert.equal(await page.locator('#receipt-detail').textContent(), states[phase].detail);
    }
    await page.locator('#receipt-state').selectOption('pending_review');
    assert.match(await page.locator('#receipt-detail').textContent(), /به معنی تأیید/);
    assert.equal(await page.locator('#receipt-panel').getAttribute('aria-live'), 'polite');
    assert.equal(await page.locator('#receipt-panel').evaluate(el => el.getAnimations({ subtree: true }).length), 0);
  });
  await checked('list preserves existing node and focused action with a bounded short example', async () => {
    const old = await page.locator('#demo-list [data-key="1"]').elementHandle();
    await page.locator('#add-item').click();
    assert.equal(await old.evaluate(el => el.isConnected), true);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'add-item');
    for (let i = 0; i < 8; i++) await page.locator('#add-item').click();
    assert.equal(await page.locator('#demo-list li').count(), 8);
    assert.match(await page.locator('#list-status').textContent(), /سقف/);
  });
  await checked('live reduced-motion cancels an active Web Animation', async () => {
    await page.locator('#reduce-motion').uncheck();
    await page.locator('#replay-panel').click();
    assert.ok(await page.locator('#view-content').evaluate(el => el.getAnimations().some(a => a.playState === 'running')));
    await page.emulateMedia({ reducedMotion: 'reduce' }); await reducedState(page, true);
    assert.equal(await page.locator('#view-content').evaluate(el => el.getAnimations().filter(a => a.playState === 'running').length), 0);
    assert.equal(await page.locator('#reduce-motion').isDisabled(), true);
    assert.equal(await page.locator('#replay-panel').evaluate(el => getComputedStyle(el).transitionDuration), '0s');
    await page.emulateMedia({ reducedMotion: 'no-preference' }); await reducedState(page, false);
  });
  await checked('manual reduction survives system changes and cannot override system reduction', async () => {
    await page.locator('#reduce-motion').check(); await reducedState(page, true);
    await page.emulateMedia({ reducedMotion: 'reduce' });
    // matchMedia dispatch is asynchronous even when the manual flag was already true.
    await page.waitForFunction(() => document.getElementById('reduce-motion').disabled);
    assert.equal(await page.locator('#reduce-motion').isDisabled(), true);
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.waitForFunction(() => !document.getElementById('reduce-motion').disabled);
    assert.equal(await page.locator('#reduce-motion').isChecked(), true);
    await page.locator('#reduce-motion').uncheck(); await reducedState(page, false);
  });
  await context.close();
  await checked('keyboard first stop is the visible skip link with focus outline', async () => {
    const c = await isolated(); const p = await c.newPage(); attach(p); await p.goto(url);
    await p.keyboard.press('Tab');
    const focus = await p.evaluate(() => ({ skip: document.activeElement.classList.contains('skip'), outline: getComputedStyle(document.activeElement).outlineWidth, top: document.activeElement.getBoundingClientRect().top }));
    assert.equal(focus.skip, true); assert.equal(focus.outline, '2px'); assert.ok(focus.top >= 0); await c.close();
  });
  await checked('static content remains readable with JavaScript disabled', async () => {
    const c = await isolated({ javaScriptEnabled: false }); const p = await c.newPage(); attach(p); await p.goto(url);
    assert.ok((await p.locator('main').innerText()).length > 1000);
    assert.match(await p.locator('noscript').innerText(), /خاموش/); await c.close();
  });
  await checked('unsupported matchMedia conservatively reduces without breaking the controls', async () => {
    const c = await isolated(); await c.addInitScript(() => Object.defineProperty(window, 'matchMedia', { value: undefined }));
    const p = await c.newPage(); attach(p); await p.goto(url); await reducedState(p, true);
    assert.match(await p.locator('#motion-status').textContent(), /نامعلوم/);
    await p.locator('[data-mode="staff"]').click(); assert.match(await p.locator('#view-title').textContent(), /کارکنان/); await c.close();
  });
  await checked('system reduction is honored on first load', async () => {
    const c = await isolated({ reducedMotion: 'reduce' }); const p = await c.newPage(); attach(p); await p.goto(url); await reducedState(p, true);
    assert.equal(await p.locator('#reduce-motion').isDisabled(), true); await c.close();
  });

  // A bundled, synthetic React fixture, not a second product app or router.
  const bundled = await build({ entryPoints: [join(root, 'tests/browser-harness.tsx')], bundle: true, write: false, minify: true, platform: 'browser', target: 'es2022', jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, nodePaths: [join(root, 'node_modules')] });
  const fixture = join(out, 'recipe-fixture.html');
  writeFileSync(fixture, '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><style>' + readFileSync(join(root, 'assets/mp-motion.css'), 'utf8') + '</style><div id="root"></div><script>' + bundled.outputFiles[0].text.replaceAll('</script', '<\\/script') + '</script></html>');
  const rc = await isolated(); const rp = await rc.newPage(); attach(rp);
  await rp.goto(pathToFileURL(fixture).href);
  await rp.locator('#draft').waitFor();
  await checked('actual React 18 hook re-renders false -> true -> false without reloading', async () => {
    assert.equal(await rp.locator('#preference').textContent(), 'false');
    await rp.locator('#draft').fill('SYNTHETIC_PRESERVED_DRAFT');
    await rp.locator('#draft').focus();
    await rp.emulateMedia({ reducedMotion: 'reduce' });
    await rp.waitForFunction(() => document.getElementById('preference').textContent === 'true');
    assert.equal(await rp.locator('.mp-kit-reduced').count(), 2);
    assert.equal(await rp.evaluate(() => document.activeElement.id), 'draft');
    assert.equal(await rp.locator('.mp-kit-reduced').first().evaluate(el => getComputedStyle(el).transform), 'none');
    await rp.emulateMedia({ reducedMotion: 'no-preference' });
    await rp.waitForFunction(() => document.getElementById('preference').textContent === 'false');
    assert.equal(await rp.locator('#draft').inputValue(), 'SYNTHETIC_PRESERVED_DRAFT');
  });
  await checked('React list update retains input and focused button', async () => {
    await rp.locator('#add').click();
    assert.equal(await rp.locator('.ant-list-item').count(), 3);
    assert.equal(await rp.locator('#draft').inputValue(), 'SYNTHETIC_PRESERVED_DRAFT');
    assert.equal(await rp.evaluate(() => document.activeElement.id), 'add');
  });
  await checked('display-only access boundary removes the synthetic child after denial', async () => {
    assert.equal(await rp.locator('#private-fixture').count(), 1);
    await rp.locator('#deny').click(); assert.equal(await rp.locator('#private-fixture').count(), 0);
    assert.equal(await rp.locator('body').getByText('دسترسی معتبر نیست').count(), 1);
  });
  await rc.close();
  await checked('no HTTP/S request attempts or browser error messages in all executed kit cases', async () => {
    assert.deepEqual(report.external_network_attempts, []); assert.deepEqual(report.page_errors, []); assert.deepEqual(report.console_errors, []);
  });
  report.status = 'KIT_BROWSER_SMOKE_PASS_NOT_PRODUCT_QA';
} catch (error) {
  report.status = 'KIT_BROWSER_SMOKE_FAILED'; report.error = error.message.replaceAll(root, '<KIT>'); process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  writeFileSync(join(root, 'references/BROWSER_CHECK.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, browser: report.browser, passed: report.cases.filter(c => c.status === 'PASS').length, failed: report.cases.filter(c => c.status === 'FAIL').length, error: report.error }, null, 2));
}
