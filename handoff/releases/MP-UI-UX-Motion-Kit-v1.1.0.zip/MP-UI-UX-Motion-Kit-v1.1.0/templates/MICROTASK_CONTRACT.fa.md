# قالب قرارداد یک GAP کوچک — تکمیل و تصویب لازم است

**وضعیت اولیه: PROPOSED؛ نه مجوز ویرایش، نه AGENT-READY.** [فایل شروع](../START_HERE_BUILDER.fa.md) و پروتکل جاری MP بر این قالب مقدم‌اند.

## هویت و محدوده

- parent canonical / عنوان / AC اصلی: `NOT_LINKED`؛ [SOURCE_PLAN](../references/SOURCE_PLAN.fa.md)
- زیرکار و یک نتیجهٔ قابل‌آزمون: `PROPOSED`
- checkout/ref/base/head و dirty fingerprint پالایش‌شده: `NOT_RECORDED`
- source/contract/owner approval همان خروجی: `MISSING`
- allowlist دقیق؛ هر مسیر اضافه نیازمند disposition/مجوز تازه: `NOT_APPROVED`
- non-goals: role/grant/DB/auth/API/payment/session/offline/SW/router/manifest/native/Electron/CI، UI/helper موازی و نصب dependency، مگر قرارداد مستقل صریح.
- D مؤثر با مصوبهٔ جاری؛ بقیهٔ Dها لازم نیست همگی بسته شوند: `UNKNOWN`
- baseline دستور/نسخه/exit/count واقعی؛ خطاهای قبلی جدا: `NOT_RUN`
- rollback محلی مجاز و حفظ dirty/private؛ بدون reset/clean: `NOT_APPROVED`

## معیارهای پیشنهادی برای GAP reduced-motion، فقط اگر inventory تأییدش کند

1. reduced/unknown/unsupported/SSR محافظه‌کارانه؛ متن/کنترل پنهان یا معطل نشود.
2. تغییر live false → true → false بدون reload، cleanup subscription و حفظ input/focus.
3. reuse helper موجود؛ بدون provider/import موازی، تغییر key فرم یا exit retention حساس.
4. تست‌های baseline و منفی، timing/token parity و RTL/keyboard طبق اثر واقعی؛ threshold/discovery تضعیف نشود.
5. بدون تغییر خارج allowlist؛ بدون ادعای authorization/server/receipt/persistence/PWA QA از تست UI.

این فهرست AC محصول را جایگزین نمی‌کند؛ برای GAP دیگری باید با منبع همان parent بازنویسی/مصوب شود.

## نه حوزهٔ مستقل

| حوزه | شرط آغاز و مالک | فرمان/خروجی/شاهد همان revision | نتیجه |
|---|---|---|---|
| G1-spec | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G2-isolation | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G3-tool-scope | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G4-tests-security | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G5-protection | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G6-evidence | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G7-human | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G8-budget | `MISSING` | `NOT_RUN` | `NOT_RUN` |
| G9-independent | `MISSING` | `NOT_RUN` | `NOT_RUN` |

G5 قواعد واقعی مقصد را بخواند؛ ساخت PR/تغییر settings خودکار نیست. G9 شخص/عامل واقعاً جداگانهٔ مصوب و روش review می‌خواهد؛ self-check جای آن نیست. human approval و merge واقعی جدا از reviewer هستند.

## پنج گیت دامنه‌ای، هرکدام با دلیل/شاهد مستقل

| Security | Privacy | Finance | Legal | Product |
|---|---|---|---|---|
| `NOT_RUN` | `NOT_RUN` | `NOT_RUN` | `NOT_RUN` | `NOT_RUN` |

N/A فقط با دلیل و تأیید انسانی؛ UNKNOWN/NOT_RUN/DEFERRED قبولی نیست. Product gate همین AC کوچک است، نه اجبار به بستن کل release/D-01/D-10.

## بودجه و stop، از قبل نه پس از اجرا

- زمان/هزینه/egress/مدل مجاز با منشأ مصوبه: `MISSING`
- سقف تلاش کل همین قرارداد: `MISSING`؛ تعداد retry را جدا و به مجموع اضافه‌نکرده ثبت کن.
- مصرف تاریخی مرتبط / remaining معتبر: `UNKNOWN`؛ تلاش‌های قبلی reset نشوند.
- حداکثر سه تلاش خطای تکراری متن Finn، enforcement نصب‌شده فرض نشود؛ محدودیت سخت‌تر/مصرف‌شدهٔ قرارداد جاری مقدم است.
- شروع UTC / پایان / مصرف مرحله‌ها / stop reason: `NOT_STARTED`
- موارد نیازمند مجوز جدا: install محصول، cloud/model/data egress، paid service، push/PR/settings/merge/deploy و production.

## تحویل

patch/artifact hash و head، trace AC، فرمان/exit/count، baseline vs نتیجهٔ جدید، یافته‌های reviewer مستقل همان نسخه و disposition، human approval/merge اگر واقعاً انجام شد، NOT_RUNها و گام مستقل بعدی. هیچ خانه‌ای برای «تکمیل فرم» PASS نشود.
