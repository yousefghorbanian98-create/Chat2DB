#!/usr/bin/env python3
"""Build this independent kit; never reads or edits an MP checkout."""
from __future__ import annotations
import argparse
import base64
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = 'MP-UI-UX-Motion-Kit-v1.1.0.zip'
BUILDER_EXPORT = 'MP-UI-UX-Motion-Builder-Start-v1.1.0.fa.md'
EXCLUDED = {'node_modules', '.kit-build', '__pycache__', '.git', '.cache', '.DS_Store'}

def payload_files(root: Path = ROOT) -> list[Path]:
    result = []
    for path in root.rglob('*'):
        relative = path.relative_to(root)
        if any(part in EXCLUDED for part in relative.parts) or path.suffix == '.pyc':
            continue
        if path.is_symlink():
            raise ValueError('Symlinks are not distributable')
        if path.is_file():
            result.append(path)
    return sorted(result, key=lambda p: p.relative_to(root).as_posix())

def render_preview(root: Path = ROOT) -> str:
    tokens = json.loads((root/'TOKENS.json').read_text())
    receipts = json.loads((root/'preview/receipt-states.json').read_text())
    css = (root/'preview/preview.css').read_text()
    js = (root/'preview/preview.js').read_text()
    js = js.replace('@@TOKENS@@', json.dumps(tokens, ensure_ascii=False).replace('<', '\\u003c'))
    js = js.replace('@@RECEIPTS@@', json.dumps(receipts, ensure_ascii=False).replace('<', '\\u003c'))
    faces = []
    for stem, unicode_range in [
        ('arabic', 'U+0600-06FF,U+0750-077F,U+0870-089F,U+08A0-08FF,U+200C-200E,U+FB50-FDFF,U+FE70-FEFF'),
        ('latin', 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC,U+2122,U+2190-21FF,U+2212,U+FEFF,U+FFFD'),
    ]:
        font = base64.b64encode((root/f'assets/fonts/vazirmatn-{stem}-wght-normal.woff2').read_bytes()).decode()
        faces.append("@font-face{font-family:'Vazirmatn Kit';font-style:normal;font-display:swap;font-weight:100 900;src:url(data:font/woff2;base64,"+font+") format('woff2');unicode-range:"+unicode_range+";}")
    digest = base64.b64encode(hashlib.sha256(js.encode()).digest()).decode()
    csp = "default-src 'none'; script-src 'sha256-"+digest+"'; style-src 'unsafe-inline'; font-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'; object-src 'none'"
    text = (root/'preview/template.html').read_text()
    for key, value in [('CSP', csp), ('FONTS', '\n'.join(faces)), ('CSS', css), ('JS', js)]:
        text = text.replace('@@'+key+'@@', value)
    if re.search(r'@@[A-Z]+@@', text):
        raise ValueError('unresolved preview placeholder')
    return text

def manifest_bytes(root: Path = ROOT) -> bytes:
    files = []
    for path in payload_files(root):
        if path.name == 'PACKAGE_MANIFEST.json' and path.parent == root:
            continue
        data = path.read_bytes()
        files.append({'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return (json.dumps({'version':'1.1.0','scope':'KIT_ONLY_NOT_PRODUCT_QA','files':files},ensure_ascii=False,indent=2)+'\n').encode()

def archive_bytes(root: Path = ROOT) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in payload_files(root):
            name = 'MP-UI-UX-Motion-Kit-v1.1.0/' + path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026,11,24,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    return stream.getvalue()

def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true', help='read-only generated HTML/manifest/archive reproducibility check')
    parser.add_argument('--archive', type=Path, default=ROOT.parent/'releases'/ARCHIVE)
    args=parser.parse_args()
    preview = render_preview().encode()
    if args.check:
        if (ROOT/'preview/index.html').read_bytes() != preview:
            raise ValueError('preview drift')
        if (ROOT/'PACKAGE_MANIFEST.json').read_bytes() != manifest_bytes():
            raise ValueError('manifest drift')
        data=archive_bytes()
        if args.archive.exists() and args.archive.read_bytes() != data:
            raise ValueError('archive drift')
        standalone = args.archive.parent/BUILDER_EXPORT
        if standalone.exists() and standalone.read_bytes() != (ROOT/'START_HERE_BUILDER.fa.md').read_bytes():
            raise ValueError('standalone builder Markdown drift')
        print('GENERATED_KIT_REPRODUCIBLE_NOT_QA')
        return 0
    (ROOT/'preview/index.html').write_bytes(preview)
    (ROOT/'PACKAGE_MANIFEST.json').write_bytes(manifest_bytes())
    data=archive_bytes()
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    args.archive.write_bytes(data)
    checksum=hashlib.sha256(data).hexdigest()
    Path(str(args.archive)+'.sha256').write_text(checksum+'  '+args.archive.name+'\n')
    standalone = args.archive.parent/BUILDER_EXPORT
    standalone.write_bytes((ROOT/'START_HERE_BUILDER.fa.md').read_bytes())
    Path(str(standalone)+'.sha256').write_text(hashlib.sha256(standalone.read_bytes()).hexdigest()+'  '+standalone.name+'\n')
    print(json.dumps({'archive':str(args.archive),'standalone_builder_markdown':str(standalone),'bytes':len(data),'members':len(payload_files()),'sha256':checksum,'scope':'KIT_ONLY_NOT_PRODUCT_QA'},indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
