'use strict';
(() => {
  const tokens = @@TOKENS@@;
  const receiptStates = @@RECEIPTS@@;
  const media = (() => {
    try {
      const result = window.matchMedia('(prefers-reduced-motion: reduce)');
      return typeof result.addEventListener === 'function' ? result : null;
    } catch { return null; }
  })();
  const systemReduced = () => media?.matches ?? true;
  const reduceControl = document.getElementById('reduce-motion');
  const motionStatus = document.getElementById('motion-status');
  let manuallyReduced = false;
  let reduced = true;
  const running = new Set();

  function applyPreference() {
    const system = systemReduced();
    reduced = system || manuallyReduced;
    reduceControl.checked = reduced;
    reduceControl.disabled = system;
    document.documentElement.dataset.reduced = String(reduced);
    motionStatus.textContent = !media ? 'تنظیم سیستم نامعلوم؛ حرکت خاموش است' : system ? 'کاهش حرکت سیستم فعال است' : reduced ? 'حرکت خاموش؛ اطلاعات باقی است' : 'حرکت کوتاه و اختیاری';
    if (reduced) {
      for (const animation of running) animation.cancel();
      running.clear();
    }
  }
  reduceControl.addEventListener('change', () => { manuallyReduced = reduceControl.checked; applyPreference(); });
  media?.addEventListener('change', applyPreference);
  applyPreference();

  function animate(element, frames, duration) {
    if (reduced || typeof element.animate !== 'function') return;
    const animation = element.animate(frames, { duration, easing: 'cubic-bezier(.22,1,.36,1)' });
    running.add(animation);
    animation.addEventListener('finish', () => running.delete(animation), { once: true });
    animation.addEventListener('cancel', () => running.delete(animation), { once: true });
  }

  const content = document.getElementById('view-content');
  const stateControl = document.getElementById('view-state');
  const panel = document.getElementById('sample-panel');
  let mode = 'member';
  const stateCopy = {
    ready: ['نمایش برنامهٔ نمونه', 'در محصول فقط نسخهٔ معتبر و تأییدشدهٔ سرور نمایش داده می‌شود؛ هیچ برنامهٔ اجرایی در این سند تولید نشده است.'],
    loading: ['در حال دریافت اطلاعات', 'نمایش وضعیت بارگذاری؛ بدون درصد پیشرفت ساختگی.'],
    empty: ['هنوز داده‌ای وجود ندارد', 'نبود داده، خطا یا صفر نیست. قدم بعدی باید در محصول واقعی روشن باشد.'],
    error: ['دریافت اطلاعات انجام نشد', 'متن و ورودی کاربر حفظ می‌شوند؛ خطا فقط با تکان‌دادن فرم توضیح داده نمی‌شود.'],
    unknown: ['نتیجهٔ عملیات نامشخص است', 'ابتدا وضعیت سرور را تطبیق دهید؛ نتیجه را موفق فرض نکنید و درخواست نوشتن را کور تکرار نکنید.'],
    offline: ['اتصال برقرار نیست', 'این سند چیزی ذخیره نمی‌کند؛ انتقال دادهٔ حساس به صف آفلاین از این طراحی نتیجه نمی‌شود.'],
  };
  function renderState() {
    const state = stateControl.value;
    const copy = stateCopy[state] || stateCopy.unknown;
    content.replaceChildren();
    content.classList.toggle('loading', state === 'loading');
    content.setAttribute('aria-busy', String(state === 'loading'));
    const title = document.createElement('p'); title.className = 'state-heading';
    title.textContent = state === 'ready' && mode === 'staff' ? 'صف بررسی نمونهٔ کارکنان' : copy[0];
    const detail = document.createElement('p');
    detail.textContent = state === 'ready' && mode === 'staff' ? 'کارکنان فقط دادهٔ مجاز خود را می‌بینند؛ این نما نه دسترسی می‌دهد و نه سند یا پرداختی را تأیید می‌کند.' : copy[1];
    content.append(title, detail);
    if (state === 'loading') {
      for (const short of [false,true]) {
        const bar = document.createElement('div'); bar.className = 'skeleton-bar' + (short ? ' short' : ''); bar.setAttribute('aria-hidden','true'); content.append(bar);
      }
    }
  }
  stateControl.addEventListener('change', renderState);
  document.querySelectorAll('[data-mode]').forEach(button => {
    button.addEventListener('click', () => {
      mode = button.dataset.mode;
      document.querySelectorAll('[data-mode]').forEach(other => { const active = other === button; other.classList.toggle('selected',active); other.setAttribute('aria-pressed',String(active)); });
      document.getElementById('view-title').textContent = mode === 'member' ? 'فضای امروزِ عضو' : 'میز کارِ کارکنان';
      document.getElementById('view-eyebrow').textContent = mode === 'member' ? 'MEMBER EXPERIENCE' : 'STAFF EXPERIENCE';
      document.getElementById('view-subtitle').textContent = mode === 'member' ? 'دسترسی روشن به برنامهٔ معتبر؛ بدون شلوغی و حرکت مزاحم.' : 'فهرست‌های خوانا و تصمیم‌های قابل‌پیگیری؛ بدون بازسازی صفحات موجود.';
      renderState();
    });
  });
  document.getElementById('replay-panel').addEventListener('click', () => animate(content, [{transform:`translateY(${tokens.motion.travelPx.panel}px)`},{transform:'translateY(0)'}], tokens.motion.durationMs.enter));

  const receiptControl = document.getElementById('receipt-state');
  receiptControl.addEventListener('change', () => {
    const value = receiptStates[receiptControl.value] || receiptStates.unknown;
    document.getElementById('receipt-title').textContent = value.title;
    document.getElementById('receipt-detail').textContent = value.detail;
    const toneClass = { success: 'success-state', info: 'info-state', error: 'error-state', warning: 'warning-state' };
    document.getElementById('receipt-panel').className = 'receipt-state ' + (toneClass[value.tone] || 'warning-state');
    document.querySelector('#receipt-panel .status-symbol').textContent = value.tone === 'success' ? '✓' : value.tone === 'error' ? '×' : value.tone === 'info' ? 'i' : '!';
    // Deliberately no animation, optimistic approval, timer, upload, or network here.
  });

  const list = document.getElementById('demo-list');
  const add = document.getElementById('add-item');
  let sequence = 3;
  add.addEventListener('click', () => {
    if (sequence >= 8) { document.getElementById('list-status').textContent = 'سقف نمونهٔ کوتاه: ۸ برچسب؛ فهرست بلند به الگوی جدا نیاز دارد.'; return; }
    const old = new Map(Array.from(list.children, element => [element, element.getBoundingClientRect()]));
    const item = document.createElement('li'); item.dataset.key = String(++sequence);
    const dot = document.createElement('span'); dot.className = 'tiny-dot'; dot.setAttribute('aria-hidden','true');
    item.append(dot, document.createTextNode('برچسب نمایشی ' + sequence.toLocaleString('fa-IR')));
    list.prepend(item);
    for (const [element, before] of old) {
      const after = element.getBoundingClientRect();
      animate(element, [{transform:`translateY(${before.top-after.top}px)`},{transform:'translateY(0)'}],tokens.motion.durationMs.enter);
    }
    document.getElementById('list-status').textContent = sequence.toLocaleString('fa-IR') + ' برچسب نمایشی؛ چیزی در محصول ذخیره نشد.';
    // The button remains mounted and focused. No per-item stagger or persistence.
  });
})();
