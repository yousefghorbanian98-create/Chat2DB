# قالب inventory خواندنی UI/Motion — پیشنهاد، نه مجوز اجرا

این سند را به‌عنوان artifact خارج source و فقط در scope مجاز تکمیل کن. parentها همان PWA-12/PWA-13 هستند؛ parent تازه ساخته نشود. برای قواعد آغاز [START_HERE](../START_HERE_BUILDER.fa.md) را بخوان.

## هویت و اختیار

- checkout/ref/base/head: `UNKNOWN`
- source pin کیت: `0e69b56dd0c427e45f2c104613cc420ea1a8c49f`؛ drift واقعی: `NOT_RUN`
- منبع scope/قرارداد خواندن و بودجهٔ همین کار: `MISSING`
- سابقه/مصرف تلاش‌های مرتبط و مصوبهٔ جدید، اگر هست: `UNKNOWN؛ reset ممنوع`
- dirty fingerprint پالایش‌شده / مسیرهای حفظ‌شونده: `NOT_RECORDED`؛ محتوای خصوصی خوانده یا افشا نشود.
- منبع تصمیم‌های جاری و Dهای مؤثر: `NOT_RECORDED`
- نتیجهٔ این سند: `PROPOSED؛ نه AGENT-READY`

## جدول مشاهده

| path/symbol واقعی | parent/نقش/سناریو | وضعیت فعلی و شاهد line/hash | دادهٔ حساس/مالک server | normal/reduced/unknown/live change | focus/draft/SSR | GAP یا بدون نیاز به تغییر |
|---|---|---|---|---|---|---|
| `NOT_INSPECTED` | `PWA-12/PWA-13` | `NOT_RUN` | `UNKNOWN` | `NOT_RUN` | `NOT_RUN` | `UNKNOWN` |

حداقل مصرف‌های helper فعلی، motion موضعی App/Feedback، overlay، skeleton، chart، stable keys، CSS loop و provider/layer را ردیابی کن. جست‌وجوی متن source را runtime/browser/security QA معرفی نکن. توصیف رفتار و فایل مرجع با اصل داده/اسکرین‌شات خصوصی فرق دارد؛ receipt/chat/health/token/مسیر خصوصی به گزارش منتقل نشود.

## انتخاب یک خروجی بعدی

- GAP دقیق و شاهد؛ یا دلیل `NO_CHANGE_NEEDED`: `UNKNOWN`
- parent/AC منبع بدون بازنویسی: `NOT_LINKED`
- پیشنهاد محدود: `PROPOSED`
- allowlist و non-goal؛ اثر auth/role/DB/payment/cache/CI: `NOT_APPROVED`
- prerequisite واقعی و D مؤثر؛ کار مستقلِ قابل ادامه: `UNKNOWN`
- چرا ابزار فعلی کافی نیست؟ آیا اصلاً install لازم است؟ `پیش‌فرض: install صفر`
- خروجی بعدی: قرارداد یک GAP / نیاز به مالک / بدون تغییر، با دلیل.

**Stop:** نبود مجوز/بودجه یا ریسک داده فقط کار وابسته را متوقف کند؛ کد، install، PWA-00 retry یا انتشار از inventory نتیجه نمی‌شود.
