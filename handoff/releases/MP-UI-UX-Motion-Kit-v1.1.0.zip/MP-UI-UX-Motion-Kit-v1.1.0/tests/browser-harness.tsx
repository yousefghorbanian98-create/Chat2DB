/** Isolated synthetic recipe smoke fixture. NOT an MP route or application. */
import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { ConfigProvider } from "antd";
import { ImmediateAccessBoundary, NonSensitiveList } from "../recipes/StudioRecipes";
import { useLiveReducedMotion } from "../recipes/live-preference";

function Fixture() {
  const reduced = useLiveReducedMotion();
  const [permitted, setPermitted] = useState<boolean | null>(true);
  const [items, setItems] = useState([{ id: "a", label: "ONE_SYNTHETIC_ITEM" }, { id: "b", label: "TWO_SYNTHETIC_ITEM" }]);
  return <ConfigProvider direction="rtl"><main>
    <output id="preference" data-reduced={String(reduced)}>{String(reduced)}</output>
    <label htmlFor="draft">Synthetic draft</label><input id="draft" defaultValue="SYNTHETIC_DRAFT" />
    <button id="add" onClick={() => setItems(current => [{ id: "c", label: "THIRD_SYNTHETIC_ITEM" }, ...current])}>Add once</button>
    <NonSensitiveList items={items} />
    <button id="deny" onClick={() => setPermitted(null)}>Revoke display</button>
    <ImmediateAccessBoundary permitted={permitted}><p id="private-fixture">SYNTHETIC_GUARDED_CONTENT</p></ImmediateAccessBoundary>
  </main></ConfigProvider>;
}
createRoot(document.getElementById("root")!).render(<StrictMode><Fixture /></StrictMode>);
