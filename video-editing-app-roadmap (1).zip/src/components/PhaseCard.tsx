"use client";

import type { Phase } from "@/lib/roadmap-data";

interface PhaseCardProps {
  phase: Phase;
  onClick: () => void;
}

export default function PhaseCard({ phase, onClick }: PhaseCardProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-right ${phase.bgColor} border ${phase.borderColor} rounded-xl p-5 card-hover group cursor-pointer`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`text-xs font-semibold ${phase.color} bg-current/10 rounded-full px-2 py-0.5`} style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}>
          فاز {phase.id}
        </div>
        <span className="text-3xl group-hover:scale-110 transition-transform">{phase.emoji}</span>
      </div>
      <h3 className={`font-bold ${phase.color} text-base mb-2`}>{phase.title}</h3>
      <p className="text-gray-400 text-xs leading-relaxed mb-3 line-clamp-2">{phase.description}</p>
      <div className="flex items-center justify-between">
        <div className="flex gap-1.5">
          <span className="text-xs bg-gray-800 text-gray-400 rounded px-1.5 py-0.5">
            {phase.libs.length} کتابخانه
          </span>
          <span className="text-xs bg-gray-800 text-gray-400 rounded px-1.5 py-0.5">
            {phase.improvements.length} پیشنهاد
          </span>
        </div>
        <span className={`text-xs ${phase.color} opacity-70 group-hover:opacity-100 transition-opacity`}>مشاهده →</span>
      </div>
    </button>
  );
}
