/**
 * Reference recipes, NOT installed product components.
 * Keep current ConfigProvider/fa_IR/StyleProvider layer and existing Feedback wrappers.
 * Fold reviewed parts into current files; do not introduce a competing UI or motion root.
 */
import type { PropsWithChildren, ReactNode } from "react";
import { Alert, Empty, List } from "antd";
import { motion, type HTMLMotionProps } from "framer-motion";
import { receiptPresentation, selectMotionPolicy } from "./motion-policy.js";
import { useLiveReducedMotion } from "./live-preference.js";

/**
 * Client display guard ONLY; server authorization remains mandatory.
 * Intentionally no AnimatePresence, delayed exit, timer, token parsing or persistence.
 * On a revoked/unknown grant, private content is removed in this render.
 */
export function ImmediateAccessBoundary({
  permitted,
  children,
}: PropsWithChildren<{ permitted: boolean | null }>) {
  if (permitted !== true) {
    return <Alert type="warning" showIcon message="دسترسی معتبر نیست" description="نشست و مجوز باید از قرارداد معتبر سرور تأیید شوند." />;
  }
  return <>{children}</>;
}

/** Display-only receipt state; no upload, approval action, bank logic, API or local status inference. */
export function ReceiptStatusView({ phase }: { phase: string }) {
  const view = receiptPresentation(phase);
  return (
    <div role="status" aria-live="polite" aria-atomic="true">
      <Alert showIcon type={view.tone} message={view.title} description={view.detail} />
    </div>
  );
}

export interface DisplayItem {
  id: string;
  label: ReactNode;
}

/**
 * Stable IDs; no entry/exit opacity, remount keys or per-row stagger.
 * For non-sensitive, short lists only; virtual tables/charts/finance need separate proof.
 */
export function NonSensitiveList({ items }: { items: readonly DisplayItem[] }) {
  const preference = useLiveReducedMotion();
  const policy = selectMotionPolicy(preference, "list");
  const motionProps: HTMLMotionProps<"div"> = {
    initial: false,
    layout: policy.layout,
    transition: { duration: policy.duration, ease: [0.22, 1, 0.36, 1] },
  };
  if (items.length === 0) return <Empty description="موردی برای نمایش نیست" />;
  return (
    <List
      dataSource={[...items]}
      rowKey={(item) => item.id}
      renderItem={(item) => (
        <List.Item>
          <motion.div {...motionProps} className={policy.enabled ? undefined : "mp-kit-reduced"} style={{ width: "100%" }}>{item.label}</motion.div>
        </List.Item>
      )}
    />
  );
}
