#!/usr/bin/env node
/** Optional loopback-only browser download smoke, NOT product/deployment QA.
 * Requires the same separate tooling as browser_smoke.mjs and a running delivery server.
 * node scripts/download_smoke.mjs http://127.0.0.1:4174 /path/to/kit.zip /path/outside-kit/report.json
 * Never writes into the kit or modifies an MP checkout.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
if (process.argv.length < 5) throw new Error('Expected BASE_URL ARCHIVE_PATH EXTERNAL_REPORT_PATH');
const base = new URL(process.argv[2]);
if (base.protocol !== 'http:' || !['127.0.0.1', 'localhost'].includes(base.hostname)) throw new Error('This smoke accepts loopback HTTP only, not production/public URLs');
const archive = resolve(process.argv[3]);
const output = resolve(process.argv[4]);
if (output === root || output.startsWith(root + '/')) throw new Error('Write the delivery receipt outside the final kit to avoid circular archive hashes');
const tools = process.env.KIT_BROWSER_TOOLS || resolve(root, '../../.cache/ui-motion-kit-work/tooling');
const require = createRequire(join(tools, 'package.json'));
const { chromium } = require('playwright-core');
const sparticuz = (await import(pathToFileURL(require.resolve('@sparticuz/chromium')).href)).default;
const libs = join(tools, 'chromium-libs/lib');
if (existsSync(libs)) process.env.LD_LIBRARY_PATH = libs+':'+(process.env.LD_LIBRARY_PATH || '');
const sha = data => createHash('sha256').update(data).digest('hex');
const report = { kit_version: '1.1.0', status: 'NOT_RUN', scope: 'real browser bytes/attachment smoke against sandbox loopback only; public HTTPS proxy was not fetched; NOT MP/product/security QA', runtime_clock_utc: new Date().toISOString(), archive_sha256: sha(readFileSync(archive)), builder_markdown_sha256: sha(readFileSync(join(root, 'START_HERE_BUILDER.fa.md'))), test_script_sha256: sha(readFileSync(fileURLToPath(import.meta.url))), cases: [], external_network_attempts: [], page_errors: [], console_errors: [] };
let browser;
async function checked(name, run) {
  await run(); report.cases.push({ name, status: 'PASS' });
}
try {
  browser = await chromium.launch({ headless: true, executablePath: process.env.KIT_CHROMIUM_EXECUTABLE || await sparticuz.executablePath(), args: sparticuz.args.filter(a => !a.startsWith('--disable-web-security') && !a.startsWith('--allow-running-insecure-content')) });
  report.browser = browser.version();
  const context = await browser.newContext({ acceptDownloads: true });
  await context.route(/^https?:/, route => {
    if (new URL(route.request().url()).origin === base.origin) return route.continue();
    report.external_network_attempts.push(route.request().url()); return route.abort();
  });
  const page = await context.newPage();
  page.on('pageerror', error => report.page_errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') report.console_errors.push(message.text()); });
  await page.goto(base.href);
  for (const width of [320, 390, 1440]) await checked('download landing has no horizontal overflow at '+width, async () => {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
    assert.equal(await page.locator('html').getAttribute('dir'), 'rtl');
  });
  await checked('ZIP click triggers a completed attachment with the exact packaged bytes', async () => {
    const pending = page.waitForEvent('download'); await page.locator('#download-zip').click(); const download = await pending;
    assert.equal(download.suggestedFilename(), archive.split('/').at(-1));
    assert.equal(await download.failure(), null);
    const bytes = readFileSync(await download.path());
    assert.equal(sha(bytes), report.archive_sha256); assert.equal(bytes.subarray(0, 2).toString(), 'PK');
  });
  await checked('Markdown click downloads the exact primary builder entry, not an HTML error', async () => {
    const pending = page.waitForEvent('download'); await page.locator('#download-builder').click(); const download = await pending;
    assert.equal(download.suggestedFilename(), 'MP-UI-UX-Motion-Builder-Start-v1.1.0.fa.md');
    assert.equal(await download.failure(), null);
    const bytes = readFileSync(await download.path()); assert.equal(sha(bytes), report.builder_markdown_sha256);
    assert.match(bytes.toString('utf8'), /^# بیلدر/);
  });
  await checked('checksum response matches the actual ZIP attachment', async () => {
    const href = await page.locator('#download-sha').getAttribute('href');
    const response = await page.request.get(new URL(href, base).href);
    assert.equal(response.status(), 200); assert.ok((await response.text()).startsWith(report.archive_sha256+'  '));
  });
  await checked('only manifest/delivery content is exposed', async () => {
    for (const path of ['/.git/config', '/node_modules/react/package.json', '/downloads/MISSING.zip']) assert.equal((await page.request.get(new URL(path, base).href)).status(), 404);
  });
  await checked('no browser errors or external network attempts in download cases', async () => {
    assert.deepEqual(report.external_network_attempts, []); assert.deepEqual(report.page_errors, []); assert.deepEqual(report.console_errors, []);
  });
  report.status = 'KIT_DOWNLOAD_SMOKE_PASS_NOT_PRODUCT_QA';
  await context.close();
} catch (error) {
  report.status = 'KIT_DOWNLOAD_SMOKE_FAILED'; report.error = error.message; process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  mkdirSync(dirname(output), { recursive: true }); writeFileSync(output, JSON.stringify(report, null, 2)+'\n');
  console.log(JSON.stringify({ status: report.status, passed: report.cases.length, archive_sha256: report.archive_sha256, builder_markdown_sha256: report.builder_markdown_sha256, error: report.error }, null, 2));
}
