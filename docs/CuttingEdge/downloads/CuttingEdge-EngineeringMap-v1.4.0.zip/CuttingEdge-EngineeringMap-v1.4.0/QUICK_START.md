# ⚡ شروع سریع — Cutting Edge v1.4.0 + Finn-Loop v3.1 + Nemotron-Brain

## ۱) خواندن نقشه
- `ENGINEERING_MAP_V1.4.md` — نقشهٔ کامل مهندسی (۱۵ بخش) از صفر تا انتشار EXE
- `NEMOTRON_BRAIN.md` — سند طراحی مغز متفکر جدید برنامه (NVIDIA Nemotron 3)

## ۲) نصب برنامه (نسخهٔ آماده v1.4.0)
https://github.com/yousefghorbanian98-create/Chat2DB/releases/download/v1.4.0/Cutting-Edge-Setup-1.4.0.exe

## ۳) کلید رایگان Nemotron (برای فاز ۱۹ — مغز متفکر)
1. برو به https://build.nvidia.com — ثبت‌نام رایگان
2. کلید `nvapi-...` را بگیر و در nodeهای `run-19-*` به‌صورت `export CE_NVIDIA_API_KEY=...` قرار بده
   (بدون کلید، مراحل ۱۹ شکست نمی‌خورند؛ `pending-needs-key` می‌شوند)

## ۴) راه‌اندازی لوپ خودکار (n8n + OmniRoute)
```bash
docker run -d -p 20128:20128 bunsdev/omniroute          # دروازهٔ مدل‌ها
docker run -d -p 5678:5678 -v n8n_data:/home/node/.n8n n8nio/n8n   # ارکستراتور
```
1. مرورگر: `http://localhost:5678`
2. Import ← `finn-loop/finn-loop.n8n.json` (۱۴۶ node)
3. GitHub credential (دسترسی content) به nodeهای `mark-*` و `Commit Report` وصل کنید
4. Activate — لوپ هر ساعت از اولین مرحلهٔ done-نشده ادامه می‌یابد (فعلاً: 45/71)

## ۵) اجرای دستی مراحل
```bash
python3 finn-loop-v3/run_stage.py 15-0       # یک مرحله
python3 finn-loop-v3/run_stage.py --report   # گزارش پیشرفت
```

## ۶) لینک‌های کلیدی
- سورس v1.4.0: https://github.com/yousefghorbanian98-create/Chat2DB/tree/arena/01a032fb-chat2db/ce-app
- ریلیز نقشه: https://github.com/yousefghorbanian98-create/Chat2DB/releases/tag/engineering-map-v1.4.0
- کلید Nemotron: https://build.nvidia.com
