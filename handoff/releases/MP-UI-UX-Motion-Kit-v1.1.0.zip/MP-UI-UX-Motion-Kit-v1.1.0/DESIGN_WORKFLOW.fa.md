# گردش پیشنهادی طراحی تا ادغام — بدون نصب کورکورانه

**خروجی این سند نقشهٔ کار است؛ نه اجرای Penpot، نصب Storybook یا authoring انجام‌شدهٔ فایل `.penpot`.** فایل طراحی Penpot/Excalidraw ساخته‌شده یا اتصال حساب/سرویس ابری در این ZIP ادعا نشده است. ابزارها جای Arena/Finn، قرارداد API یا تأیید مالک را نمی‌گیرند.

## مرحلهٔ A — فهم و inventory، بدون بازنویسی

مرجع ۵۰ parent و وضعیت جاری را از [فایل شروع](START_HERE_BUILDER.fa.md) بخوان. از [inventory](templates/UI_MOTION_INVENTORY.fa.md) فقط برای scope مصوب استفاده کن. هدف پیدا کردن شکاف است، نه توجیه نصب ابزار.

**خروجی:** سناریو/نقش، state، path/symbol فعلی، دادهٔ حساس، evidence، GAP و parent مربوط. اطلاعات عضو، تصویر بدن، رسید، token و متن chat وارد diagram/screenshot/cloud نشوند. اگر GAP نیست، نتیجهٔ معتبر «بدون نیاز به تغییر» است.

## مرحلهٔ B — فلو و wireframe، Excalidraw اختیاری

از منبع رسمی معرفی‌شده در [ابزارها](OPEN_SOURCE_TOOLS.fa.md) استفاده کن؛ اجرای local/self-hosted مطابق نسخهٔ سازگار و مجوز است. برای خواندن همین کیت، نصب آن لازم نیست.

**خروجی پیشنهادی:** فایل قابل‌ویرایش و SVG برای پنج سفر عضو، مربی، حضور QR، رسید و امنیت؛ داده‌ها مصنوعی. حالت‌های loading/empty/error/unknown/403/offline و مرز server تصمیم را از ظاهر جدا نشان بده. بازتولید تمام نمودارهای قبلی یا تبدیل مدل سه‌نقشی قدیمی به schema جدید هدف نیست.

**پذیرش طراحی:** مسیر deny/revoke صریح؛ upload به pending_review؛ نتیجهٔ مالی مبهم بدون retry کور؛ PWA-3F تا مصوبه BLOCKED. تغییر role/grant/DB از diagram نتیجه نمی‌شود.

## مرحلهٔ C — طراحی بصری با Penpot، بیرون از محصول

پنل طراحی را در محیط مجاز خودت آماده کن؛ account، plugin، model/MCP یا cloud upload با این سند مجاز نشده است. نسخه و قابلیت‌های واقعی ابزار را بخوان. آدرس منبع و license pin در JSON ابزارهاست؛ pin منبع مجوز، دستور build/deploy آن commit نیست.

**خروجی پیشنهادی:**

1. یک library/صفحهٔ foundation: palette، type، spacing، radius، focus، RTL و motion policy؛ نه design system موازی در کد.
2. اجزای مرتبط با GAP منتخب: همان کنترل‌های AntD، همراه variant/state؛ مثال در [COMPONENT_STATES.csv](templates/COMPONENT_STATES.csv).
3. طرح‌های responsive برای عرض‌های هدف قرارداد؛ 320/390/1440 حداقلِ preview این کیت‌اند، نه اثبات همهٔ دستگاه‌ها. طراحی 768/zoom/device اضافی هدف پیشنهادی است، نه نتیجهٔ تست.
4. annotation برای keyboard/focus، حالت مجاز/غیرمجاز، reduced motion و منبع واقعی داده. RTL را با mirror کردن QR، نمودار، لوگو و عدد اشتباه نگیر.
5. لینک/نام component طراحی به path/symbol موجود و parent اصلی. «صفحه زیبا» بدون mapping، قرارداد اجرا نیست.

[نگاشت token](templates/DESIGN_TOKEN_MAPPING.csv) دستی و پیشنهادی است. TOKENS.json ساختار مخصوص کیت دارد؛ import مستقیمِ آزمایش‌شده به Penpot یا DTCG ادعا نمی‌شود. اگر adapter لازم شد، خود یک خروجی کوچک با تست parity است. مجوز فونت Vazirmatn و رفرنس مقادیر حفظ شوند.

## مرحلهٔ D — کاتالوگ اجزا؛ اول نیاز، بعد Storybook

برای شروع می‌توان از preview مستقل و تست‌های کیت استفاده کرد. فقط اگر بازبینی stateها/مستندات component واقعاً با ابزار موجود حل نمی‌شود، Storybook را به‌عنوان dev-tool جدا پیشنهاد بده.

**قبل از هر install در MP:** قرارداد/allowlist و بودجه، نسخهٔ سازگار با React/Vite/TypeScript و lock فعلی، peer dependencies، اثر CI/egress و مسیر بازگشت بررسی شوند. latest یا سرویس visual-regression ابری پیش‌فرض نیست. هیچ تغییر Storybook در این بسته روی محصول اعمال نشده است.

**خروجی پیشنهادی بعد از مجوز:** storyهای synthetic برای ready/loading/empty/error/unknown/denied/offline و reduced/normal؛ wrapperهای واقعی fa_IR/RTL/theme، بدون auth/token/API واقعی. تمرکز روی همان کامپوننت‌های موجود؛ کنترل دوم یا پوشاندن مشکل با mock موفقیت ممنوع. قبولی story جای API/ownership/device QA را نمی‌گیرد.

## مرحلهٔ E — توکن‌ها؛ Style Dictionary فعلاً defer

اگر JSON/CSS موجود برای یک خروجی کافی است، pipeline جدید نساز. فقط با نیاز واقعی به تولید چند خروجی و قرارداد مجاز، schema adapter و generator بررسی شود.

**شرط پذیرش آینده:** یک مرجع canonical، تبدیل واحدهای ms/px صریح، تمایز دادهٔ معنایی و مقدار، خروجی reproducible، تست parity و عدم تولید secret/asset بدون مجوز. CSV همراه، نام‌گذاری پیشنهادی است نه parser/ورودی آماده. نه Penpot و نه Style Dictionary خودکار کد مشروع MP را از این فایل تولید نمی‌کنند.

## مرحلهٔ F — ادغام یک GAP و شاهد واقعی

[فایل شروع](START_HERE_BUILDER.fa.md) نه حوزه و پنج گیت را تعریف می‌کند. پس از قرارداد، فقط همان GAP را در مالک فعلی اصلاح کن. پیشنهاد آغاز در صورت تأیید: reduced/unknown و live preference در helper موجود با تست SSR/cleanup/live-change و حفظ focus/draft.

پیش‌نمایش عمداً native DOM/CSS/Web Animations سبک دارد؛ نمونهٔ نصب‌شدهٔ AntD یا اپ دوم نیست. recipeهای واقعی React/AntD/Framer جداگانه typecheck و SSR/browser fixture می‌شوند. تطبیق ساختار preview با UI محصول، کپی خودکار CSS یا replacement stylesheet نیست.

**اثرهای نیازمند اختیار جدا:** package/lock محصول، UI migration، auth/role/DB/payment/session/offline، سرویس/مدل بیرونی، خرید، workflow dispatch، push/PR/merge/deploy. توصیهٔ ابزار و بودجهٔ کیت هیچ‌کدام را پیشاپیش تصویب نمی‌کنند.
