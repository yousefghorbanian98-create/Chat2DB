# تصمیم پیشنهادی انتخاب ابزار — نسخهٔ ۱.۱.۰

**وضعیت: پیشنهاد قابل‌بررسی؛ نه ADR محصول یا مجوز تغییر dependency.** شناخت ما به source pin و فایل‌های مشاهده‌شده محدود است؛ dirty worktree بیلدر، رندر فعلی یا تمام محصول مستقلاً دیده نشده‌اند.

## حفظ و استفادهٔ دوباره

- **Ant Design 5**: Button/Input/Form/Modal/Drawer/Tabs/Table/Alert موجود، با ConfigProvider فعلی و فارسی. خود کنترل تعاملی از صفر بازنویسی نشود. جایگزینی toast/skeleton موجود نیز task جدا با تست است.
- **Framer Motion 11**: همان موتور نصب‌شده؛ policyهای تازه پس از review در `src/lib/motion.ts` فعلی ادغام شوند. recipe نمونه، منبع canonical دوم نیست.
- **CSS بومی**: hover/focus/color feedback کوتاه، بدون transition:all و smooth scrolling سراسری. تغییر وضعیت مهم متنی و قابل‌دسترسی باشد.
- **Vazirmatn، Ant Icons، Recharts**: همین منابع حفظ شوند. تاریخ جلالی از کنترل فعلی؛ عدد/ریال از helper جاری؛ نمایش locale در motion دوباره پیاده نشود.

## فعلاً اضافه نکن

| گزینه | دلیل عدم انتخاب پیش‌فرض | چه زمانی دوباره بررسی شود؟ |
|---|---|---|
| Motion جدید (`motion/react`) | Framer Motion موجود همان نیاز اصلی را پوشش می‌دهد؛ مهاجرت فقط برای نام جدید لازم نیست | GAP واقعی، سازگاری React/lock و آزمون مهاجرت مصوب |
| GSAP / Anime.js | timeline نمایشی پیچیده نیاز اصلی پنل/عضو نیست | لندینگ مستقل با نیاز ثابت‌شده، مجوز و budget جدا |
| React Spring | موتور فنری دوم، هم‌پوشانی با Framer Motion | نیاز فیزیکی خاص که با موتور فعلی حل نمی‌شود |
| AutoAnimate | layout animation فعلی قابل بازاستفاده است؛ رفتار خودکار روی جدول/فرم ممکن است نامناسب باشد | GAP محدود و تست‌شده، نه فعال‌سازی سراسری |
| Lottie / Rive | فایل، runtime و مجوز asset جدید؛ برای فرم/جدول لازم نیست | onboarding/تصویرسازی مشخص با asset مجاز، fallback ثابت و بررسی حجم/دسترس‌پذیری |
| کتابخانهٔ UI دوم / مجموعهٔ نمایشی کامل | خطر دو هویت بصری و تضاد کنترل‌ها/CSS | فقط نیاز اثبات‌شده و تصویب مستقل؛ نه به‌خاطر زیبایی demo |

رایگان‌بودن، OSS/OSI بودن و مجوز asset یکی نیستند. مجوزها باید در نسخهٔ منتخب بررسی شوند؛ این بسته هیچ مجوزی برای سرویس پولی، API مدل، telemetry، CDN یا خرید asset صادر نمی‌کند.

## نکات واقعی source، نه ادعای runtime

- main.tsx: تم dark، RTL، fa_IR، StyleProvider layer و رنگ‌های فعلی.
- lib/motion.ts: press=120ms، enter=280ms، page=340ms؛ stagger فعلی تا 540ms می‌رسد؛ null تنظیم حرکت به false تبدیل می‌شود.
- App.tsx و Feedback.tsx: حرکت‌های موضعی خارج از helper نیز وجود دارند. یکدست‌سازی فقط پس از inventory و تست، نه replace سراسری.
- پیاده‌سازی نصب‌شدهٔ `useReducedMotion()` در Framer Motion 11.18.2 مقدار preference را با state اولیه می‌خواند؛ hook خودِ React در آن فایل برای تغییر زندهٔ سیستم subscribe نمی‌کند. پس برای ادعای واکنش زنده، به نام hook یا توضیح آن اکتفا نکن. recipe در `recipes/live-preference.ts` با React 18 `useSyncExternalStore` و cleanup، adapter پیشنهادی و بدون dependency تازه دارد؛ باید در helper فعلی ادغام و روی محصول آزموده شود.
- پیشنهاد این کیت: unknown/عدم پشتیبانی subscription برابر بدون حرکت، critical بدون exit delay، stagger تزئینی opt-in با سقف 120ms. این‌ها هنوز در MP پیاده نشده‌اند.

API فریم‌ورک/نسخهٔ تازه را از روی مقالهٔ عمومی وارد نکن. سازگاری این recipeها فقط با نسخه‌های validation ثبت‌شده آزموده شده است؛ parity محصول یا پشتیبانی همهٔ مرورگرها نیست.

## افزودهٔ ۱.۱.۰ — لایهٔ طراحی بیرون اپ

Penpot ابزار منتخب طراحی، Excalidraw اختیاری برای flow، Storybook dev-tool اختیاری پس از قرارداد و Style Dictionary فعلاً defer است. هیچ‌کدام روی MP نصب نشده‌اند و شرط validation کیت نیستند. [فهرست و مجوزها](OPEN_SOURCE_TOOLS.fa.md)، [گردش طراحی](DESIGN_WORKFLOW.fa.md) و [شروع کامل بیلدر](START_HERE_BUILDER.fa.md) مرجع عملی این نسخه‌اند. وضعیت تاریخی PWA-00 و بودجه/تلاش مصرف‌شده از این پیشنهاد reset نمی‌شود.
