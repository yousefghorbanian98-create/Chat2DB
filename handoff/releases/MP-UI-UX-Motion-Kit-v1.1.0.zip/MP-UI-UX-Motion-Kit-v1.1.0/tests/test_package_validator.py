"""Integrity-validator regression checks on synthetic temporary copies, not MP QA."""
from __future__ import annotations
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT/'scripts'/filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

validator = load('kit_validator', 'validate_package.py')
builder = load('kit_builder', 'build_package.py')

class PortableKitChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='mp-ui-kit-test-')
        self.root = Path(self.temp.name)/'kit'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('node_modules', '.kit-build', '__pycache__', '.cache'))
        self.addCleanup(self.temp.cleanup)

    def resign(self):
        (self.root/'PACKAGE_MANIFEST.json').write_bytes(builder.manifest_bytes(self.root))

    def problems(self):
        return '\n'.join(validator.check(self.root)['problems'])

    def test_baseline_package(self):
        self.assertEqual(validator.check(self.root)['status'], 'KIT_OK_NOT_PRODUCT_QA')

    def test_plain_nested_path(self):
        self.assertEqual(validator.safe_relative('assets/fonts/OFL.txt').as_posix(), 'assets/fonts/OFL.txt')

    def test_reject_unsafe_manifest_paths(self):
        for value in ['', '../escape', '/absolute', 'a/../../b', 'a/./b', 'a//b', 'C:/drive', 'a\\b', 'a\0b']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                validator.safe_relative(value)

    def test_known_contrast_ratios(self):
        self.assertAlmostEqual(validator.contrast('#000000', '#FFFFFF'), 21)
        self.assertAlmostEqual(validator.contrast('#111827', '#111827'), 1)

    def test_unlisted_file_rejected(self):
        (self.root/'unexpected.txt').write_text('SYNTHETIC_EXTRA')
        self.assertIn('manifest inventory mismatch', self.problems())

    def test_changed_file_rejected(self):
        with (self.root/'README.fa.md').open('a') as stream:
            stream.write('\nSYNTHETIC_DRIFT\n')
        self.assertIn('digest/size mismatch', self.problems())

    def test_malformed_manifest_rejected(self):
        (self.root/'PACKAGE_MANIFEST.json').write_text('{broken')
        self.assertEqual(validator.check(self.root)['status'], 'KIT_INVALID')

    def test_duplicate_manifest_entry_rejected(self):
        path = self.root/'PACKAGE_MANIFEST.json'
        data = json.loads(path.read_text())
        data['files'].append(data['files'][0])
        path.write_text(json.dumps(data))
        self.assertIn('duplicate manifest path', self.problems())

    def test_csp_detected_even_when_manifest_is_refreshed(self):
        path = self.root/'preview/index.html'
        path.write_text(path.read_text().replace('script-src', 'script-src-disabled', 1))
        self.resign()
        self.assertIn('CSP/script binding', self.problems())

    def test_broken_html_link_detected(self):
        path = self.root/'preview/index.html'
        path.write_text(path.read_text().replace('../START_HERE_BUILDER.fa.md', '../MISSING.fa.md'))
        self.resign()
        self.assertIn('broken/escaping local HTML link', self.problems())

    def test_broken_markdown_link_detected(self):
        path = self.root/'README.fa.md'
        path.write_text(path.read_text()+'\n[synthetic missing](MISSING.fa.md)\n')
        self.resign()
        self.assertIn('broken/escaping local Markdown link', self.problems())

    def test_font_header_detected(self):
        path = self.root/'assets/fonts/vazirmatn-arabic-wght-normal.woff2'
        path.write_bytes(b'NOT_A_FONT')
        self.resign()
        self.assertIn('invalid font header', self.problems())

    def test_validation_dependency_must_match_source_identity(self):
        path = self.root/'references/MP_SOURCE.json'
        data = json.loads(path.read_text())
        data['locked_packages']['react']['version'] = '0.0.0'
        path.write_text(json.dumps(data))
        self.resign()
        self.assertIn('validation dependency diverges from observed lock', self.problems())

    def test_screen_mapping_count_detected(self):
        path = self.root/'SCREEN_MATRIX.csv'
        path.write_text('\n'.join(path.read_text().splitlines()[:-1])+'\n')
        self.resign()
        self.assertIn('screen matrix is not 25 rows', self.problems())
        self.assertIn('canonical member/staff mapping changed', self.problems())

    def test_stale_evidence_binding_detected(self):
        path = self.root/'references/BROWSER_CHECK.json'
        data = json.loads(path.read_text())
        data['bindings']['preview/index.html'] = '0'*64
        path.write_text(json.dumps(data))
        self.resign()
        self.assertIn('stale evidence binding', self.problems())

    def test_ignored_generated_modules_do_not_change_payload(self):
        path = self.root/'node_modules/synthetic-dependency'
        path.mkdir(parents=True)
        (path/'index.js').write_text('SYNTHETIC_IGNORED')
        self.assertEqual(validator.check(self.root)['status'], 'KIT_OK_NOT_PRODUCT_QA')

    def test_tool_catalogue_requires_twelve_choices(self):
        path = self.root/'references/OPEN_SOURCE_TOOLS.json'
        data = json.loads(path.read_text()); data['tools'].pop(); path.write_text(json.dumps(data)); self.resign()
        self.assertIn('expected 12 upstream tools', self.problems())

    def test_tool_install_is_not_implicitly_authorized(self):
        path = self.root/'references/OPEN_SOURCE_TOOLS.json'
        data = json.loads(path.read_text()); data['tools'][0]['automatic_install'] = True; path.write_text(json.dumps(data)); self.resign()
        self.assertIn('unapproved installation/egress', self.problems())

    def test_tool_license_source_must_be_pinned(self):
        path = self.root/'references/OPEN_SOURCE_TOOLS.json'
        data = json.loads(path.read_text()); data['tools'][0]['source_commit'] = 'develop'; path.write_text(json.dumps(data)); self.resign()
        self.assertIn('tool license provenance malformed', self.problems())

    def test_tool_license_and_selection_are_not_silently_changed(self):
        path = self.root/'references/OPEN_SOURCE_TOOLS.json'
        data = json.loads(path.read_text()); data['tools'][0]['license_spdx'] = 'MIT'; path.write_text(json.dumps(data)); self.resign()
        self.assertIn('tool license/decision changed', self.problems())

    def test_original_canonical_plan_is_immutable(self):
        path = self.root/'references/SOURCE_PLAN.fa.md'
        path.write_text(path.read_text().replace('ثبت تصمیم پلتفرم', 'SYNTHETIC_CHANGED_TITLE')); self.resign()
        self.assertIn('canonical/historical reference changed', self.problems())

    def test_historical_decision_is_not_an_approval(self):
        path = self.root/'references/DECISION_REGISTER.json'
        data = json.loads(path.read_text()); data['decisions'][0]['owner_response'] = 'SYNTHETIC_APPROVAL'; path.write_text(json.dumps(data)); self.resign()
        self.assertIn('historical decisions misrepresented', self.problems())

    def test_primary_builder_entry_keeps_all_nine_domains(self):
        path = self.root/'START_HERE_BUILDER.fa.md'
        path.write_text(path.read_text().replace('G9-', 'GX-')); self.resign()
        self.assertIn('builder entry missing core scope/gate context', self.problems())

    def test_token_mapping_values_match_the_single_source(self):
        path = self.root/'templates/DESIGN_TOKEN_MAPPING.csv'
        path.write_text(path.read_text().replace('#0B0F14', '#FFFFFF')); self.resign()
        self.assertIn('token mapping drift/overclaim', self.problems())

    def test_nested_markdown_links_are_checked(self):
        path = self.root/'templates/UI_MOTION_INVENTORY.fa.md'
        path.write_text(path.read_text()+'\n[synthetic missing](../MISSING.fa.md)\n'); self.resign()
        self.assertIn('broken/escaping local Markdown link', self.problems())

    def test_all_package_version_fields_match(self):
        path = self.root/'TOKENS.json'
        data = json.loads(path.read_text()); data['package_version'] = '0.0.0'; path.write_text(json.dumps(data)); self.resign()
        self.assertIn('package version drift', self.problems())

if __name__ == '__main__':
    unittest.main()
