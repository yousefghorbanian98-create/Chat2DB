"use client";

import { phases } from "@/lib/roadmap-data";

interface SidebarProps {
  selectedPhaseId: number;
  onSelect: (id: number) => void;
}

export default function Sidebar({ selectedPhaseId, onSelect }: SidebarProps) {
  return (
    <aside className="w-56 flex-shrink-0 hidden lg:block">
      <div className="sticky top-24 space-y-1">
        <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-3 mb-3">فازها</p>
        {phases.map((phase) => (
          <button
            key={phase.id}
            onClick={() => onSelect(phase.id)}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all ${
              selectedPhaseId === phase.id
                ? `${phase.bgColor} ${phase.color} border ${phase.borderColor}`
                : "text-gray-400 hover:text-white hover:bg-gray-800"
            }`}
          >
            <span className="text-lg">{phase.emoji}</span>
            <span className="text-right">{phase.title}</span>
          </button>
        ))}
      </div>
    </aside>
  );
}
