# تغییرات ۱.۱.۰ نسبت به ۱.۰.۰

- یک نقطهٔ آغاز مستقل و جامع برای بیلدر: `START_HERE_BUILDER.fa.md`؛ همراه نسخهٔ تکیِ همان بایت‌ها.
- تبدیل پیشنهادهای ابزار به تصمیم روشن: Penpot انتخاب طراحی، Excalidraw اختیاری، Storybook opt-in و Style Dictionary فعلاً defer؛ استک runtime موجود بدون dependency جدید.
- ثبت منبع رسمی، license source pin، blob/hash و تصمیم استفاده برای دوازده ابزار؛ منبع مجوز، نسخهٔ نصب مصوب نیست. GrapesJS فقط core و مجوز BSD آن است؛ detection کل repository به‌تنهایی مبنا نشده است.
- گردش طراحی تا handoff با خروجی/معیار هر مرحله؛ قالب inventory، قرارداد خرد، stateهای component و نگاشت دستی token.
- افزودن رونوشت دقیق طرح ۵۰ parent، هویت شناسه‌ها، D-register و review تاریخی PWA-00 با provenance/hash؛ هیچ شناسه/عنوان/AC بازنویسی نشده است.
- فلو شروع SVG/Mermaid و بخش انتخاب ابزار در preview آفلاین؛ بدون ادعای ساخت فایل Penpot یا نصب Storybook.
- راهنمای دریافت، فایل Markdown تکی و کانال Download موقت محیط برای پرهیز از لینک نسبیِ نامعتبر در متن گفتگو.
- کنترل‌های فایل/پیوند/هویت/مجوز و تست‌های رگرسیون نسخهٔ تازه؛ گزارش‌های قبلی به‌جای اجرای تازه فروخته نمی‌شوند. مرز نتایج در VERIFICATION ثبت می‌شود.

**بدون تغییر:** کد/dep/workflow محصول، نقش/grant/DB، Flutter/Android/Flutter Web/Electron، auth/offline/payment و مجوز release. سقف تلاش/بودجهٔ تاریخی PWA-00 reset نشده و گیت/تست تضعیف نشده است. UI kit ۱.۰.۰ و ZIP اصلی PWA v2 منجمد و دست‌نخورده‌اند. نسخهٔ جدید در GitHub push یا publish نشده است.
