"use client";

import { useState } from "react";
import type { Improvement } from "@/lib/roadmap-data";

interface ImprovementCardProps {
  improvement: Improvement;
}

const PRIORITY_CONFIG = {
  critical: { label: "حیاتی", color: "text-red-400", bg: "bg-red-500/10 border-red-500/30" },
  high: { label: "بالا", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/30" },
  medium: { label: "متوسط", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/30" },
  low: { label: "پایین", color: "text-green-400", bg: "bg-green-500/10 border-green-500/30" },
};

const EFFORT_CONFIG = {
  low: { label: "آسان", icon: "🟢" },
  medium: { label: "متوسط", icon: "🟡" },
  high: { label: "دشوار", icon: "🔴" },
};

const CATEGORY_CONFIG = {
  performance: { label: "کارایی", icon: "⚡" },
  architecture: { label: "معماری", icon: "🏗️" },
  ux: { label: "تجربه کاربری", icon: "✨" },
  ai: { label: "هوش مصنوعی", icon: "🤖" },
  dx: { label: "توسعه‌دهنده", icon: "🛠️" },
  security: { label: "امنیت", icon: "🔐" },
};

export default function ImprovementCard({ improvement }: ImprovementCardProps) {
  const [expanded, setExpanded] = useState(false);
  const priority = PRIORITY_CONFIG[improvement.priority];
  const effort = EFFORT_CONFIG[improvement.effort];
  const category = CATEGORY_CONFIG[improvement.category];

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-gray-700 transition-all">
      <div
        className="p-5 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className={`text-xs border rounded-full px-2 py-0.5 ${priority.bg} ${priority.color}`}>
                {priority.label}
              </span>
              <span className="text-xs bg-gray-800 text-gray-400 rounded-full px-2 py-0.5">
                {category.icon} {category.label}
              </span>
              <span className="text-xs bg-gray-800 text-gray-400 rounded-full px-2 py-0.5">
                {effort.icon} {effort.label}
              </span>
            </div>
            <h4 className="font-bold text-white text-base">{improvement.title}</h4>
            <p className="text-gray-400 text-sm mt-1">{improvement.description}</p>
          </div>
          <button
            className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-lg bg-gray-800 text-gray-400 transition-transform ${expanded ? "rotate-180" : ""}`}
          >
            ▾
          </button>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-gray-800 p-5 bg-gray-900/50">
          <h5 className="text-sm font-semibold text-gray-300 mb-3">مراحل پیاده‌سازی:</h5>
          <ol className="space-y-2">
            {improvement.details.map((detail, i) => (
              <li key={i} className="flex items-start gap-3 text-sm">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold">
                  {i + 1}
                </span>
                <span className="text-gray-300 leading-relaxed">{detail}</span>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
