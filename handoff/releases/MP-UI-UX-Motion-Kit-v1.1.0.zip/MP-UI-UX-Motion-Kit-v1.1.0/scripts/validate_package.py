#!/usr/bin/env python3
"""Portable, read-only kit integrity/design-contract check. NOT MP/product QA.
No network, subprocess, package installation, product checkout, or archive extraction.
A self-contained manifest detects drift, not authenticity/signature or independent review.
"""
from __future__ import annotations
import base64
import csv
import hashlib
import json
import re
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'node_modules', '.kit-build', '__pycache__', '.git', '.cache', '.DS_Store'}


def safe_relative(value: str) -> PurePosixPath:
    if not value or '\\' in value or '\0' in value or ':' in value:
        raise ValueError('unsafe manifest path')
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in ('', '..', '.') for part in value.split('/')):
        raise ValueError('unsafe manifest path')
    return path


def contrast(a: str, b: str) -> float:
    def luminance(value: str) -> float:
        channels = [int(value[i:i+2], 16)/255 for i in (1, 3, 5)]
        linear = [x/12.92 if x <= 0.04045 else ((x+0.055)/1.055)**2.4 for x in channels]
        return sum(x*w for x, w in zip(linear, [0.2126, 0.7152, 0.0722]))
    low, high = sorted([luminance(a), luminance(b)])
    return (high+0.05)/(low+0.05)


class Document(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.links = []
        self.script = ''
        self.in_script = False
        self.script_count = 0
        self.csp = ''
        self.lang = None
        self.direction = None
        self.external = []
        self.external_scripts = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag == 'html':
            self.lang, self.direction = attrs.get('lang'), attrs.get('dir')
        if tag == 'script':
            self.in_script = True
            self.script_count += 1
            if 'src' in attrs:
                self.external_scripts.append(attrs['src'])
        if tag == 'meta' and attrs.get('http-equiv', '').lower() == 'content-security-policy':
            self.csp = attrs.get('content', '')
        for key in ['src', 'href']:
            if key in attrs:
                value = attrs[key]
                if value.startswith(('http:', 'https:', '//')):
                    self.external.append(value)
                if key == 'href':
                    self.links.append(value)

    def handle_endtag(self, tag):
        if tag == 'script':
            self.in_script = False

    def handle_data(self, data):
        if self.in_script:
            self.script += data


EXPECTED_REFERENCE_HASHES = {'references/SOURCE_PLAN.fa.md': 'f05412e24d5faea5df8af73f324ec22958990688fdd3ae0917d001b09dbf9583', 'references/PLAN_IDENTITY.json': '710fd7ee05b22f9bb39223b977850034d0003bb5d41c6c7f6e7f0fa46d8f4dee', 'references/DECISION_REGISTER.json': '54bc23e703039c4ce24fa4d8d7d91bbc27994e818311852ff811e0297fdc87d1', 'references/PWA-00-REVIEW-2026-11-24.fa.source.txt': '542a3189cc5e2e96fbe251f36950d9765273ff350ff1d1245d474637dbfbc917'}
EXPECTED_TOOL_DECISIONS = {
    'penpot/penpot': ('MPL-2.0', 'SELECTED_DESIGN_EXTERNAL'),
    'excalidraw/excalidraw': ('MIT', 'OPTIONAL_FLOW_EXTERNAL'),
    'storybookjs/storybook': ('MIT', 'OPTIONAL_DEV_TOOL_AFTER_APPROVAL'),
    'style-dictionary/style-dictionary': ('Apache-2.0', 'DEFER_UNTIL_TOKEN_PIPELINE_GAP'),
    'ant-design/ant-design': ('MIT', 'EXISTING_REUSE_NO_UPGRADE'),
    'mantinedev/mantine': ('MIT', 'ALTERNATIVE_NOT_SELECTED'),
    'shadcn-ui/ui': ('MIT', 'ALTERNATIVE_NOT_SELECTED'),
    'radix-ui/primitives': ('MIT', 'ALTERNATIVE_NOT_SELECTED'),
    'tailwindlabs/tailwindcss': ('MIT', 'EXISTING_REUSE_NO_UPGRADE'),
    'motiondivision/motion': ('MIT', 'EXISTING_REUSE_NO_MIGRATION'),
    'puckeditor/puck': ('MIT', 'FUTURE_ONLY_NOT_SELECTED'),
    'GrapesJS/grapesjs': ('BSD-3-Clause', 'FUTURE_ONLY_NOT_SELECTED'),
}


def check_v11_contracts(root: Path) -> tuple[list[str], dict]:
    problems = []
    metrics = {}
    for name, digest in EXPECTED_REFERENCE_HASHES.items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest() != digest:
            problems.append('canonical/historical reference changed: '+name)
    baseline = json.loads((root/'references/PWA_BASELINE.json').read_text(encoding='utf-8'))
    if {entry['path']: entry['sha256'] for entry in baseline['files']} != EXPECTED_REFERENCE_HASHES:
        problems.append('historical provenance changed')
    source = (root/'references/SOURCE_PLAN.fa.md').read_text(encoding='utf-8')
    rows = re.findall(r'^\| (PWA-[0-9A-F]{2}) \| (.*?) \| (.*?) \|$', source, re.M)
    identity = json.loads((root/'references/PLAN_IDENTITY.json').read_text(encoding='utf-8'))
    ids = [row[0] for row in rows]
    if len(rows) != 50 or ids != identity['expected_task_ids'] or [sum(x.startswith('PWA-'+str(i)) for x in ids) for i in range(6)] != [6, 8, 5, 16, 8, 7]:
        problems.append('canonical 50 rows/identities changed')
    metrics['canonical_parents'] = len(rows)
    decisions = json.loads((root/'references/DECISION_REGISTER.json').read_text(encoding='utf-8'))['decisions']
    if [entry['id'] for entry in decisions] != [f'D-{i:02d}' for i in range(1, 12)] or any(entry['status'] != 'DECISION' or entry['owner_response'] is not None for entry in decisions):
        problems.append('historical decisions misrepresented')
    tools = json.loads((root/'references/OPEN_SOURCE_TOOLS.json').read_text(encoding='utf-8'))
    if tools['kit_version'] != '1.1.0' or tools['product_runtime_additions'] or tools['paid_or_cloud_service_approval'] is not False:
        problems.append('tool catalogue implies unapproved installation/egress')
    entries = tools['tools']
    if len(entries) != 12 or {entry['repository'] for entry in entries} != set(EXPECTED_TOOL_DECISIONS):
        problems.append('expected 12 upstream tools')
    for entry in entries:
        repo = entry['repository']
        if (entry['license_spdx'], entry['decision']) != EXPECTED_TOOL_DECISIONS.get(repo):
            problems.append('tool license/decision changed: '+repo)
        if entry['automatic_install'] is not False or entry['new_install_performed_in_MP'] is not False:
            problems.append('tool catalogue implies unapproved installation/egress')
        path = safe_relative(entry['license_source_path']).as_posix()
        commit = entry['source_commit']
        if not re.fullmatch('[0-9a-f]{40}', commit) or not re.fullmatch('[0-9a-f]{40}', entry['license_git_blob']) or not re.fullmatch('[0-9a-f]{64}', entry['license_sha256']) or entry['url'] != 'https://github.com/'+repo or entry['license_url'] != f'https://github.com/{repo}/blob/{commit}/{path}':
            problems.append('tool license provenance malformed: '+repo)
    metrics['upstream_tools'] = len(entries)
    start = (root/'START_HERE_BUILDER.fa.md').read_text(encoding='utf-8')
    if {int(n) for n in re.findall(r'\bG([1-9])-', start)} != set(range(1, 10)) or any(term not in start for term in ['PWA-00', 'PWA-3F', 'PWA-12', 'PWA-13', 'READY-FOR-OWNER', 'NOT_RUN', 'member', 'coach', 'reception', 'manager', 'admin', 'super_admin']):
        problems.append('builder entry missing core scope/gate context')
    tokens = json.loads((root/'TOKENS.json').read_text(encoding='utf-8'))
    package = json.loads((root/'package.json').read_text(encoding='utf-8'))
    lock = json.loads((root/'package-lock.json').read_text(encoding='utf-8'))
    if [tokens['package_version'], package['version'], lock['version'], lock['packages']['']['version']] != ['1.1.0']*4:
        problems.append('package version drift')
    with (root/'templates/DESIGN_TOKEN_MAPPING.csv').open(encoding='utf-8', newline='') as stream:
        mapping = list(csv.DictReader(stream))
    for entry in mapping:
        value = tokens
        for key in entry['kit_path'].split('.'):
            value = value[key]
        if str(value) != entry['source_value'] or entry['status'] != 'PROPOSED_MANUAL_MAPPING_NOT_IMPORT_TESTED':
            problems.append('token mapping drift/overclaim')
    metrics['proposed_token_mappings'] = len(mapping)
    return problems, metrics


def check(root: Path = ROOT) -> dict:
    root = root.resolve()
    problems = []
    ratios = {}
    metrics = {'manifest_files': 0, 'local_links_checked': 0, 'screen_matrix_rows': 0}
    try:
        manifest = json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
        if manifest['version'] != '1.1.0' or manifest['scope'] != 'KIT_ONLY_NOT_PRODUCT_QA':
            problems.append('unexpected manifest identity')
        listed = set()
        for entry in manifest['files']:
            relative = safe_relative(entry['path'])
            name = relative.as_posix()
            if name in listed:
                raise ValueError('duplicate manifest path')
            listed.add(name)
            path = root/name
            if any((root/Path(*relative.parts[:i])).is_symlink() for i in range(1, len(relative.parts)+1)):
                raise ValueError('symlink in manifest')
            data = path.read_bytes()
            if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                problems.append('digest/size mismatch: '+name)
        actual = set()
        for path in root.rglob('*'):
            relative = path.relative_to(root)
            if any(part in EXCLUDED for part in relative.parts) or path.suffix == '.pyc':
                continue
            if path.is_symlink():
                raise ValueError('symlink in kit')
            if path.is_file() and path != root/'PACKAGE_MANIFEST.json':
                actual.add(relative.as_posix())
        if actual != listed:
            problems.append('manifest inventory mismatch')
        metrics['manifest_files'] = len(listed)

        tokens = json.loads((root/'TOKENS.json').read_text(encoding='utf-8'))
        source = json.loads((root/'references/MP_SOURCE.json').read_text(encoding='utf-8'))
        package = json.loads((root/'package.json').read_text(encoding='utf-8'))
        lock = json.loads((root/'package-lock.json').read_text(encoding='utf-8'))
        if tokens['source_commit'] != source['commit'] or source['commit'] != '0e69b56dd0c427e45f2c104613cc420ea1a8c49f':
            problems.append('source pin mismatch')
        if tokens['new_product_dependencies'] or package.get('dependencies') or package['private'] is not True:
            problems.append('unexpected product runtime dependency')
        for name, version in package['devDependencies'].items():
            identity = source['locked_packages'][name]
            entry = lock['packages']['node_modules/'+name]
            if version != identity['version'] or entry['version'] != version or entry['integrity'] != identity['integrity']:
                problems.append('validation dependency diverges from observed lock: '+name)
        motion = tokens['motion']
        if motion['protectedContentExitDelayMs'] != 0 or motion['financialCountUp'] or motion['defaultInfiniteLoops'] or motion['defaultListStagger']:
            problems.append('unsafe motion proposal')

        html = (root/'preview/index.html').read_text(encoding='utf-8')
        doc = Document()
        doc.feed(html)
        if doc.lang != 'fa' or doc.direction != 'rtl' or len(doc.ids) != len(set(doc.ids)):
            problems.append('HTML language/direction/anchors')
        if doc.external or doc.external_scripts or doc.script_count != 1:
            problems.append('external HTML resource/script or unexpected script count')
        digest = base64.b64encode(hashlib.sha256(doc.script.encode()).digest()).decode()
        if "script-src 'sha256-"+digest+"'" not in doc.csp or "connect-src 'none'" not in doc.csp:
            problems.append('CSP/script binding')
        if re.search(r'\b(fetch|XMLHttpRequest|WebSocket|localStorage|sessionStorage|indexedDB|caches|serviceWorker)\b', doc.script):
            problems.append('unexpected preview data access primitive')
        if re.search(r'@@[A-Z]+@@', html) or re.search(r'url\([\s\"\x27]*(?:https?:|//)', html, re.I):
            problems.append('unresolved preview token or external CSS resource')
        for link in doc.links:
            parts = urlsplit(link)
            if not parts.path:
                if parts.fragment and unquote(parts.fragment) not in doc.ids:
                    problems.append('broken HTML anchor')
                continue
            target = (root/'preview'/unquote(parts.path)).resolve()
            metrics['local_links_checked'] += 1
            if not target.is_relative_to(root) or not target.is_file():
                problems.append('broken/escaping local HTML link')
        # Check local Markdown destinations without attempting external network validation.
        for name in sorted(name for name in listed if name.endswith('.md')):
            path = root/name
            for link in re.findall(r'\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)', path.read_text(encoding='utf-8')):
                parts = urlsplit(link)
                if parts.scheme or parts.netloc or not parts.path:
                    continue
                target = (path.parent/unquote(parts.path)).resolve()
                metrics['local_links_checked'] += 1
                if not target.is_relative_to(root) or not target.is_file():
                    problems.append('broken/escaping local Markdown link: '+path.name)

        for stem in ['arabic', 'latin']:
            if not (root/f'assets/fonts/vazirmatn-{stem}-wght-normal.woff2').read_bytes().startswith(b'wOF2'):
                problems.append('invalid font header')
        if 'SIL OPEN FONT LICENSE Version 1.1' not in (root/'assets/fonts/OFL.txt').read_text(encoding='utf-8'):
            problems.append('font license missing')
        pairs = [('body', 'text', 'surface'), ('secondary', 'secondary', 'surface'), ('primary_label', 'primaryInk', 'primary'), ('focus_on_background', 'focus', 'background')]
        raw_ratios = {name: contrast(tokens['colors'][fg], tokens['colors'][bg]) for name, fg, bg in pairs}
        ratios = {name: round(value, 2) for name, value in raw_ratios.items()}
        if any(value < 4.5 for value in raw_ratios.values()):
            problems.append('proposed palette pair contrast below 4.5')

        for record in ['RECIPE_CHECK.json', 'BROWSER_CHECK.json']:
            report = json.loads((root/'references'/record).read_text(encoding='utf-8'))
            for name, digest in report['bindings'].items():
                relative = safe_relative(name)
                if hashlib.sha256((root/relative.as_posix()).read_bytes()).hexdigest() != digest:
                    problems.append('stale evidence binding: '+record)
            if record == 'BROWSER_CHECK.json':
                if report['status'] != 'KIT_BROWSER_SMOKE_PASS_NOT_PRODUCT_QA' or not report['cases'] or any(case['status'] != 'PASS' for case in report['cases']):
                    problems.append('browser smoke not passed')
            elif report['status'] != 'KIT_RECIPE_CHECK_PASS_NOT_PRODUCT_QA' or report['tests']['passed'] <= 0 or report['tests']['failed'] or report['tests']['skipped']:
                problems.append('recipe tests not passed')
        with (root/'SCREEN_MATRIX.csv').open(encoding='utf-8', newline='') as stream:
            rows = list(csv.DictReader(stream))
        metrics['screen_matrix_rows'] = len(rows)
        if len(rows) != 25:
            problems.append('screen matrix is not 25 rows')
        expected_member = {'PWA-3'+suffix for suffix in '0123456789ABCDEF'}
        expected_staff = {'PWA-4'+suffix for suffix in '01234567'}
        if {row['parent_ids_unchanged'] for row in rows if row['scope'] == 'member'} != expected_member or {row['parent_ids_unchanged'] for row in rows if row['scope'] == 'staff'} != expected_staff:
            problems.append('canonical member/staff mapping changed')
        if any(row['evidence_status'] != 'PROPOSED_MAPPING_NOT_PRODUCT_QA' for row in rows):
            problems.append('mapping overclaims product evidence')
        extra_problems, extra_metrics = check_v11_contracts(root)
        problems.extend(extra_problems)
        metrics.update(extra_metrics)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        problems.append(type(error).__name__+': '+str(error))
    return {
        'status': 'KIT_OK_NOT_PRODUCT_QA' if not problems else 'KIT_INVALID',
        'problems': problems,
        'scope': 'archive/source/evidence/design-contract only; NOT MP behavior, device QA, independent review, authorization or release',
        'metrics': metrics,
        'palette_pair_contrast_not_full_accessibility_audit': ratios,
    }


if __name__ == '__main__':
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not result['problems'] else 2)
