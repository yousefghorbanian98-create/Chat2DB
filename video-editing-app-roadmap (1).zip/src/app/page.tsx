"use client";

import { useState } from "react";
import { phases, generalImprovements, quickWins } from "@/lib/roadmap-data";
import PhaseCard from "@/components/PhaseCard";
import LibraryCard from "@/components/LibraryCard";
import ImprovementCard from "@/components/ImprovementCard";
import GeneralSection from "@/components/GeneralSection";
import QuickWins from "@/components/QuickWins";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";

export default function Home() {
  const [activePhase, setActivePhase] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "phase" | "general" | "quickwins">("overview");
  const [selectedPhaseId, setSelectedPhaseId] = useState<number>(1);

  const selectedPhase = phases.find((p) => p.id === selectedPhaseId);

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <Header />

      {/* Navigation Tabs */}
      <div className="sticky top-0 z-40 bg-gray-950/95 backdrop-blur border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1 py-2 overflow-x-auto scrollbar-hide">
            {[
              { id: "overview", label: "نقشه راه", icon: "🗺️" },
              { id: "phase", label: "جزئیات فاز", icon: "📋" },
              { id: "general", label: "پیشنهادات عمومی", icon: "💡" },
              { id: "quickwins", label: "اقدامات سریع", icon: "⚡" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? "bg-indigo-600 text-white"
                    : "text-gray-400 hover:text-white hover:bg-gray-800"
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Hero */}
            <div className="text-center space-y-4 py-8">
              <div className="inline-flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/30 rounded-full px-4 py-1.5 text-indigo-400 text-sm font-medium mb-4">
                <span className="w-2 h-2 rounded-full bg-indigo-400 pulse-glow inline-block"></span>
                Cutting Edge — AI Video Studio
              </div>
              <h1 className="text-4xl md:text-5xl font-bold">
                <span className="gradient-text">نقشه راه توسعه</span>
              </h1>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                تحلیل کامل پروژه، پیشنهادات بهبود و کتابخانه‌های اوپن‌سورس برای رسیدن به اهداف ۷ فاز
              </p>
              <div className="flex flex-wrap justify-center gap-3 mt-4">
                <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg px-3 py-1.5 text-sm">
                  <span>⚛️</span>
                  <span className="text-gray-300">React + Electron</span>
                </div>
                <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg px-3 py-1.5 text-sm">
                  <span>🐍</span>
                  <span className="text-gray-300">FastAPI + Python</span>
                </div>
                <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg px-3 py-1.5 text-sm">
                  <span>🎬</span>
                  <span className="text-gray-300">FFmpeg + AI</span>
                </div>
                <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg px-3 py-1.5 text-sm">
                  <span>📦</span>
                  <span className="text-gray-300">Zustand + TanStack Query</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "فاز توسعه", value: "۷", icon: "🎯", color: "text-indigo-400" },
                { label: "کتابخانه اوپن‌سورس", value: "۴۰+", icon: "📦", color: "text-purple-400" },
                { label: "پیشنهاد بهبود", value: "۲۵+", icon: "💡", color: "text-yellow-400" },
                { label: "اقدام سریع", value: "۸", icon: "⚡", color: "text-green-400" },
              ].map((stat) => (
                <div key={stat.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center card-hover">
                  <div className="text-3xl mb-2">{stat.icon}</div>
                  <div className={`text-3xl font-bold ${stat.color}`}>{stat.value}</div>
                  <div className="text-gray-400 text-sm mt-1">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Current Stack Analysis */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <span>🔍</span>
                تحلیل Stack فعلی
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-green-400 font-semibold mb-3 flex items-center gap-2">
                    <span>✅</span> نقاط قوت
                  </h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    {[
                      "model.ts بسیار خوب طراحی شده — undo/redo، commit pattern، pure functions",
                      "Timeline.tsx پیاده‌سازی حرفه‌ای با centred mode و pinch-to-zoom",
                      "Backend با FastAPI و WebSocket برای real-time progress",
                      "i18n آماده با پشتیبانی RTL فارسی",
                      "Faster-Whisper و MediaPipe از قبل در requirements",
                      "Auto-update با electron-updater پیاده‌سازی شده",
                      "Differential packaging برای به‌روزرسانی سریع‌تر",
                      "Film Strip در Timeline — نمایش تصویری کلیپ‌ها",
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <span className="text-green-400 mt-0.5 flex-shrink-0">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-yellow-400 font-semibold mb-3 flex items-center gap-2">
                    <span>⚠️</span> فرصت‌های بهبود
                  </h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    {[
                      "Keyframe animation هنوز وجود ندارد — بزرگ‌ترین gap",
                      "Waveform در audio track نمایش داده نمی‌شود",
                      "Proxy video برای کلیپ‌های سنگین نیاز است",
                      "Unit test برای model.ts وجود ندارد",
                      "Crash reporter پیاده‌سازی نشده",
                      "Memoization در Timeline components ضعیف است",
                      "State در restart برنامه از دست می‌رود (persist نیست)",
                      "نصب‌کننده احتمالاً بزرگ‌تر از ۱۲۰MB است",
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <span className="text-yellow-400 mt-0.5 flex-shrink-0">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Phase Cards Grid */}
            <div>
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <span>🗺️</span>
                فازهای توسعه
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {phases.map((phase) => (
                  <PhaseCard
                    key={phase.id}
                    phase={phase}
                    onClick={() => {
                      setSelectedPhaseId(phase.id);
                      setActiveTab("phase");
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-r from-indigo-600/20 to-purple-600/20 border border-indigo-500/30 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-2">🚀 از کجا شروع کنم؟</h2>
              <p className="text-gray-400 text-sm mb-4">اگر وقت محدود دارید، این ۳ کار بیشترین تاثیر را دارند:</p>
              <div className="grid md:grid-cols-3 gap-4">
                {[
                  {
                    step: "۱",
                    title: "Zustand Persist",
                    desc: "State از بین نرود — ۳۰ دقیقه کار",
                    color: "bg-blue-500/20 border-blue-500/40",
                  },
                  {
                    step: "۲",
                    title: "Waveform + Proxy",
                    desc: "UX timeline را متحول می‌کند — ۱ روز کار",
                    color: "bg-purple-500/20 border-purple-500/40",
                  },
                  {
                    step: "۳",
                    title: "Keyframe Engine",
                    desc: "بزرگ‌ترین Feature gap — ۲ هفته کار",
                    color: "bg-pink-500/20 border-pink-500/40",
                  },
                ].map((item) => (
                  <div key={item.step} className={`${item.color} border rounded-xl p-4`}>
                    <div className="text-2xl font-bold text-white mb-1">مرحله {item.step}</div>
                    <div className="text-white font-semibold">{item.title}</div>
                    <div className="text-gray-300 text-sm mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Phase Detail Tab */}
        {activeTab === "phase" && (
          <div className="space-y-6">
            {/* Phase selector */}
            <div className="flex flex-wrap gap-2">
              {phases.map((phase) => (
                <button
                  key={phase.id}
                  onClick={() => setSelectedPhaseId(phase.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    selectedPhaseId === phase.id
                      ? `${phase.bgColor} ${phase.color} border ${phase.borderColor}`
                      : "bg-gray-800 text-gray-400 hover:text-white border border-gray-700"
                  }`}
                >
                  <span>{phase.emoji}</span>
                  <span>فاز {phase.id}</span>
                </button>
              ))}
            </div>

            {selectedPhase && (
              <div className="space-y-6">
                {/* Phase Header */}
                <div className={`${selectedPhase.bgColor} border ${selectedPhase.borderColor} rounded-2xl p-6`}>
                  <div className="flex items-start gap-4">
                    <div className="text-5xl">{selectedPhase.emoji}</div>
                    <div className="flex-1">
                      <h2 className={`text-2xl font-bold ${selectedPhase.color}`}>
                        فاز {selectedPhase.id} — {selectedPhase.title}
                      </h2>
                      <p className="text-gray-300 mt-2">{selectedPhase.description}</p>
                    </div>
                  </div>

                  {/* Goals */}
                  <div className="mt-6">
                    <h3 className="text-white font-semibold mb-3">اهداف این فاز:</h3>
                    <div className="grid md:grid-cols-2 gap-2">
                      {selectedPhase.goals.map((goal) => (
                        <div key={goal} className="flex items-center gap-2 text-sm text-gray-300">
                          <span className={`${selectedPhase.color} flex-shrink-0`}>◆</span>
                          {goal}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Tips */}
                  <div className="mt-4 border-t border-white/10 pt-4">
                    <h3 className="text-white font-semibold mb-3">💡 نکات کلیدی:</h3>
                    <div className="space-y-2">
                      {selectedPhase.tips.map((tip) => (
                        <div key={tip} className="flex items-start gap-2 text-sm text-gray-300">
                          <span className="text-yellow-400 flex-shrink-0 mt-0.5">→</span>
                          {tip}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Libraries */}
                <div>
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <span>📦</span>
                    کتابخانه‌های پیشنهادی ({selectedPhase.libs.length})
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {selectedPhase.libs.map((lib) => (
                      <LibraryCard key={lib.name} lib={lib} />
                    ))}
                  </div>
                </div>

                {/* Improvements */}
                <div>
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <span>🔧</span>
                    پیشنهادات بهبود ({selectedPhase.improvements.length})
                  </h3>
                  <div className="space-y-4">
                    {selectedPhase.improvements.map((imp) => (
                      <ImprovementCard key={imp.id} improvement={imp} />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* General Improvements Tab */}
        {activeTab === "general" && (
          <div className="space-y-6">
            <div className="text-center py-4">
              <h2 className="text-2xl font-bold text-white">پیشنهادات بهبود عمومی</h2>
              <p className="text-gray-400 mt-2">بهبودهایی که در تمام فازها کاربرد دارند</p>
            </div>
            <GeneralSection improvements={generalImprovements} />
          </div>
        )}

        {/* Quick Wins Tab */}
        {activeTab === "quickwins" && (
          <div className="space-y-6">
            <div className="text-center py-4">
              <h2 className="text-2xl font-bold text-white">⚡ اقدامات سریع</h2>
              <p className="text-gray-400 mt-2">کارهایی که با کمترین زمان بیشترین تاثیر را دارند</p>
            </div>
            <QuickWins wins={quickWins} />
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-6 text-center text-gray-500 text-sm">
        <p>Cutting Edge — راهنمای توسعه | ساخته شده برای Yousef Ghorbanian</p>
      </footer>
    </div>
  );
}
