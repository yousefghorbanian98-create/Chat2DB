# Muscle Paradise — بستهٔ UI / UX / Motion و شروع بیلدر ۱.۱.۰

**از [START_HERE_BUILDER.fa.md](START_HERE_BUILDER.fa.md) شروع کن.** این Markdown برای بیلدرِ بدون تاریخچه نوشته شده و نسخهٔ تکی آن نیز کنار ZIP تحویل داده می‌شود. لینک‌های نسبی نسخهٔ تکی پس از استخراج بسته معتبرند.

## انتخاب نهایی، نه فهرست نصب

- **طراحی بصری:** Penpot، بیرون runtime محصول.
- **flow/wireframe:** Excalidraw اختیاری.
- **پیاده‌سازی:** همان Ant Design + `framer-motion` + CSS بومی + Vazirmatn محلی موجود.
- **کاتالوگ اجزا:** Storybook اختیاری، فقط پس از نیاز/قرارداد و بررسی سازگاری.
- **pipeline توکن:** Style Dictionary فعلاً defer؛ فایل TOKENS این کیت ورودی آمادهٔ DTCG یا Penpot نیست.
- **صفر dependency جدید runtime محصول.** Mantine/shadcn/Radix، UI موازی و Puck/GrapesJS برای هستهٔ اپ انتخاب نشده‌اند.

این کیت، source محصول یا یک اپ React دوم نیست. هیچ Penpot/Storybook/Style Dictionary، dependency، نقش، workflow، سرور یا کد MP با آن نصب/تغییر نشده است. توصیه‌ها `PROPOSED` هستند؛ تست خود کیت، G9 مستقل، human approval یا QA محصول نیست.

## محتویات اصلی

| فایل | استفاده |
|---|---|
| [START_HERE_BUILDER.fa.md](START_HERE_BUILDER.fa.md) | هدف، وضعیت تاریخی، منابع، قرارداد، نقطهٔ شروع و گزارش بعدی |
| [OPEN_SOURCE_TOOLS.fa.md](OPEN_SOURCE_TOOLS.fa.md) | ۱۲ ابزار با مجوز/pin/منبع رسمی و تصمیم استفاده |
| [DESIGN_WORKFLOW.fa.md](DESIGN_WORKFLOW.fa.md) | خروجی هر مرحلهٔ طراحی، handoff و شرط ورود ابزار اختیاری |
| [STACK_DECISION.fa.md](STACK_DECISION.fa.md) / [UX_MOTION_SPEC.fa.md](UX_MOTION_SPEC.fa.md) | reuse استک و قواعد RTL، motion، فرم، نشست و رسید |
| [SCREEN_MATRIX.csv](SCREEN_MATRIX.csv) / [TOKENS.json](TOKENS.json) | نگاشت ۲۵ دامنه و مقادیر پیشنهادی |
| [preview/index.html](preview/index.html) | پیش‌نمایش فارسی/RTL خودبسنده؛ فقط دادهٔ مصنوعی؛ بدون CDN/API/storage |
| [templates/UI_MOTION_INVENTORY.fa.md](templates/UI_MOTION_INVENTORY.fa.md) | اولین artifact خواندنی پیشنهادی |
| [templates/MICROTASK_CONTRACT.fa.md](templates/MICROTASK_CONTRACT.fa.md) | قرارداد یک GAP، نه مجوز اجرای خودکار |
| [templates/DESIGN_TOKEN_MAPPING.csv](templates/DESIGN_TOKEN_MAPPING.csv) | راهنمای نگاشت دستی توکن؛ نه ادعای import آزمایش‌شده |
| [templates/COMPONENT_STATES.csv](templates/COMPONENT_STATES.csv) | stateهایی که طراحی/Storybook آینده باید پوشش دهد |
| [diagrams/BUILDER_START_FLOW.fa.svg](diagrams/BUILDER_START_FLOW.fa.svg) | فلو شروع؛ نسخهٔ Mermaid هم همراه است |
| [references/SOURCE_PLAN.fa.md](references/SOURCE_PLAN.fa.md) | ۵۰ شناسه/عنوان/AC canonical، بدون بازنویسی |
| [VERIFICATION.fa.md](VERIFICATION.fa.md) | نتایج اجراشده، provenance و NOT_RUNهای محصول |
| [DOWNLOAD_HELP.fa.md](DOWNLOAD_HELP.fa.md) | دریافت فایل و مرز لینک موقت محیط |

## زمینه‌ای که نباید از دست برود

همان `mp-app/studio/` یک PWA مشترک member/staff می‌شود؛ Flutter/Android/Flutter Web، Electron، history/docs/tests/CI حفظ می‌شوند. شش نقش backend، مجوز سرور، DB، session/storage، offline، پرداخت و release تصمیم‌های مستقل‌اند. PWA-3F مشروط/BLOCKED پیش‌فرض، upload≠bank approval و unknown≠zero باقی می‌مانند.

مرجع جدیدی برای جایگزینی طرح ۵۰کارتی نساخته‌ایم. رونوشت دقیق canonical plan، هویت ۵۰ شناسه، رجیستر تاریخی Dها و review تاریخی PWA-00 در `references/` با هش آمده‌اند. [PWA_BASELINE.json](references/PWA_BASELINE.json) هویت منبع را مشخص می‌کند. گزارش historical به معنی وضعیت زندهٔ بیلدر یا approval تازه نیست؛ وضعیت جاری و بودجهٔ مصرف‌شده باید در محیط خود بیلدر تطبیق داده شوند.

## بررسی محلی، بدون نصب

از ریشهٔ استخراج‌شده، Python 3.10+:

```bash
python3 scripts/validate_package.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

`scripts/check_archive.py` مسیر ZIP را برای CRC/manifest/hash می‌گیرد و اگر `.sha256` کنارش باشد آن را هم تطبیق می‌دهد. `scripts/build_package.py --check` فایل‌های تولیدی را read-only بررسی می‌کند. سلامت داخلی فایل‌ها امضای ناشر نیست.

برای **validation اختیاری recipeهای خود کیت** و فقط داخل همین پوشه، بعد از خواندن manifest/lock:

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck
npm test
```

این فرمان نصب محصول، دستور upgrade یا جایگزین build/lint/test در checkout MP نیست. node_modules، باینری مرورگر و ابزارهای تست در ZIP نیستند. فونت‌های محلی و مجوز کاملشان همراه‌اند؛ [THIRD_PARTY_NOTICES.fa.md](THIRD_PARTY_NOTICES.fa.md).

نسخهٔ قبلی ۱.۰.۰ و هندآف اصلی v2 تغییر نکرده‌اند. برای تفاوت‌ها [CHANGELOG.fa.md](CHANGELOG.fa.md) را بخوان.
