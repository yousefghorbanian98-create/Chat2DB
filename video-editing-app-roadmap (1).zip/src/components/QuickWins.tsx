"use client";

interface QuickWin {
  title: string;
  desc: string;
  time: string;
  impact: string;
}

interface QuickWinsProps {
  wins: QuickWin[];
}

const IMPACT_CONFIG = {
  high: { label: "تاثیر بالا", color: "text-green-400", bg: "bg-green-500/10 border-green-500/30" },
  medium: { label: "تاثیر متوسط", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/30" },
  low: { label: "تاثیر پایین", color: "text-gray-400", bg: "bg-gray-500/10 border-gray-500/30" },
};

export default function QuickWins({ wins }: QuickWinsProps) {
  return (
    <div className="space-y-4">
      <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-xl p-4">
        <p className="text-indigo-300 text-sm">
          💡 این کارها را در هفته اول انجام دهید — سریع‌ترین مسیر به یک نسخه بهتر
        </p>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {wins.map((win, index) => {
          const impact = IMPACT_CONFIG[win.impact as keyof typeof IMPACT_CONFIG] ?? IMPACT_CONFIG.medium;
          return (
            <div
              key={win.title}
              className="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all card-hover"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-lg">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h4 className="font-bold text-white">{win.title}</h4>
                    <span className={`text-xs border rounded-full px-2 py-0.5 ${impact.bg} ${impact.color}`}>
                      {impact.label}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm mb-3 leading-relaxed">{win.desc}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>⏱️</span>
                    <span>زمان تخمینی: <span className="text-gray-300">{win.time}</span></span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Timeline view */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 mt-8">
        <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
          <span>📅</span>
          پیشنهاد برنامه‌ریزی
        </h3>
        <div className="space-y-4">
          {[
            {
              period: "هفته اول",
              tasks: ["Zustand Persist", "crash reporter", "Keyboard shortcuts"],
              color: "bg-blue-500",
              textColor: "text-blue-400",
              bg: "bg-blue-500/10 border-blue-500/30",
            },
            {
              period: "هفته دوم",
              tasks: ["Proxy Video", "Waveform در Audio Track", "Context Menu"],
              color: "bg-purple-500",
              textColor: "text-purple-400",
              bg: "bg-purple-500/10 border-purple-500/30",
            },
            {
              period: "هفته سوم-چهارم",
              tasks: ["Beat Detection", "Vitest برای model.ts", "rembg integration"],
              color: "bg-pink-500",
              textColor: "text-pink-400",
              bg: "bg-pink-500/10 border-pink-500/30",
            },
            {
              period: "ماه دوم",
              tasks: ["Keyframe Engine (اولویت اول)", "Auto-Reframe", "Demucs separation"],
              color: "bg-orange-500",
              textColor: "text-orange-400",
              bg: "bg-orange-500/10 border-orange-500/30",
            },
          ].map((week) => (
            <div key={week.period} className={`border ${week.bg} rounded-xl p-4`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-3 h-3 rounded-full ${week.color}`}></div>
                <h4 className={`font-semibold ${week.textColor}`}>{week.period}</h4>
              </div>
              <div className="flex flex-wrap gap-2 mr-6">
                {week.tasks.map((task) => (
                  <span key={task} className="text-sm bg-gray-800 text-gray-300 rounded-lg px-3 py-1">
                    {task}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
