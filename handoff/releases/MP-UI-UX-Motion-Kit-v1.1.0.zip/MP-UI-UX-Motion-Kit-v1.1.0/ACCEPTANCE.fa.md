# چک‌لیست پذیرش و مرز شواهد

این چک‌لیستِ استفادهٔ آینده است؛ علامت‌نخوردن سطرها نتیجهٔ fail نیست. نتیجه و حدود اجراهای واقعی همین نسخه در [VERIFICATION.fa.md](VERIFICATION.fa.md) ثبت شده؛ موارد محصول از آن نتیجه نمی‌شوند.

## سلامت همین بسته (قابل بررسی تکرارپذیر)

- [ ] archive/manifest/hash و مسیرها سالم؛ هیچ node_modules، باینری مرورگر، سورس اختصاصی MP یا دادهٔ خصوصی داخل ZIP نیست.
- [ ] preview بدون شبکه، API، storage و SW باز می‌شود؛ داده‌ها صریحاً مصنوعی‌اند.
- [ ] سه اندازهٔ 320/390/1440، RTL، target لمس، keyboard و reduced-motion در preview بررسی شوند.
- [ ] recipeها با React18/AntD5/FramerMotion11 و TypeScript strict کامپایل و تست شوند.
- [ ] منبع و provenance، مجوز فونت و محدودیت‌های QA روشن‌اند.
- [ ] START_HERE مستقل، رونوشت دقیق طرح ۵۰ parent و D-register تاریخی، سابقهٔ PWA-00 و بودجهٔ مصرف‌شده را بدون ادعای approval تازه توضیح می‌دهد.
- [ ] انتخاب ابزارها صریح است: Penpot بیرون runtime، Excalidraw اختیاری، Storybook مشروط، Style Dictionary فعلاً defer؛ صفر dependency تازهٔ runtime MP.
- [ ] Markdown تکی byte-identical با START_HERE داخل ZIP است؛ لینک‌های نسبی آن به ساختار استخراج‌شده نیاز دارند.
- [ ] routeهای ZIP/Markdown/SHA در صفحهٔ دانلود، attachment واقعی‌اند نه مسیر workspace؛ بایت‌های دانلودشده با فایل نهایی تطبیق دارند. عمر لینک محیط و مرز نبودِ انتشار GitHub روشن است.

## نه حوزهٔ هر زیرکار ادغام (نتیجه ابتدا NOT_RUN)

| گیت | کنترل آغاز | شاهد پایان |
|---|---|---|
| G1-spec | parent/AC/NG خرد، paths، هدف | trace هر AC و diff محدود |
| G2-isolation | محیط/دادهٔ مصنوعی، dirty fingerprint | عدم دسترسی نامرتبط و حفظ تغییرات |
| G3-tool-scope | فرمان‌ها و اثرهای مجاز | command/exit، بدون install/egress ضمنی |
| G4-tests-security | baseline، counts، تست منفی، threshold | نتایج همان revision، بدون skip/تضعیف |
| G5-protection | مقصد PR و rules/checks واقعی، no bypass | check/review/merge rule واقعی، نه YAML تنها |
| G6-evidence | base/head/hash و محل پالایش‌شده | timestamp، patch/artifact hash، نسخه و provenance |
| G7-human | scope مصوب و merger معلوم | تأیید همان head و merge انسانی واقعی |
| G8-budget | زمان/تلاش/هزینه/egress عددی مصوب | مصرف و stop از ابتدا، نه تخمین پس از پایان |
| G9-independent | reviewer/context مستقل و روش تعیین‌شده | بررسی واقعی روی نسخهٔ نهایی و findings |

## پنج گیت دامنه‌ای، برای همین اثر محدود

- Security: scope UI؛ هیچ پوشاندن کنترل سرور، retention محتوای خصوصی یا مجوز ضمنی.
- Privacy: هیچ receipt/chat/health/token واقعی در demo، logs، cache، trace یا screenshot.
- Finance: نمایش canonical؛ unknown≠zero؛ upload≠bank approval؛ بدون checkout/پول واقعی.
- Legal: مجوز dependency/font/asset/tool و egress واقعی؛ عمومی‌بودن GitHub مجوز بازتوزیع نیست.
- Product: AC همین زیرکار؛ حفظ خوانایی، RTL، فرم و native؛ پذیرش کل release به این زیرکار تحمیل نشود.

هر سطر نتیجهٔ مستقل با evidence می‌خواهد. N/A فقط با دلیل و تأیید انسانی؛ نبود reviewer/device/tool دلیل N/A نیست. این ZIP هیچ‌یک از این گیت‌های محصول را از قبل PASS نمی‌کند.

## آزمون‌های لازم در محصول، نه اثبات‌شده توسط کیت

401/403 و revoke واقعی، member A/B، stale refresh، مالکیت رسید، انقضا/replay QR، ثبت پایدار و reload، نسخهٔ دقیق برنامه، update بدون از دست رفتن فرم، cache-after-logout، نصب و offline واقعی، Android و مرورگرهای هدف، screen reader و CI روی SHA نهایی. پنج سفر مرجع v2 حذف یا ادغام نمی‌شوند. unknown در جریان اصلی مانع اعلام تکمیل است.
