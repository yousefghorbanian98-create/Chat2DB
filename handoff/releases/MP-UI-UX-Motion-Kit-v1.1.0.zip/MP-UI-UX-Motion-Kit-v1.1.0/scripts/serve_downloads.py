#!/usr/bin/env python3
"""Manifest-allowlisted static kit/download server. No MP/API/storage/write endpoint.
Local-only by default; explicitly use --host 0.0.0.0 only for an authorized preview.
The preview URL is temporary, not a GitHub publication or release.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import json
import mimetypes
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
BUILDER_EXPORT = 'MP-UI-UX-Motion-Builder-Start-v1.1.0.fa.md'


def make_handler(kit_root: Path, archive: Path):
    root = kit_root.resolve()
    archive = archive.resolve()
    if not archive.is_file() or not re.fullmatch(r'[A-Za-z0-9._-]+', archive.name):
        raise ValueError('a readable archive with a safe filename is required')
    manifest = json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    public = {entry['path'] for entry in manifest['files']} | {'PACKAGE_MANIFEST.json'}
    zip_route = '/downloads/'+archive.name
    md_route = '/downloads/'+BUILDER_EXPORT
    sha_route = zip_route+'.sha256'
    landing = '''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>دریافت بستهٔ Muscle Paradise 1.1.0</title><style>
:root{color-scheme:dark;font-family:Tahoma,system-ui,sans-serif;background:#0b0f14;color:#f3f6f8;line-height:1.95}*{box-sizing:border-box}body{margin:0;padding:clamp(18px,5vw,65px)}main{max-width:920px;margin:auto}header{display:flex;gap:16px;align-items:center;border-bottom:1px solid #26343b;padding-bottom:24px}.mark{background:#00b86a;color:#04120b;border-radius:13px;padding:8px 14px;font-weight:900;direction:ltr}small,.muted{color:#a6b6c3}h1{font-size:clamp(25px,5vw,40px);line-height:1.6;margin:32px 0 14px}p{margin:8px 0 20px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:28px 0}.card{background:#111827;border:1px solid #315b43;border-radius:16px;padding:24px;min-width:0}.card h2{font-size:20px;margin:0 0 10px}.file{font:12px/1.7 system-ui,sans-serif;direction:ltr;overflow-wrap:anywhere;color:#9ca3af;min-height:42px}.button{display:flex;justify-content:center;align-items:center;min-height:48px;min-width:44px;padding:12px 18px;border:1px solid #315b43;border-radius:11px;text-decoration:none;color:#04120b;background:#00b86a;font-weight:700}.secondary{color:#dce9df;background:#15251e}.links{display:flex;gap:12px;flex-wrap:wrap}.links a{color:#a9efcd;min-height:44px;padding:8px;display:inline-flex;align-items:center}.note{border-inline-start:3px solid #fbbf24;padding-inline-start:15px;color:#d7cda8;font-size:14px}a:focus-visible{outline:2px solid #38bdf8;outline-offset:4px}footer{border-top:1px solid #26343b;margin-top:32px;padding-top:20px;font-size:13px;color:#9ca3af}@media(max-width:600px){.cards{grid-template-columns:1fr}.card{padding:20px}}
</style></head><body><main><header><span class="mark">MP.</span><div><b>Muscle Paradise</b><br><small>UI / UX / Motion · Builder Handoff 1.1.0</small></div></header><h1>یک بسته. یک نقطهٔ شروع روشن.</h1><p class="muted">نسخهٔ به‌روز و راهنمای مستقل بیلدر را از دکمه‌های زیر دریافت کن؛ این‌ها route دانلود همین محیط‌اند، نه مسیر محلیِ متن گفتگو.</p><div class="cards"><section class="card"><h2>بستهٔ کامل ZIP</h2><p>پیش‌نمایش، ابزارهای منتخب، قراردادها، طرح ۵۰کارتی، قالب‌ها و شواهد همین کیت.</p><p class="file">@@ZIP_NAME@@</p><a class="button" id="download-zip" href="@@ZIP_ROUTE@@" download>دانلود بستهٔ کامل</a></section><section class="card"><h2>Markdown شروع بیلدر</h2><p>هدف، ترتیب کار، محدودیت‌های قبلی، اولین خروجی و گیت‌ها؛ همان فایل داخل ZIP.</p><p class="file">@@MD_NAME@@</p><a class="button secondary" id="download-builder" href="@@MD_ROUTE@@" download>دانلود فایل بیلدر</a></section></div><div class="links"><a id="download-sha" href="@@SHA_ROUTE@@" download>SHA-256 بسته</a><a href="/preview/index.html">پیش‌نمایش آفلاین UI</a><a href="/START_HERE_BUILDER.fa.md">خواندن راهنمای بیلدر</a><a href="/DOWNLOAD_HELP.fa.md">راهنمای دریافت</a></div><p class="note">این لینک برای عمر همین محیط است؛ فایل‌ها را ذخیره کن. این بسته مجوز تغییر MP، تلاش تازهٔ PWA-00، install، push یا انتشار نیست. سلامت کیت، QA محصول یا تأیید انسانی نیست.</p><footer>هیچ دادهٔ واقعی، API محصول یا directory listing در این سرور ارائه نمی‌شود.</footer></main></body></html>'''
    for key, value in [('ZIP_NAME', archive.name), ('MD_NAME', BUILDER_EXPORT), ('ZIP_ROUTE', zip_route), ('MD_ROUTE', md_route), ('SHA_ROUTE', sha_route)]:
        landing = landing.replace('@@'+key+'@@', html.escape(value, quote=True))

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            # Do not persist request URLs, queries, cookies or potentially private probes.
            pass

        def do_HEAD(self):
            self.serve(head=True)

        def do_GET(self):
            self.serve(head=False)

        def do_POST(self):
            self.send_error(405, 'Read-only delivery server')

        def respond(self, data: bytes, mime: str, head: bool, download: str | None = None, landing_page: bool = False):
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('ETag', '"'+hashlib.sha256(data).hexdigest()+'"')
            if download is not None:
                self.send_header('Content-Disposition', 'attachment; filename="'+download+'"')
            if landing_page:
                self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'")
            self.end_headers()
            if not head:
                self.wfile.write(data)

        def serve(self, head: bool):
            path = unquote(urlsplit(self.path).path)
            if path == '/':
                self.respond(landing.encode(), 'text/html; charset=utf-8', head, landing_page=True)
                return
            if path == '/favicon.ico':
                self.send_response(204)
                self.end_headers()
                return
            if path == zip_route:
                self.respond(archive.read_bytes(), 'application/zip', head, archive.name)
                return
            if path == md_route:
                self.respond((root/'START_HERE_BUILDER.fa.md').read_bytes(), 'text/markdown; charset=utf-8', head, BUILDER_EXPORT)
                return
            if path == sha_route:
                digest = hashlib.sha256(archive.read_bytes()).hexdigest()
                self.respond((digest+'  '+archive.name+'\n').encode(), 'text/plain; charset=utf-8', head, archive.name+'.sha256')
                return
            name = path.lstrip('/')
            candidate = (root/name).resolve()
            if name not in public or '..' in Path(name).parts or not candidate.is_relative_to(root) or not candidate.is_file():
                self.send_error(404)
                return
            mime = mimetypes.guess_type(name)[0] or 'application/octet-stream'
            if name.endswith(('.md', '.py', '.ts', '.tsx', '.mjs', '.txt')):
                mime = 'text/plain'
            if mime.startswith('text/') or mime in ['application/json', 'application/javascript']:
                mime += '; charset=utf-8'
            self.respond(candidate.read_bytes(), mime, head)

    return Handler


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=4174)
    args = parser.parse_args()
    # Check bytes/CRC/manifest before exposing a delivery listener; this is not product QA.
    from check_archive import check
    checksum = Path(str(args.archive)+'.sha256')
    result = check(args.archive, checksum if checksum.is_file() else None)
    handler = make_handler(ROOT, args.archive)
    print(json.dumps({'service': 'Muscle Paradise kit downloads 1.1.0', 'bind': args.host, 'port': args.port, 'archive_sha256': result['sha256'], 'scope': 'temporary read-only kit delivery, NOT product deployment'}, ensure_ascii=False), flush=True)
    with ThreadingHTTPServer((args.host, args.port), handler) as server:
        server.serve_forever()


if __name__ == '__main__':
    main()
