# ابزارهای اوپن‌سورس — انتخاب متناسب با MP، نه فهرست نصب

**منبع قابل‌ردیابی:** metadata و فایل مجوزِ pinشدهٔ upstream خوانده شده‌اند؛ [OPEN_SOURCE_TOOLS.json](references/OPEN_SOURCE_TOOLS.json) commit/blob/SHA-256 و دامنهٔ شاهد را دارد. این بررسی، تست runtime، ممیزی dependencyهای انتقالی یا نظر حقوقی مستقل نیست. هیچ ابزار تازه‌ای در MP نصب نشده است.

## معنای رایگان و مرز انتخاب

هزینهٔ مجوز کد اوپن‌سورسِ مشخص‌شده صفر است؛ hosting، حساب ابری، پشتیبانی، قالب/asset و AI ممکن است هزینه و مجوز دیگری داشته باشند. قابلیت‌های سرویس یا نسخهٔ تجاری را جزو نسخهٔ رایگان فرض نکن. upstream commit زیر فقط منبع مجوز است، نه نسخهٔ نصب/ارتقای مصوب محصول.

## دوازده ابزار بررسی‌شده

| ابزار و منبع رسمی | مجوز و منبع دقیق | تصمیم این کیت | کاربرد/مرز |
|---|---|---|---|
| [Penpot](https://github.com/penpot/penpot) | [MPL-2.0](https://github.com/penpot/penpot/blob/a0bbafaf12c60804fde2c03a510ed62049e0942a/LICENSE) | `SELECTED_DESIGN_EXTERNAL` | طراحی بصری و prototype، بیرون از runtime محصول |
| [Excalidraw](https://github.com/excalidraw/excalidraw) | [MIT](https://github.com/excalidraw/excalidraw/blob/5681e7d8be319092b13979e947afe632d5a4a525/LICENSE) | `OPTIONAL_FLOW_EXTERNAL` | wireframe و جریان‌ها؛ بدون دادهٔ واقعی |
| [Storybook](https://github.com/storybookjs/storybook) | [MIT](https://github.com/storybookjs/storybook/blob/a066aa49a6916f388fb58a932b4d8bb9ee2a2d44/LICENSE) | `OPTIONAL_DEV_TOOL_AFTER_APPROVAL` | کاتالوگ stateهای کامپوننت؛ نه شرط شروع |
| [Style Dictionary](https://github.com/style-dictionary/style-dictionary) | [Apache-2.0](https://github.com/style-dictionary/style-dictionary/blob/795233d9bee6a7b5787d685d75d626df3399d24d/LICENSE) | `DEFER_UNTIL_TOKEN_PIPELINE_GAP` | فقط پس از نیاز واقعی به تولید چند خروجی token |
| [Ant Design](https://github.com/ant-design/ant-design) | [MIT](https://github.com/ant-design/ant-design/blob/fdff100719297c25e079e4d0995918155663f348/LICENSE) | `EXISTING_REUSE_NO_UPGRADE` | همان UI فعلی؛ کنترل موازی ساخته نشود |
| [Mantine](https://github.com/mantinedev/mantine) | [MIT](https://github.com/mantinedev/mantine/blob/8f2ae606f8a37d5971f8315685e7daab44d9fbe2/LICENSE) | `ALTERNATIVE_NOT_SELECTED` | جایگزین برای پروژهٔ تازه؛ نه کنار AntD فعلی |
| [shadcn/ui](https://github.com/shadcn-ui/ui) | [MIT](https://github.com/shadcn-ui/ui/blob/055aa6b7837b1808456a24beb4c97a677864aa82/LICENSE.md) | `ALTERNATIVE_NOT_SELECTED` | جایگزین ساخت component library؛ ادغام همزمان پیش‌فرض نیست |
| [Radix Primitives](https://github.com/radix-ui/primitives) | [MIT](https://github.com/radix-ui/primitives/blob/eb3a2b7091293e27df8f9ba906632d8daa3d81a3/LICENSE) | `ALTERNATIVE_NOT_SELECTED` | زیرساخت design system اختصاصی؛ نه نیاز فعلی |
| [Tailwind CSS](https://github.com/tailwindlabs/tailwindcss) | [MIT](https://github.com/tailwindlabs/tailwindcss/blob/f95406ebb8d9c53d377e0ebb5467c318704c93cf/LICENSE) | `EXISTING_REUSE_NO_UPGRADE` | استایل‌دهی موجود و نسخهٔ سازگار حفظ شود |
| [Motion / Framer Motion](https://github.com/motiondivision/motion) | [MIT](https://github.com/motiondivision/motion/blob/1fa0e141f7b3f0a4eea258d5debc7dfbe5af6ffc/LICENSE.md) | `EXISTING_REUSE_NO_MIGRATION` | همان framer-motion فعلی؛ نه نصب موازی motion |
| [Puck](https://github.com/puckeditor/puck) | [MIT](https://github.com/puckeditor/puck/blob/aea29a71a228f1b9ddf828d7659733f6872c2548/LICENSE) | `FUTURE_ONLY_NOT_SELECTED` | اگر خودِ محصول به ویرایشگر بصری React نیاز پیدا کرد |
| [GrapesJS Core](https://github.com/GrapesJS/grapesjs) | [BSD-3-Clause](https://github.com/GrapesJS/grapesjs/blob/bf2d83cd750528cb5f4a56aa1d3f8c95b007f833/packages/core/LICENSE) | `FUTURE_ONLY_NOT_SELECTED` | قالب‌ساز HTML؛ فقط core، نه Studio SDK |

## از کجا شروع/دریافت شود؟

- **Penpot:** README/docs و self-host guidance همان مخزن رسمی را برای نسخهٔ سازگار بخوان؛ بیرون source محصول و با دادهٔ مصنوعی. این ZIP شامل باینری/محیط نصب‌شده یا فایل تألیف‌شدهٔ Penpot نیست.
- **Excalidraw:** مخزن رسمی و روش اجرای local/ویرایشگر مجاز؛ خروجی قابل‌ویرایش + SVG. cloud upload و دادهٔ واقعی پیش‌فرض نیستند.
- **Storybook:** فقط پس از شکاف مستند در کاتالوگ اجزا، انتخاب نسخهٔ سازگار با React/Vite/TypeScript فعلی و قرارداد dev-tool. `npx latest`، سرویس ابری تست تصویری یا CI دوم الزامی نیست.
- **Style Dictionary:** فعلاً نصب نکن؛ هنگام نیاز واقعی، ابتدا schema و adapter با تست parity. TOKENS.json کیت نه DTCG آماده است و نه import آزمایش‌شدهٔ Penpot.
- **AntD / Tailwind / Framer Motion:** همان مالک‌ها و lock محصول حفظ؛ منابع بالا برای بررسی هستند، نه دستور به آخرین نسخه. نام Motion مجوز import موازی `motion/react` یا مهاجرت خودکار نیست.
- **Mantine / shadcn / Radix:** گزینهٔ جایگزین‌اند؛ نصب همزمان کنار AntD انتخاب این پروژه نیست.
- **Puck / GrapesJS:** فقط اگر خود محصول به ویرایشگر صفحه نیاز پیدا کند. backend، ownership، نقش، ذخیره‌سازی و PWA کامل را خودکار نمی‌سازند.

**نکتهٔ GrapesJS:** GitHub ممکن است مجوز کل repository را `NOASSERTION` تشخیص دهد؛ برای این فهرست `packages/core/LICENSE` و فیلد `license` در package.json همان core مستقیماً بررسی شدند و BSD-3-Clause هستند. Studio SDK و مجوز/سرویس تجاری آن جزو انتخاب نیستند.

## تصمیم عملی برای MP

**Penpot بیرون اپ → reuse استک موجود → Storybook در صورت نیاز؛ Style Dictionary بعداً و فقط با GAP.** نصب همهٔ دوازده ابزار، تعویض orchestrator، UI دوم و framework موازی پیشنهاد نمی‌شود. دستور install/حساب/مدل/سرویس پولی در این تحویل اجرا نشده است.

برای مراحل و خروجی‌ها [DESIGN_WORKFLOW](DESIGN_WORKFLOW.fa.md) و برای اجازهٔ شروع [START_HERE_BUILDER](START_HERE_BUILDER.fa.md) را بخوان.
