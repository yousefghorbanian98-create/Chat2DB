# منابع و مجوزها

## محتوای همراه

- دو فایل فونت **Vazirmatn Variable 5.3.0** از بستهٔ موجود `@fontsource-variable/vazirmatn` برداشته شده‌اند. مجوز کامل SIL Open Font License 1.1 در [assets/fonts/OFL.txt](assets/fonts/OFL.txt) حفظ شده است. منبع: https://github.com/rastikerdar/vazirmatn و https://registry.npmjs.org/@fontsource-variable%2fvazirmatn/5.3.0 . تغییر یا فروش خود فونت موضوع این تحویل نیست.
- `locked_packages` در `references/MP_SOURCE.json` هویت بستهٔ فونت در lock محصول را ثبت می‌کند. فونت‌های همراه، source/runtime اختصاصی MP نیستند.
- node_modules، کتابخانه‌های React/AntD/Framer و باینری مرورگر در ZIP بسته‌بندی نشده‌اند. package-lock فقط reproducibility ابزار validation است. در صورت نصب، مجوزها/هش‌های همان نسخه‌ها باید نگه‌داری و بررسی شوند.
- recipeها، مستندات و preview جدید برای همین تحویل نوشته شده‌اند؛ snapshot کامل source اختصاصی MP در این بسته نیست. metadata مسیر/commit/hash برای قابلیت استناد آمده است. این فایل مجوز بازتوزیع کد/نام/دارایی اختصاصی MP یا تعیین مجوز حقوقی برای کل محصول نیست.

## پیوندهای رسمی ابزارهای حفظ‌شده

- https://github.com/ant-design/ant-design — Ant Design
- https://github.com/motiondivision/motion — Framer Motion / Motion؛ این بسته با import و نسخهٔ موجود 11 کار می‌کند، نه دستور نصب latest.
- https://github.com/recharts/recharts — Recharts
- https://github.com/rastikerdar/vazirmatn — Vazirmatn
- https://www.w3.org/WAI/WCAG22/Techniques/css/C39 — روش احترام به prefers-reduced-motion؛ به‌تنهایی گواه انطباق WCAG نیست.

metadata مجوزِ مستقیم lock خوانده‌شده: React، AntD، Framer Motion، Recharts، Zustand و icons برابر MIT؛ TypeScript برابر Apache-2.0؛ فونت OFL-1.1. این metadata، ممیزی حقوقی/امنیتی مستقل یا مجوز assetهای آینده نیست. هیچ runtime جدیدِ GSAP/Rive/Lottie یا asset آن‌ها در بسته وجود ندارد.

## ابزارهای معرفی‌شده در نسخهٔ ۱.۱.۰

[OPEN_SOURCE_TOOLS.json](references/OPEN_SOURCE_TOOLS.json) منبع رسمی و فایل مجوز با commit/blob/hash هر ابزار را ثبت می‌کند. کد یا باینری این دوازده ابزار (غیر از فونت‌های مجازِ همراه) در ZIP کپی نشده است؛ لینک‌دادن یا پیشنهاد ابزار، authoring/nصب/سرویس ابری اجراشده نیست. مجوزهای MPL-2.0، MIT، Apache-2.0 و BSD-3-Clause مربوط به کدهای مشخص‌شده‌اند؛ asset/plugin/template/سرویس آینده باید جدا بررسی شود.
