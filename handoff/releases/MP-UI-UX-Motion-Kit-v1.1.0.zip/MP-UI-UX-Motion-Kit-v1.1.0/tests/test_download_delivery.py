"""Synthetic HTTP delivery regressions; no real user data or product endpoint."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('kit_delivery', ROOT/'scripts/serve_downloads.py')
delivery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(delivery)

class DownloadDeliveryChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='mp-kit-delivery-test-')
        cls.root = Path(cls.temp.name)/'kit'
        cls.root.mkdir()
        (cls.root/'preview').mkdir()
        fixtures = {
            'START_HERE_BUILDER.fa.md': '# راهنمای مصنوعی\nNOT_PRODUCT_QA\n',
            'DOWNLOAD_HELP.fa.md': '# راهنمای دریافت مصنوعی\n',
            'preview/index.html': '<!doctype html><html lang="fa" dir="rtl">SYNTHETIC_PREVIEW</html>',
        }
        for name, data in fixtures.items():
            (cls.root/name).write_text(data, encoding='utf-8')
        (cls.root/'unlisted.txt').write_text('SYNTHETIC_NOT_PUBLIC')
        (cls.root/'PACKAGE_MANIFEST.json').write_text(json.dumps({'files': [{'path': name} for name in fixtures]}))
        cls.archive = Path(cls.temp.name)/'MP-UI-UX-Motion-Kit-v1.1.0.zip'
        # The transport unit test uses bytes only; CRC/real archive is checked separately.
        cls.archive.write_bytes(b'PK_SYNTHETIC_DOWNLOAD_FIXTURE_NOT_A_REAL_ZIP')
        cls.server = ThreadingHTTPServer(('0.0.0.0', 0), delivery.make_handler(cls.root, cls.archive))
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = 'http://127.0.0.1:'+str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)
        cls.temp.cleanup()

    def open(self, path='/', method='GET', headers=None):
        return urlopen(Request(self.base+path, method=method, headers=headers or {}), timeout=5)

    def test_landing_contains_real_download_routes_not_workspace_paths(self):
        with self.open() as response:
            body = response.read().decode()
            self.assertEqual(response.status, 200)
            self.assertIn('id="download-zip" href="/downloads/'+self.archive.name+'"', body)
            self.assertIn('id="download-builder"', body)
            self.assertNotIn('handoff/releases/', body)
            self.assertNotIn('localhost', body)
            self.assertIn("default-src 'none'", response.headers['Content-Security-Policy'])

    def test_zip_is_attachment_with_exact_bytes_length_and_etag(self):
        data = self.archive.read_bytes()
        with self.open('/downloads/'+self.archive.name) as response:
            self.assertEqual(response.headers['Content-Type'], 'application/zip')
            self.assertIn('attachment;', response.headers['Content-Disposition'])
            self.assertEqual(response.headers['Content-Length'], str(len(data)))
            self.assertEqual(response.headers['ETag'], '"'+hashlib.sha256(data).hexdigest()+'"')
            self.assertEqual(response.read(), data)

    def test_standalone_markdown_exactly_equals_the_file_inside_kit(self):
        with self.open('/downloads/'+delivery.BUILDER_EXPORT) as response:
            self.assertEqual(response.read(), (self.root/'START_HERE_BUILDER.fa.md').read_bytes())
            self.assertIn(delivery.BUILDER_EXPORT, response.headers['Content-Disposition'])
            self.assertEqual(response.headers['Content-Type'], 'text/markdown; charset=utf-8')

    def test_checksum_route_matches_transferred_zip(self):
        with self.open('/downloads/'+self.archive.name+'.sha256') as response:
            expected = hashlib.sha256(self.archive.read_bytes()).hexdigest()+'  '+self.archive.name+'\n'
            self.assertEqual(response.read().decode(), expected)

    def test_head_has_download_metadata_but_no_body(self):
        with self.open('/downloads/'+self.archive.name, method='HEAD') as response:
            self.assertEqual(response.read(), b'')
            self.assertEqual(int(response.headers['Content-Length']), self.archive.stat().st_size)
            self.assertIn('attachment;', response.headers['Content-Disposition'])

    def test_preview_proxy_host_is_accepted(self):
        with self.open(headers={'Host': '4174-preview.e2b.app'}) as response:
            self.assertEqual(response.status, 200)

    def test_private_unlisted_and_traversal_paths_are_not_served(self):
        for path in ['/unlisted.txt', '/node_modules/react/package.json', '/.git/config', '/%2e%2e/unlisted.txt', '/downloads/MISSING.zip']:
            with self.subTest(path=path), self.assertRaises(HTTPError) as error:
                self.open(path)
            self.assertEqual(error.exception.code, 404)

    def test_post_is_rejected(self):
        with self.assertRaises(HTTPError) as error:
            self.open('/', method='POST')
        self.assertEqual(error.exception.code, 405)

    def test_manifest_whitelisted_preview_is_readable(self):
        with self.open('/preview/index.html') as response:
            self.assertIn(b'SYNTHETIC_PREVIEW', response.read())
            self.assertIn('text/html', response.headers['Content-Type'])

if __name__ == '__main__':
    unittest.main()
