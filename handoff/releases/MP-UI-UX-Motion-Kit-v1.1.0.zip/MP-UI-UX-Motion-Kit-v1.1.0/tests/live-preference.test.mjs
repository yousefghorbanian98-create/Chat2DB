import test from 'node:test';
import assert from 'node:assert/strict';
import { readSystemReducedMotion, subscribeSystemReducedMotion } from '../.kit-build/live-preference.js';

// Pure external-store adapter tests; React re-render behavior is a separate browser smoke.
function fakeSystem(initial = false) {
  const listeners = new Set();
  const m = {
    matches: initial,
    addEventListener(type, fn) { assert.equal(type, 'change'); listeners.add(fn); },
    removeEventListener(type, fn) { assert.equal(type, 'change'); listeners.delete(fn); },
  };
  return {
    window: { matchMedia(q) { assert.equal(q, '(prefers-reduced-motion: reduce)'); return m; } },
    set(value) { m.matches = value; for (const fn of [...listeners]) fn(); },
    get count() { return listeners.size; },
  };
}
function withWindow(value, run) {
  const old = Object.getOwnPropertyDescriptor(globalThis, 'window');
  try { Object.defineProperty(globalThis, 'window', { configurable: true, value }); run(); }
  finally { if (old) Object.defineProperty(globalThis, 'window', old); else delete globalThis.window; }
}
test('SSR and unavailable matchMedia conservatively reduce', () => {
  withWindow(undefined, () => { assert.equal(readSystemReducedMotion(), true); assert.doesNotThrow(() => subscribeSystemReducedMotion(() => {})()); });
  withWindow({}, () => assert.equal(readSystemReducedMotion(), true));
});
test('matchMedia exceptions conservatively reduce', () => {
  withWindow({ matchMedia() { throw new Error('unsupported'); } }, () => assert.equal(readSystemReducedMotion(), true));
});
test('snapshot without live subscription support conservatively reduces', () => {
  withWindow({ matchMedia() { return { matches: false }; } }, () => assert.equal(readSystemReducedMotion(), true));
});
test('subscriber sees false -> true -> false live and cleans up', () => {
  const system = fakeSystem();
  withWindow(system.window, () => {
    const seen = [readSystemReducedMotion()];
    const stop = subscribeSystemReducedMotion(() => seen.push(readSystemReducedMotion()));
    assert.equal(system.count, 1);
    system.set(true); system.set(false); stop();
    assert.equal(system.count, 0); system.set(true);
    assert.deepEqual(seen, [false, true, false]);
  });
});
test('independent subscribers clean up without removing each other', () => {
  const system = fakeSystem(true);
  withWindow(system.window, () => {
    let a = 0; let b = 0;
    const stopA = subscribeSystemReducedMotion(() => a++);
    const stopB = subscribeSystemReducedMotion(() => b++);
    stopA(); system.set(false); stopB();
    assert.equal(a, 0); assert.equal(b, 1); assert.equal(system.count, 0);
  });
});
