# بیلدر از اینجا شروع کند — Muscle Paradise / UI + UX + Motion 1.1.0

**این فایل را اول بخوان؛ برای فهم مأموریت به تاریخچهٔ چت نیاز نداری.** نسخهٔ تکیِ این Markdown نیز ارائه می‌شود؛ لینک‌های نسبی آن پس از استخراج ZIP و از ریشهٔ کیت معتبرند.

> **مأموریت فعلی:** آماده‌سازی و انتخاب ابزار/طراحی برای ادامهٔ PWA مشترک Muscle Paradise. این تحویل، مجوز ویرایش MP، نصب dependency محصول، دورزدن Finn، تلاش تازهٔ PWA-00، push/PR/merge یا انتشار نیست. فقط در قرارداد کوچک، معتبر و مصوبِ کار واقعی اقدام کن. `PROPOSED` و `NOT_RUN` را به PASS تبدیل نکن.

## ۰. در یک دقیقه بدان چه چیزی می‌سازیم

- **یک React PWA مشترک برای عضو و کارکنان، بر پایهٔ `mp-app/studio/` موجود.** صفحات کارکنان تطبیق داده شوند؛ رفتار/قرارداد تجربه‌های عضو از Flutter تدریجی منتقل شود. اپ React دوم یا جایگزینی با Flutter Web نساز.
- **Flutter/Android، Flutter Web، سابقه، docs/tests/CI و Electron حفظ شوند.** desktop packaging پیش‌شرط PWA نیست؛ حذف هیچ‌کدام از انتخاب UI نتیجه نمی‌شود.
- **استک منتخب:** Ant Design موجود + `framer-motion` موجود + CSS بومی + Vazirmatn محلی. RTL/fa_IR، ConfigProvider، StyleProvider layer، helperهای motion و Feedback فعلی را بازاستفاده کن. صفر dependency جدید runtime محصول پیشنهاد شده است.
- **شش نقش backend فعلی:** `member`, `coach`, `reception`, `manager`, `admin`, `super_admin`. گروه نمایشی member/staff دو نقش تازه یا تأیید مدل سه‌نقشی نیست. API/server ownership مرجع امنیت است، نه منو/انیمیشن.
- **پیش‌فرض صرفاً پیشنهادی شروع:** online-first؛ اگر cache تصویب شد فقط static shell/assets. هیچ API/PII/session/token/receipt/health/chat cache و هیچ offline write حساس اضافه نکن. `PWA-3F` همچنان مشروط و به‌صورت پیش‌فرض BLOCKED است.
- ارسال رسید ≠ تأیید بانک؛ دادهٔ unknown ≠ صفر؛ متن موفقیت ≠ ثبت پایدار. checkout عضو، عکس بدن، محاسبهٔ پزشکی/تغذیه‌ای بی‌منبع، دادهٔ واقعی، live money و production خارج دامنه‌اند.

## ۱. اول بسته را بیرون از source محصول بررسی کن

ZIP را در یک مسیر مرجع مستقل استخراج کن؛ روی source یا فایل‌های dirty بیلدر unzip نکن. Python 3.10+ کافی است و فرمان‌های زیر شبکه یا MP را تغییر نمی‌دهند:

```bash
python3 scripts/validate_package.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

برای خود ZIP، `scripts/check_archive.py` مسیر ZIP را می‌گیرد؛ فایل `.sha256` کنار ZIP نیز در صورت وجود تطبیق داده می‌شود. manifest و checksum فقط drift را می‌گیرند؛ امضای ناشر، review مستقل یا QA محصول نیستند. اگر validator شکست خورد، فایل/گزارش را برای سبزشدن دستکاری نکن؛ نسخه و خطای دقیق را گزارش کن.

**نصب Penpot، Storybook، Style Dictionary یا هر کتابخانهٔ UI شرط این بررسی نیست.** هیچ دستور `npx ...@latest` یا install کلی روی MP اجرا نکن. [راهنمای دانلود](DOWNLOAD_HELP.fa.md) کانال تحویل و محدودیت لینک موقت محیط را توضیح می‌دهد.

## ۲. منابع و ترتیب خواندن

| ترتیب | فایل داخل همین ZIP | چرا لازم است؟ |
|---|---|---|
| ۱ | همین `START_HERE_BUILDER.fa.md` | هدف، اختیار، نقطهٔ آغاز و تحویل |
| ۲ | [SOURCE_PLAN](references/SOURCE_PLAN.fa.md) و [PLAN_IDENTITY](references/PLAN_IDENTITY.json) | ۵۰ parent اصلی با شناسه/عنوان/AC دست‌نخورده |
| ۳ | [مرجع D-01…D-11](references/DECISION_REGISTER.json) و [مرز تاریخچه](references/PWA_BASELINE.json) | Dهای اصلی و هویت ورودی‌ها؛ snapshot تاریخی، نه وضعیت زندهٔ مصوب |
| ۴ | [بازبینی تاریخی PWA-00](references/PWA-00-REVIEW-2026-11-24.fa.source.txt) | از تکرار خطا، reset تلاش و فرض بسته‌شدن findings جلوگیری کن |
| ۵ | [ابزارهای منتخب](OPEN_SOURCE_TOOLS.fa.md)، [گردش طراحی](DESIGN_WORKFLOW.fa.md) و [تصمیم استک](STACK_DECISION.fa.md) | ابزار بیرون اپ را با dependency محصول اشتباه نگیر |
| ۶ | [مشخصات UX/Motion](UX_MOTION_SPEC.fa.md)، [ماتریس ۲۵ دامنه](SCREEN_MATRIX.csv)، [توکن‌ها](TOKENS.json) | mapping طراحی، نه اجرای ۲۵ یا ۵۰ کارت |
| ۷ | [شواهد همین کیت](VERIFICATION.fa.md)، [پذیرش](ACCEPTANCE.fa.md) و [فلو شروع](diagrams/BUILDER_START_FLOW.fa.svg) | چه چیزی واقعاً تست شده و چه چیزی هنوز NOT_RUN است |

هندآف اصلی کامل v2، منجمد و جدا از این افزونه است: commit `3b4d389c20dc1d938e072ff6c90808a4eec44dd6` در Chat2DB؛ SHA-256 فایل اصلی `ab63be429ba8aff30eaebbd6e5d2978eca46c78cf2efb3ac4b4283a3d4a6863e`. [دانلود مرجع منجمد v2](https://github.com/yousefghorbanian98-create/Chat2DB/raw/3b4d389c20dc1d938e072ff6c90808a4eec44dd6/handoff/releases/MP-PWA-Arena-Handoff-v2.0.0.zip). این کیت برای **فهم شروع** به دانلود آن وابسته نیست؛ اجرای کل ۵۰ کارت نیازمند جزئیات و قراردادهای جاری خود محصول است.

## ۳. هویت source و تقدم وضعیت جاری

بررسی استاتیک مبنای استک در MP با pin `0e69b56dd0c427e45f2c104613cc420ea1a8c49f` انجام شده؛ metadata یازده فایل و سیزده هویت lock در [MP_SOURCE.json](references/MP_SOURCE.json) است. این pin نه ادعای HEAD فعلی بیلدر است، نه دستور checkout. runtime، backend، worktree خصوصی و وضعیت زندهٔ گیت‌های MP در این تحویل مشاهده نشده‌اند.

در آن snapshot: React/DOM 18.3.1، AntD 5.29.3، Framer Motion 11.18.2، Vazirmatn 5.3.0، icons 5.6.1، Recharts 2.15.4 و Zustand 5.1.0 خوانده شده‌اند. این اعداد فرمان ارتقا یا نصب نیستند. نسخه‌های upstream فهرست ابزارها نیز فقط pin منبع مجوزند؛ نسخهٔ نصب مصوب MP نیستند.

در checkout **خودِ MP** ابتدا AGENTS/ADR/تصمیم مالک و handoff جاری، branch/base/head، بودجه و سابقهٔ اجرا را بخوان. به شاخه‌ای که این فایل نام می‌برد سوییچ نکن. نبودن فایل بیلدر در محیط تهیهٔ این کیت، نبودن آن در محیط بیلدر را ثابت نمی‌کند. dirty/private/untracked را clean، reset، overwrite یا برای ثبت شاهد عمومی افشا نکن. fingerprint پالایش‌شده و allowlist قرارداد را رعایت کن؛ secret، نام/مسیر خصوصی و محتوای دادهٔ کاربر را در گزارش عمومی نیاور.

## ۴. مانع تاریخی PWA-00 را دور نزن

آخرین وضعیت قابل اتکای این گفتگو برای نسخهٔ بررسی‌شده: **`CHANGES_REQUESTED — DOCUMENTS_ONLY`**، نه DONE/AGENT-READY. گزارش کامل همراه بسته است. سه موضوع آن:

1. محدودکردن reviewer مستقل به «فقط انسان» بدون پشتوانهٔ مصوبه؛ reviewer واقعاً مستقل می‌تواند انسان یا عامل/ابزار جداگانهٔ مصوب باشد. **تأیید و merge انسانی همچنان جدا و لازم‌اند.**
2. آمیختن Product gateِ ADR/PWA-00 با پذیرش release آینده. D-01/D-10 می‌توانند هنوز باز بمانند؛ لازم نیست برای یک خروجی مستنداتی، کل release را حل کنی.
3. روشن‌کردن تاریخ/منشأ تصمیم و approval؛ تاریخ commit قدیمی تخلف نیست و تغییر نام پوشه لازم نیست.

بیلدر قبلاً سقف ۹۰ دقیقه/سه تلاش را گزارش کرده و سه تلاش کل مصرف شده بود؛ elapsed time مستقل قابل اثبات نبود. این کیت **بودجه یا تلاش تازه نمی‌دهد**. پیشنهاد قبلی «۳۰ دقیقه/یک اصلاح» نیز شرطی بود، نه مجوز اجرا. اگر پس از آن approval/نسخه/شاهد معتبر تازه‌ای وجود دارد، در محیط خودت با ref/hash و scope تطبیق بده؛ از این snapshot تاریخی وضعیت زنده را حدس نزن.

در سابقهٔ review، protected بودن main و خواندن قواعد GitHub به معنی G5 PASS نبود؛ metadata تاریخی PR با هشت check و صفر approval الزام‌شده دیده شد و دسترسی به classic protection کامل نبود. این کیت وضعیت فعلی protection یا تأیید انسانی را اثبات نمی‌کند و تنظیمی را عوض نمی‌کند.

**اثر عملی:** PWA-00 را بی‌مجوز دوباره اصلاح/اجرا نکن و از کیت برای جهش خودکار به کارت بعد استفاده نکن. خواندن مرجع، آماده‌سازی قرارداد و کار مستقلِ واقعاً مجاز می‌تواند ادامه یابد؛ ابهام فقط کار وابسته را متوقف کند.

## ۵. شروع عملی پیشنهادی — اول inventory، نه نصب و بازنویسی

### خروجی اول: یک inventory خواندنی و محدود

پس از احراز دامنهٔ مجاز همین کار، برای parentهای موجود **PWA-12/PWA-13** از [قالب inventory](templates/UI_MOTION_INVENTORY.fa.md) استفاده کن. این زیرکار parent پنجاه‌ویکم نیست. پیش از مجوز نوشتن در source، خروجی را به‌صورت artifact مرجع خارج source آماده کن.

حداقل این مالک‌های فعلی و مصرف‌هایشان را با checkout واقعی تطبیق بده:

- `mp-app/studio/package.json` و lock: scripts، نسخه‌های واقعی و هم‌پوشانی‌ها؛ نه فقط range.
- `src/main.tsx`: ConfigProvider، dark theme، fa_IR، RTL و StyleProvider layer.
- `src/lib/motion.ts` و `useMotionPreset()`: timing، preference، مصرف‌کنندگان و سیاست unknown.
- `src/App.tsx` و `src/components/Feedback.tsx`: motionهای موضعی، overlay، skeleton و toast؛ controller دوم نساز.
- `src/styles/index.css` و تنظیم Tailwind: layer، focus، transition/loop و logical properties.
- route/session/revoke، AntD Modal/Drawer، فهرست، نمودار و فرم فقط برای **ردیابی اثر**؛ ویرایش آن‌ها از inventory نتیجه نمی‌شود.

هر ردیف باید path/symbol، نقش/سناریو، وضعیت فعلی، نوع دادهٔ حساس، رفتار reduced/unknown، شاهد و GAP داشته باشد. عکس/اطلاعات عضو، رسید، chat یا token وارد artifact نکن. بررسی متن source، browser test یا security acceptance نیست.

### خروجی دوم: قرارداد فقط برای یک شکاف کم‌ریسک

اگر inventory نیاز واقعی را نشان داد، پیشنهاد اول **رفع سیاست reduced/unknown و تغییر زندهٔ تنظیم سیستم در helper موجود** است؛ با [قالب قرارداد](templates/MICROTASK_CONTRACT.fa.md). مرز، allowlist، baseline، reviewer و بودجهٔ عددی باید قبل از کد معتبر باشند.

در نسخهٔ validationِ Framer Motion 11.18.2، hook `useReducedMotion()` React subscription زندهٔ مستقل ندارد؛ به نام/توضیح آن اکتفا نکن. [adapter پیشنهادی](recipes/live-preference.ts) از React 18 `useSyncExternalStore` استفاده می‌کند. این یک recipe است، نه patch نصب‌شده در MP. ابتدا نسخه و رفتار واقعی فعلی را بررسی کن؛ policy و adapterِ لازم را در **همان helper موجود** ادغام کن، نه Provider/helper موازی.

**allowlist پیشنهادی:** helper motion موجود و regression testهای همان مالک، با تأیید قرارداد. افزودن CSS scoped فقط اگر GAP/تست آن را لازم کند و به allowlist اضافه شود. auth، API، role/grant، DB، SW/cache، router، مالی، manifest، Electron/native، CI و نصب ابزار جدید non-goal همین اصلاح‌اند.

اگر prerequisite این اصلاح هنوز معتبر نیست، خروجی تو inventory + قرارداد `READY-FOR-OWNER` یا `BLOCKED + دلیل` است؛ نه کد تأییدنشده. تصمیم‌های بازِ نامرتبط دلیل توقف همهٔ کارهای مستقل نیستند.

## ۶. چرا ابزارهای پیشنهادی را یک‌جا نصب نمی‌کنیم؟

| ابزار | جایگاه در این مأموریت | خروجی/شرط استفاده |
|---|---|---|
| Penpot | انتخاب طراحی **بیرون runtime محصول** | فایل طراحی، صفحه/کامپوننت و state؛ نصب/حساب/ارسال دادهٔ واقعی خودکار نیست |
| Excalidraw | اختیاری برای flow و wireframe | فایل قابل‌ویرایش و خروجی SVG با دادهٔ مصنوعی |
| Storybook | dev-tool اختیاری پس از نیاز و قرارداد | storyهای state کامپوننت؛ قبل از نصب peer dependencies با React18/Vite فعلی سنجیده شوند؛ latest فرض نشود |
| Style Dictionary | فعلاً defer | تنها پس از نیاز به pipeline چندخروجی؛ TOKENS این کیت خودبه‌خود فایل DTCG/ورودی آمادهٔ آن نیست |
| AntD / Framer Motion / CSS / Vazirmatn | حفظ و reuse | همان نسخه‌ها و مالک‌های سازگار فعلی؛ نه تعویض UI یا import موازی |
| Mantine / shadcn / Radix | جایگزین‌های مقایسه‌شده، فعلاً انتخاب نشده | migration یا نصب همزمان با AntD اختیار جدا می‌خواهد |
| Puck / GrapesJS Core | صرفاً آیندهٔ نیاز page-builder | ابزار ساخت ویرایشگرند؛ backend/role/API/PWA کامل نمی‌سازند؛ Studio SDK تجاری جزو انتخاب نیست |

منابع رسمی، مجوز و pin هر دوازده ابزار در [فهرست ابزارها](OPEN_SOURCE_TOOLS.fa.md) و JSON همراه آن آمده است. «رایگان» یعنی هزینهٔ مجوز کد مشخص‌شده صفر؛ سرور، AI، cloud، support و assetهای جانبی تعهد رایگان بودن ندارند. هیچ استفاده‌ای از مدل بیرونی، سرویس پولی یا telemetry از این فایل نتیجه نمی‌شود. Arena عامل کدنویسی اصلی است؛ Finn و کنترل‌های موجود جایگزین نمی‌شوند.

## ۷. نه حوزهٔ قرارداد برای **هر** زیرکار، مستقل از هم

| حوزه | قبل از شروع | شاهد پایان |
|---|---|---|
| G1-spec | parent/AC/NG، allowlist، یک نتیجهٔ قابل‌آزمون | trace هر AC به diff و تست |
| G2-isolation | محیط/دادهٔ مصنوعی، dirty fingerprint پالایش‌شده | تغییرات نامرتبط حفظ؛ عدم دسترسی خارج scope |
| G3-tool-scope | فرمان/اثر/egress مجاز | command/exit واقعی؛ بدون install یا اثر بیرونی ضمنی |
| G4-tests-security | baseline، تست منفی، threshold و stop rule | counts/خروجی همان revision؛ بدون skip/تضعیف |
| G5-protection | قواعد واقعی مقصد و required checks/reviews، no bypass | نتیجهٔ همان PR/head؛ YAML/protected=true به‌تنهایی کافی نیست |
| G6-evidence | base/head/hash و مقصد پالایش‌شدهٔ شواهد | زمان UTC، نسخه، artifact/patch hash و provenance |
| G7-human | scope مصوب و merger/approver مشخص | تأیید همان head و merge انسانی واقعی |
| G8-budget | زمان/تلاش/هزینه/egress عددی مصوب | مصرف از ابتدا، stop در سقف؛ نه reset یا تخمین پسینی |
| G9-independent | reviewer مستقلِ مصوب و قابل تأمین | review واقعی نسخهٔ نهایی، یافته‌ها و disposition |

چرخهٔ کار: Forge → Inspect → Normalize → Next؛ نصب runtime Finn شرط صرفاً خواندن پروتکل نیست. سقف سه تلاشِ خطای تکراری در Finn سند است، نه ادعای enforcement نصب‌شده. قرارداد جاری و سابقهٔ مصرف‌شده را رعایت کن. self-review، اعتبارسنج کیت یا یک agent با همان context جای G9 مستقل را پر نمی‌کند. review مستقل و human approval دو خروجی جدا هستند.

## ۸. پنج گیت دامنه‌ای جدا، نه یک عبارت «همه سبز»

- **Security:** scope UI؛ عدم retention محتوای خصوصی در revoke؛ سرور/مالکیت مرجع. تست guardِ نمایش، اثبات authorization نیست.
- **Privacy:** فقط synthetic؛ بدون رسید/سلامت/chat/token یا مسیر خصوصی در logs، screenshot، trace، cache و فایل طراحی ابری.
- **Finance:** canonical ریال/سرور؛ unknown صفر نیست؛ upload تأیید بانک/اشتراک نیست؛ retry کور و optimistic approval ممنوع.
- **Legal:** مجوز نسخهٔ واقعی ابزار/font/asset و egress؛ GitHub عمومی مجوز بازتوزیع همهٔ دارایی‌ها نیست. مجوز/font notice حفظ شود.
- **Product:** AC همین زیرکار، RTL، خوانایی، focus/form و حفظ native؛ پذیرش کل release را به اصلاح کوچک تحمیل نکن.

هر حوزه نتیجه و شاهد مستقل می‌خواهد. `UNKNOWN / NOT_RUN / DEFERRED` قبولی نیست؛ N/A فقط با دلیل و تأیید انسانی. هیچ گیت محصول از پیش به‌وسیلهٔ ZIP PASS نشده است.

## ۹. Dهای واقعی و سؤال‌های مالک

[رجیستر همراه](references/DECISION_REGISTER.json) متن/منبع اصلی Dها را نگه می‌دارد؛ `DECISION` در آن یعنی input لازم است، نه پاسخ مصوب یا وضعیت زندهٔ امروز. ابتدا تصمیم جاری را بخوان؛ سؤال تکراری نساز.

| شناسه | موضوع اصلی | مرز |
|---|---|---|
| D-01 | دامنهٔ client انتشار اول | جهت React معلوم؛ release baseline مستقل |
| D-02 | topology و ingress | HTTPS/میزبان/مسئول؛ نه deploy ضمنی |
| D-03 | نقش‌ها و grants | شش نقش حفظ؛ server permission matrix |
| D-04 | تک‌باشگاه یا multi-tenant | فقط اگر scope/ownership تغییر کند |
| D-05 | سیاست پرداخت و فروشگاه | manual transfer/human review؛ نه checkout تازه |
| D-06 | حریم خصوصی و retention | session/cache/رسید/سلامت؛ بدون عکس بدن |
| D-07 | DB و معیار مهاجرت | فقط GAP backend مرتبط؛ UI مجوز migration نیست |
| D-08 | سیاست مدل و egress عامل | مدل/داده/بودجه/kill switch؛ cloud پیش‌فرض نیست |
| D-09 | مالک عملیات، بودجه و پشتیبانی | مسئول و سقف عددی؛ نه انتخاب provider خودکار |
| D-10 | تعریف «همهٔ قابلیت‌های اصلی» | سفر/نقش/دستگاه/RTL و شواهد release |
| D-11 | مرز تغذیه، سلامت و منابع | مسئول حرفه‌ای و منبع/مجوز؛ بدون عدد/ادعای LLM |

سؤال‌ها را یک‌جا با اثر، پیشنهاد محدود و کار مستقل بعدی بده. برای شروع یک زیرکار مجاز لازم نیست همهٔ یازده D حل شوند؛ فقط وابستگی واقعی آن زیرکار. هیچ بودجهٔ تازه، تغییر نقش یا تصمیم session/offline را از سکوت مالک نتیجه نگیر.

## ۱۰. معیار تحویل اولین اصلاح احتمالی

پس از قرارداد و مجوز واقعی، حداقل این‌ها با source/تست همان revision اثبات شوند:

- reduced، unknown یا نبود API پشتیبانی‌شده: transform/scale/stagger/delay غیرضروری صفر؛ متن و کنترل‌ها فوراً قابل‌استفاده بمانند.
- false → true → false در تنظیم سیستم **بدون reload** اثر کند؛ subscription cleanup شود؛ SSR امن و محتوای اولیه مخفی نباشد.
- تغییر state/key فرم را remount نکند؛ focus و draft حفظ شوند؛ RTL/keyboard/عرض هدف بررسی شوند.
- خروج محتوای حساس بعد از revoke/logout معطل animation نشود؛ receipt pending به approved تبدیل نشود؛ این شرط جای تست واقعی API/مالکیت را نمی‌گیرد.
- timing و token دو مرجع دستی ناسازگار پیدا نکنند؛ helper، provider یا UI library موازی اضافه نشود.
- baseline، test discovery، threshold و گیت‌های فعلی حذف/تضعیف نشوند؛ تغییر خارج allowlist صفر یا با قرارداد تازه.

فرمان‌های محصول را از package.json/CI جاری بخوان؛ در snapshot، Studio دارای `npm test`، `npm run lint` و `npm run build` است. فیلتر یا نتیجه را حدس نزن. `python3 scripts/docs_gate.py` مربوط به checkout MP است و این کیت نتیجهٔ اجرای آن را ندارد. build، lint، browser، device، backend و security هرکدام نتیجهٔ مستقل می‌خواهند.

## ۱۱. گزارش بعدی بیلدر دقیقاً چه داشته باشد؟

1. **وضعیت واقعی:** `PROPOSED / DECISION / BLOCKED / READY-FOR-OWNER / AGENT-READY` با معنای پروتکل جاری؛ نه انتخاب عنوان برای سبزکردن صف.
2. checkout/ref/base/head و dirty summary پالایش‌شده؛ تشخیص drift نسبت به source pin کیت؛ بودجه/تلاش باقی‌مانده با منشأ مصوبه.
3. یک خروجی inventory و یک GAP؛ parent/AC، allowlist/NG و D وابسته؛ اگر GAP نیست، «بدون نیاز به تغییر» با شاهد.
4. ابزار انتخاب‌شده و دلیل؛ dependency جدید پیشنهادی/واقعاً نصب‌شده جدا؛ فعلاً صفر تغییر محصول.
5. نتیجهٔ هر نه حوزه و پنج گیت با evidence مستقل؛ command، نسخه، exit و counts واقعی، شکست‌ها و NOT_RUNها.
6. diff/patch/artifact hash و reviewer مستقل همان نسخه؛ findings و اصلاح/بستن آن‌ها؛ human approval/merge جدا.
7. یک سؤال/بستهٔ تصمیم مالک فقط برای blocker واقعی و پیشنهاد گام مستقل بعدی. بعد از تغییر head، review/check اثرگرفته دوباره لازم است.

**فهرست canonical همان ۵۰ مورد است:** `[6,8,5,16,8,7]`؛ شناسه‌های `00–05 / 10–17 / 20–24 / 30–39 + 3A–3F / 40–47 / 50–56`. اختلاف تاریخی ۵۶/۲۶ یا خلاصهٔ ۲۸تایی، consolidation تأییدشده نیست. عنوان/AC را بازنویسی یا parent جدید نساز. پنج سفر عضو، مربی، QR، مالی و امنیت در SOURCE_PLAN جدا باقی می‌مانند.

## ۱۲. متن شروع قابل استفاده توسط بیلدر

> ابتدا فقط کیت را خارج source اعتبارسنجی و AGENTS/تصمیم/وضعیت/بودجهٔ جاری MP را با هویت نسخه تطبیق بده. هیچ محصول یا dependency را از روی این ZIP تغییر نده. وضعیت تاریخی PWA-00 و تلاش‌های مصرف‌شده را reset نکن؛ اگر شاهد جدید داری دقیقاً نسخه و مصوبه‌اش را نشان بده. برای کار مستقلِ مجاز، inventory محدود UI/Motion در PWA-12/PWA-13 و قرارداد یک GAP کم‌ریسک تهیه کن. استک فعلی، شش نقش و Flutter/Android/Flutter Web/Electron/CI حفظ شوند. ابزار طراحی بیرون اپ است؛ Storybook اختیاری و Style Dictionary فعلاً defer. گیت‌های نه‌گانه و پنج گیت دامنه‌ای، review مستقل، تأیید انسانی و human merge باید واقعی باشند. در پایان فقط شواهد همان خروجی کوچک و blocker واقعی را گزارش کن؛ از سلامت ZIP یا زیبایی preview، Product QA یا release-ready نتیجه نگیر.
