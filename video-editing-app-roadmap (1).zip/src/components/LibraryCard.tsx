"use client";

import type { OpenSourceLib } from "@/lib/roadmap-data";

interface LibraryCardProps {
  lib: OpenSourceLib;
}

const PRIORITY_COLORS: Record<string, string> = {
  ts: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  py: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  both: "bg-purple-500/10 text-purple-400 border-purple-500/20",
};

const LANG_LABEL: Record<string, string> = {
  ts: "TypeScript",
  py: "Python",
  both: "TS + Python",
};

const LANG_ICON: Record<string, string> = {
  ts: "⚛️",
  py: "🐍",
  both: "🔀",
};

export default function LibraryCard({ lib }: LibraryCardProps) {
  const repoUrl = `https://github.com/${lib.repo}`;
  
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all card-hover group">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="font-bold text-white text-base">{lib.name}</h4>
            <span className={`text-xs border rounded-full px-2 py-0.5 ${PRIORITY_COLORS[lib.language]}`}>
              {LANG_ICON[lib.language]} {LANG_LABEL[lib.language]}
            </span>
            {lib.stars !== "N/A" && (
              <span className="text-xs text-yellow-400 flex items-center gap-1">
                ⭐ {lib.stars}
              </span>
            )}
          </div>
          <a
            href={repoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-gray-500 hover:text-indigo-400 transition-colors mt-0.5 block ltr"
          >
            {lib.repo}
          </a>
        </div>
      </div>
      
      <p className="text-gray-300 text-sm mb-3 leading-relaxed">{lib.description}</p>
      
      <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-lg p-3 mb-3">
        <p className="text-indigo-300 text-xs leading-relaxed">
          <span className="text-indigo-400 font-semibold">کاربرد: </span>
          {lib.use}
        </p>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-3">
        {lib.tags.map((tag) => (
          <span key={tag} className="text-xs bg-gray-800 text-gray-400 rounded-full px-2 py-0.5 ltr">
            #{tag}
          </span>
        ))}
      </div>
      
      <div className="flex gap-2 flex-wrap">
        {lib.npm && (
          <code className="text-xs bg-gray-800 text-green-400 rounded px-2 py-1 ltr flex items-center gap-1">
            <span className="text-gray-500">npm i</span> {lib.npm}
          </code>
        )}
        {lib.pypi && (
          <code className="text-xs bg-gray-800 text-yellow-400 rounded px-2 py-1 ltr flex items-center gap-1">
            <span className="text-gray-500">pip install</span> {lib.pypi}
          </code>
        )}
        <a
          href={repoUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-white rounded px-2 py-1 transition-colors flex items-center gap-1"
        >
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
            <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
          </svg>
          GitHub
        </a>
      </div>
    </div>
  );
}
