/**
 * PROPOSAL: integrate into existing lib/motion.ts, not a second motion provider.
 * Framer Motion 11.18.2 useReducedMotion snapshots the preference with useState;
 * this existing-React adapter explicitly subscribes to live system changes.
 */
import { useSyncExternalStore } from "react";

const query = "(prefers-reduced-motion: reduce)";
function media(): MediaQueryList | null {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") return null;
  try {
    const result = window.matchMedia(query);
    // Unsupported subscription means conservative no-motion, not a stale false.
    return typeof result.addEventListener === "function" && typeof result.removeEventListener === "function" ? result : null;
  } catch {
    return null;
  }
}
export function readSystemReducedMotion(): boolean {
  return media()?.matches ?? true;
}
export function subscribeSystemReducedMotion(notify: () => void): () => void {
  const result = media();
  if (!result) return () => {};
  result.addEventListener("change", notify);
  return () => result.removeEventListener("change", notify);
}
export function useLiveReducedMotion(): boolean {
  return useSyncExternalStore(subscribeSystemReducedMotion, readSystemReducedMotion, () => true);
}
