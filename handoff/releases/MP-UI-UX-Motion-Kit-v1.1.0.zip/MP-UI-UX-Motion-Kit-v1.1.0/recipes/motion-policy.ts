/**
 * PROPOSAL ONLY. Merge the reviewed policy into existing src/lib/motion.ts.
 * Do not create a second canonical motion system or install motion/react.
 * All times below are seconds, matching Framer Motion 11.
 */
export type MotionIntent = "panel" | "feedback" | "list" | "critical";
export type MotionPreference = boolean | null | undefined;

export const KIT_MOTION = {
  press: 0.12,
  feedback: 0.12,
  enter: 0.28,
  page: 0.34,
  staggerStep: 0.03,
  staggerCap: 0.12,
  panelTravel: 6,
} as const;

export interface MotionPolicy {
  enabled: boolean;
  duration: number;
  displacement: number;
  layout: false | "position";
}

/** Unknown preference is conservatively treated as reduced motion. */
export function selectMotionPolicy(
  preference: MotionPreference,
  intent: MotionIntent,
): MotionPolicy {
  if (preference !== false || intent === "critical") {
    return { enabled: false, duration: 0, displacement: 0, layout: false };
  }
  return {
    enabled: true,
    duration: intent === "feedback" ? KIT_MOTION.feedback : KIT_MOTION.enter,
    displacement: intent === "panel" ? KIT_MOTION.panelTravel : 0,
    layout: intent === "list" ? "position" : false,
  };
}

/** Opt-in decorative stagger only; never delay a control or authorization. */
export function decorativeDelay(
  index: number,
  preference: MotionPreference,
  optedIn = false,
): number {
  if (!optedIn || preference !== false || !Number.isFinite(index)) return 0;
  return Math.min(Math.max(0, Math.floor(index)) * KIT_MOTION.staggerStep, KIT_MOTION.staggerCap);
}

export type ReceiptPhase =
  | "not_sent"
  | "submitting"
  | "pending_review"
  | "approved"
  | "rejected"
  | "unknown"
  | "offline";

export interface ReceiptPresentation {
  tone: "info" | "warning" | "success" | "error";
  title: string;
  detail: string;
  allowBlindRetry: false;
  celebrate: false;
}

/**
 * Display only. Caller supplies a validated, authorized canonical server state.
 * This function does not validate a bank transfer, grant access, or activate a subscription.
 * Unknown/untrusted phases fail closed; do not infer approved from upload success.
 */
export function receiptPresentation(phase: string): ReceiptPresentation {
  const safe = { allowBlindRetry: false, celebrate: false } as const;
  switch (phase) {
    case "not_sent":
      return { ...safe, tone: "info", title: "رسیدی ارسال نشده", detail: "ارسال رسید به‌تنهایی تأیید پرداخت نیست." };
    case "submitting":
      return { ...safe, tone: "info", title: "در حال ارسال", detail: "تا روشن‌شدن پاسخ، ارسال دوباره انجام ندهید." };
    case "pending_review":
      return { ...safe, tone: "warning", title: "در انتظار بررسی انسانی", detail: "دریافت رسید به معنی تأیید واریز بانکی یا فعال‌شدن اشتراک نیست." };
    case "approved":
      return { ...safe, tone: "success", title: "تأیید ثبت‌شدهٔ سرور", detail: "فقط وقتی وضعیت معتبر سرور پس از بررسی مجاز چنین است؛ این نما خود چیزی را تأیید نمی‌کند." };
    case "rejected":
      return { ...safe, tone: "error", title: "نیازمند پیگیری", detail: "دلیل پالایش‌شدهٔ معتبر را از مسیر مجاز دریافت کنید؛ اطلاعات بانکی را در پیام عمومی ننویسید." };
    case "offline":
      return { ...safe, tone: "warning", title: "اتصال برقرار نیست", detail: "رسید یا دادهٔ حساس در صف آفلاین ذخیره نمی‌شود." };
    default:
      return { ...safe, tone: "warning", title: "نتیجه نامشخص است", detail: "ابتدا وضعیت سرور را تطبیق دهید؛ موفقیت یا ارسال دوباره را فرض نکنید." };
  }
}
