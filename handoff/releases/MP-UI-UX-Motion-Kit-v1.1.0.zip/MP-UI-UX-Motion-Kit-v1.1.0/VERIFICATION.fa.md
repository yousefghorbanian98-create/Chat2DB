# شواهد واقعی کیت ۱.۱.۰ و مرز QA

**`PROPOSED_ADOPTION_NOT_PRODUCT_QA`** — نتایج زیر self-check همین کیت‌اند؛ نه اجرای تست در MP، G9 مستقل، human approval یا مجوز شروع/انتشار محصول. کد و dependency محصول تغییر نکرده است.

## نتایج تازهٔ این نسخه

| اجرا | نتیجهٔ ثبت‌شده | دامنه |
|---|---|---|
| `npm ci --ignore-scripts --no-audit --no-fund` در پوشهٔ مستقل ۱.۱ | exit 0؛ ۸۱ package | validation-only؛ نه نصب محصول یا ابزارهای طراحی |
| `npm run typecheck` | exit 0؛ strict TypeScript | recipeهای React18/AntD5/Framer11 با lock کیت |
| `npm test` | ۵۰ passed؛ صفر failed/skipped/cancelled | policy، SSR، subscription/cleanup و parity |
| `node scripts/browser_smoke.mjs` | ۱۸ case passed؛ صفر failed | Chromium headless `158.0.8127.0`؛ فقط دادهٔ مصنوعی |
| `python3 scripts/validate_package.py` | `KIT_OK_NOT_PRODUCT_QA`؛ بدون problem | inventory/hash/CSP/پیوندهای local/هویت/منابع و قرارداد طراحی |
| `python3 -m unittest discover -s tests -p 'test_*.py' -v` | ۳۵ passed؛ صفر failed | ۲۶ رگرسیون validator + ۹ رگرسیون HTTP delivery با fixture مصنوعی |
| `node scripts/download_smoke.mjs BASE_URL ARCHIVE EXTERNAL_REPORT` | ۸ case passed؛ صفر خطا | کلیک و تکمیل دانلود ZIP/Markdown در Chromium از سرور همین محیط؛ نه fetch پروکسی HTTPS عمومی |
| ZIP/CRC/manifest/reproducibility | checker محلی و بازتولید byte-equal | سلامت داخلی بسته؛ نه امضا/اصالت یا QA محصول |

Logها و bindingها: [RECIPE_CHECK.json](references/RECIPE_CHECK.json)، [recipe-tests.tap.txt](references/recipe-tests.tap.txt)، [typecheck.log.txt](references/typecheck.log.txt)، [BROWSER_CHECK.json](references/BROWSER_CHECK.json)، [package-tests.log.txt](references/package-tests.log.txt). binding فایلِ آزموده‌شده را شناسایی می‌کند؛ اجرای دوبارهٔ browser نیست. زمان داخل JSON ساعت ماشین ابزار است، نه تاریخ approval/تصمیم محصول.

## آنچه در browser preview واقعاً بررسی شد

- اجرای self-contained `file://` در حالت offline؛ دو font face embed شده load شدند. صفر تلاش HTTP/S، page error و console error در caseهای اجراشده.
- فارسی/RTL و عرض‌های 320/390/1440 CSS px بدون overflow؛ کنترل‌ها/پیوندهای عملیاتی انتخاب‌شده حداقل 44×44. این اندازه‌گیری همهٔ اجزای MP نیست.
- دوازده ترکیب member/staff و شش state، هفت receipt state مطابق typed policy، عدم تعبیر pending_review به تأیید بانک و نبود انیمیشن مالی.
- حفظ node/focus فهرست، سقف نمونهٔ هشت‌تایی، تغییر زندهٔ reduced motion و لغو انیمیشن درحال‌اجرا، انتخاب دستی و fallback بدون matchMedia.
- skip link قابل‌فوکوس و outline، محتوای خوانا بدون JS؛ در fixture واقعی React، false → true → false بدون reload و حفظ draft/focus، به‌علاوهٔ حذف child مصنوعی بعد از deny.
- چهار کارت انتخاب ابزار و ورودی START_HERE صریح‌اند؛ هیچ‌یک ادعای نصب/ادغام Penpot/Storybook/Style Dictionary نیست.

باینری serverless با sandbox خاموش اجرا شد؛ flag غیرفعال‌کردن web-security حذف و درخواست HTTP/S در smoke آفلاین مسدود بود. این اجرا security certification نیست. ابزار/باینری/bundle موقت در ZIP وجود ندارد.

## رگرسیون تحویل و آزمون دانلود

نه تست HTTP با fixture مصنوعی، route واقعی attachment، Content-Type/Length/Disposition/ETag، برابر بودن Markdown با فایل داخل کیت، SHA، HEAD، پذیرش host پروکسی، deny مسیر private/unlisted/traversal و read-only POST را کنترل کردند. fixture انتقال، ZIP محصول نیست؛ CRC/manifest روی آرشیو واقعی جدا بررسی می‌شود.

[download_smoke.mjs](scripts/download_smoke.mjs) هشت case را با موفقیت اجرا کرد: نبود overflow در عرض‌های 320/390/1440، کلیک واقعی و تکمیل downloadِ ZIP، دانلود Markdown byte-identical با START_HERE، تطبیق checksum، deny مسیرهای private و نبود خطا/شبکهٔ بیرونی. پاسخ سه route اصلی نیز با HTTP 200، header attachment و بایت‌های فایل‌های بیرونی تطبیق داده شد؛ Host مصنوعی مشابه preview پذیرفته شد. **رسیدِ digest نسخهٔ دقیق خارج ZIP نگه‌داری می‌شود** تا hash چرخه‌ای ایجاد نشود؛ نام آن `MP-UI-UX-Motion-Kit-v1.1.0.download-check.json` است. این smoke فقط loopback محیط را می‌پذیرد؛ public HTTPS proxy را fetch نمی‌کند و تست انتشار عمومی یا production نیست. لینک Preview موقت است؛ فایل را از پیوست/صفحهٔ دانلود ذخیره کن.

## provenance و preservation

- [MP_SOURCE](references/MP_SOURCE.json): source pin استاتیک `0e69b56dd0c427e45f2c104613cc420ea1a8c49f`، یازده فایل و سیزده هویت lock؛ نه HEAD/runtime فعلی MP. ساعت خواندن اولیه ثبت نشده است.
- [PWA_BASELINE](references/PWA_BASELINE.json): رونوشت دقیق SOURCE_PLAN، PLAN_IDENTITY، D-register و review تاریخی با hash. ۵۰ شناسه/عنوان/AC و counts `[6,8,5,16,8,7]` حفظ شده‌اند؛ snapshot Dها approval زنده نیست.
- [OPEN_SOURCE_TOOLS](references/OPEN_SOURCE_TOOLS.json): منبع مجوز دوازده upstream با commit/blob/SHA-256 خوانده شد. GrapesJS core جدا از detection نامشخص کل repo بررسی شد. این کار ممیزی حقوقی/transitive dependency نیست.
- ZIP قبلی UI ۱.۰.۰ با SHA `683ed1ebde0a8f7a16bb4fab301386c0252bbc853298fdd61d02792e369db3ec` و PWA v2 با SHA `ab63be429ba8aff30eaebbd6e5d2978eca46c78cf2efb3ac4b4283a3d4a6863e` دست‌نخورده‌اند.

## خطای این دور و مرز سابقه

اولین `npm ci` به‌اشتباه از ریشهٔ Chat2DB اجرا شد و به علت نبود lock همان مسیر EUSAGE داد؛ install آن اجرا انجام نشد. cwd به پوشهٔ مستقل کیت اصلاح شد و نصب/تست‌های موفق جدول بالا فقط آنجا اجرا شدند. package/lock محصول تغییر نکرد و نتیجهٔ خطا پنهان نشده است.

خطاهای ساخت نسخهٔ ۱.۰.۰ تاریخچهٔ همان نسخه‌اند؛ نتایج آن‌ها به‌جای اجرای تازه استفاده نشده‌اند. تلاش‌های ساخت این کیت، سابقه یا بودجهٔ بیلدر PWA-00 را reset نمی‌کنند. متن محدودیت‌ها در [START_HERE](START_HERE_BUILDER.fa.md) آمده است.

## بازتولید

Python 3.10+، بدون نصب یا شبکه، از ریشهٔ کیت:

```bash
python3 scripts/validate_package.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 scripts/build_package.py --check
```

`scripts/check_archive.py` مسیر ZIP و در صورت نیاز `--sha256-file` را می‌گیرد و هیچ کد داخل آرشیو را اجرا نمی‌کند. `build_package.py` بدون `--check` فایل تولیدی، manifest، ZIP و Markdown تکی/هش‌های بیرونی را در مسیر خروجی می‌نویسد؛ دستور انتشار نیست. timestamp ثابت آرشیو، زمان تست/approval/release نیست و checksum امضای ناشر نیست.

برای recipeها فقط در کیت: `npm ci --ignore-scripts --no-audit --no-fund`، سپس `npm run typecheck` و `npm test`. برای browser اختیاری، ابزارهای جداگانهٔ `playwright-core@1.65.1`، `@sparticuz/chromium@158.0.0` و `esbuild@0.28.2` و executable/library سازگار لازم‌اند. `KIT_BROWSER_TOOLS` مسیر tooling و `KIT_CHROMIUM_EXECUTABLE` executable اختیاری را مشخص می‌کنند. در اجرای ثبت‌شده، کتابخانه‌های همراه `al2023.tar.br` فقط داخل `chromium-libs/lib` پوشهٔ ابزار استخراج شدند؛ نصب سیستمی انجام نشد. قبل از نصب/egress در محیط دیگری scope را بررسی کن.

## صریحاً NOT_RUN در محصول

Build/lint/test/CI کامل MP؛ backend/API/ownership و شش نقش؛ 401/403 و revoke واقعی؛ receipt خصوصی، بانک، QR و persistence/reload؛ PWA install/update/SW/offline؛ دستگاه Android/iOS؛ Firefox/WebKit/Safari؛ screen reader/zoom و audit انسانی accessibility؛ performance روی device؛ SAST/security/legal مستقل؛ staging/release؛ G9، human approval و merge. این کیت هیچ‌کدام را PASS یا N/A اعلام نمی‌کند. هیچ push/publication تازهٔ GitHub انجام نشده است.
