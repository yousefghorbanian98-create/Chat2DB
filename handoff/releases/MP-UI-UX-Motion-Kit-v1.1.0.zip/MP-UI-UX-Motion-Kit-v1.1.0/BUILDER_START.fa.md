# میان‌بر شروع بیلدر — نسخهٔ ۱.۱.۰

**مرجع شروع کامل و مستقل، [START_HERE_BUILDER.fa.md](START_HERE_BUILDER.fa.md) است.** این فایل صرفاً فهرست سریع است و قرارداد دوم یا مجوز اجرای محصول نیست.

1. ZIP را خارج source محصول استخراج و `python3 scripts/validate_package.py` را از ریشهٔ آن اجرا کن.
2. هدف مشترک Studio/React PWA، preservation native/CI، canonical ۵۰ parent و source pin را از فایل شروع بخوان.
3. وضعیت واقعی checkout، تصمیم‌ها، review و بودجهٔ مصرف‌شده را تطبیق بده. تلاش‌های PWA-00 reset نمی‌شوند؛ اگر approval/شاهد جدید نداری، کد یا اصلاح تازهٔ آن را شروع نکن.
4. برای کار مستقلِ واقعاً مجاز، ابتدا [inventory](templates/UI_MOTION_INVENTORY.fa.md) محدود PWA-12/PWA-13؛ سپس [قرارداد](templates/MICROTASK_CONTRACT.fa.md) یک GAP کم‌ریسک. قبل از قرارداد معتبر، source را تغییر نده.
5. ابزار منتخب طراحی Penpot است؛ Excalidraw اختیاری، Storybook opt-in و Style Dictionary فعلاً defer. هیچ‌کدام شرط validation کیت یا مجوز install روی MP نیستند.
6. فقط بعد از مصوبهٔ همان زیرکار، بخش لازم recipe را در helper موجود ادغام و تست کن؛ helper/provider/UI موازی، migration بی‌دلیل یا dependency جدید پیش‌فرض ممنوع.
7. نه حوزهٔ قرارداد، پنج گیت دامنه‌ای، review مستقل و تأیید/merge انسانی جدا ثبت شوند. `UNKNOWN / NOT_RUN / DEFERRED` قبولی نیست.

گزارش بعدی باید inventory، GAP/بدون‌نیازبه‌تغییر، allowlist، D وابسته، بودجه با منشأ، فرمان/exit/count واقعی و blocker مؤثر را داشته باشد. زیبایی preview یا سالم‌بودن ZIP، Product QA، AGENT-READY یا مجوز رفتن خودکار به کارت بعد نیست.
