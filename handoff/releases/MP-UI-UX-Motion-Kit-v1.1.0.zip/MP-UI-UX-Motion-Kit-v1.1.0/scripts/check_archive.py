#!/usr/bin/env python3
"""Read-only standard-library ZIP/manifest/hash check; never executes archive code.
This establishes internal integrity, NOT a signature, trusted publisher or product QA.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import stat
import zipfile
from pathlib import Path, PurePosixPath

PREFIX = 'MP-UI-UX-Motion-Kit-v1.1.0/'
FORBIDDEN = {'node_modules', '.kit-build', '__pycache__', '.cache', '.git', '.venv', '.npm'}


def relative(value: str) -> str:
    if not value or '\\' in value or '\0' in value or ':' in value or PurePosixPath(value).is_absolute() or any(x in ('', '.', '..') for x in value.split('/')):
        raise ValueError('unsafe archive path')
    return PurePosixPath(value).as_posix()


def check(archive: Path, checksum_file: Path | None = None) -> dict:
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if checksum_file is not None:
        text = checksum_file.read_text(encoding='utf-8').strip()
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', text)
        if not match or match.group(1) != digest or match.group(2) != archive.name:
            raise ValueError('external checksum/filename mismatch')
    with zipfile.ZipFile(archive) as package:
        seen = set()
        expanded = 0
        for info in package.infolist():
            if not info.filename.startswith(PREFIX) or info.is_dir():
                raise ValueError('unexpected archive root or directory entry')
            name = relative(info.filename[len(PREFIX):])
            if name in seen or set(PurePosixPath(name).parts) & FORBIDDEN:
                raise ValueError('duplicate/forbidden archive member')
            if stat.S_ISLNK(info.external_attr >> 16) or info.flag_bits & 1:
                raise ValueError('symlink/encrypted archive member')
            if info.file_size > 2_000_000:
                raise ValueError('oversized member')
            seen.add(name)
            expanded += info.file_size
        if expanded > 20_000_000:
            raise ValueError('oversized archive')
        if package.testzip() is not None:
            raise ValueError('ZIP CRC failure')
        manifest = json.loads(package.read(PREFIX+'PACKAGE_MANIFEST.json'))
        entries = set()
        for entry in manifest['files']:
            name = relative(entry['path'])
            if name in entries:
                raise ValueError('duplicate manifest path')
            entries.add(name)
            data = package.read(PREFIX+name)
            if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                raise ValueError('archive payload digest mismatch')
        if entries | {'PACKAGE_MANIFEST.json'} != seen:
            raise ValueError('archive/manifest inventory mismatch')
    return {'status': 'KIT_ARCHIVE_OK_NOT_PRODUCT_QA', 'sha256': digest, 'members': len(seen), 'compressed_bytes': archive.stat().st_size, 'uncompressed_bytes': expanded, 'external_checksum_checked': checksum_file is not None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--sha256-file', type=Path)
    args = parser.parse_args()
    checksum = args.sha256_file
    if checksum is None and Path(str(args.archive)+'.sha256').is_file():
        checksum = Path(str(args.archive)+'.sha256')
    try:
        print(json.dumps(check(args.archive, checksum), indent=2))
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print(json.dumps({'status': 'KIT_ARCHIVE_INVALID', 'error': str(error)}, indent=2))
        raise SystemExit(2)
