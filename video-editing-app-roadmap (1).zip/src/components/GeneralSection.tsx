"use client";

import type { GeneralImprovement } from "@/lib/roadmap-data";

interface GeneralSectionProps {
  improvements: GeneralImprovement[];
}

export default function GeneralSection({ improvements }: GeneralSectionProps) {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      {improvements.map((section) => (
        <div
          key={section.category}
          className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden"
        >
          <div className="p-5 border-b border-gray-800">
            <h3 className={`font-bold text-lg flex items-center gap-2 ${section.color}`}>
              <span>{section.icon}</span>
              {section.category}
            </h3>
          </div>
          <div className="p-5 space-y-4">
            {section.items.map((item) => (
              <div key={item.title} className="border-r-2 border-indigo-500/40 pr-4">
                <h4 className="font-semibold text-white text-sm mb-1">{item.title}</h4>
                <p className="text-gray-400 text-sm leading-relaxed mb-2">{item.desc}</p>
                {item.code && (
                  <pre className="code-block text-xs p-3 overflow-x-auto text-green-400 rounded-lg">
                    <code>{item.code}</code>
                  </pre>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
