import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { readFileSync } from 'node:fs';
import { selectMotionPolicy, decorativeDelay, receiptPresentation, KIT_MOTION } from '../.kit-build/motion-policy.js';
import { ImmediateAccessBoundary, NonSensitiveList, ReceiptStatusView } from '../.kit-build/StudioRecipes.js';

for (const preference of [true, null, undefined]) {
  for (const intent of ['panel', 'feedback', 'list', 'critical']) {
    test(`no motion for preference=${String(preference)} intent=${intent}`, () => {
      assert.deepEqual(selectMotionPolicy(preference, intent), { enabled: false, duration: 0, displacement: 0, layout: false });
    });
  }
}
test('critical has no retained or delayed motion even with full motion enabled', () => {
  assert.deepEqual(selectMotionPolicy(false, 'critical'), { enabled: false, duration: 0, displacement: 0, layout: false });
});
test('non-sensitive list uses position-only layout', () => {
  assert.equal(selectMotionPolicy(false, 'list').layout, 'position');
});
test('panel displacement is small and finite', () => {
  assert.equal(selectMotionPolicy(false, 'panel').displacement, 6);
});
test('feedback uses existing press timing', () => {
  assert.equal(selectMotionPolicy(false, 'feedback').duration, 0.12);
});
test('stagger is disabled unless explicitly opted in', () => {
  assert.equal(decorativeDelay(12, false), 0);
});
for (const index of [-10, -1, 0, 1, 4, 12, 1000000, NaN, Infinity]) {
  test(`bounded delay index=${String(index)}`, () => {
    const delay = decorativeDelay(index, false, true);
    assert.ok(delay >= 0 && delay <= 0.12);
  });
}
test('reduced and unknown preferences never stagger', () => {
  for (const pref of [true, null, undefined]) assert.equal(decorativeDelay(3, pref, true), 0);
});
for (const phase of ['not_sent','submitting','pending_review','approved','rejected','unknown','offline','untrusted']) {
  test(`receipt ${phase} has no blind retry or celebration`, () => {
    const p=receiptPresentation(phase);
    assert.equal(p.allowBlindRetry,false); assert.equal(p.celebrate,false);
    assert.ok(p.title.length>0 && p.detail.length>0);
  });
}
test('upload received is not payment approved', () => {
  const p=receiptPresentation('pending_review');
  assert.equal(p.tone,'warning'); assert.match(p.title,/بررسی انسانی/);
  assert.match(p.detail,/به معنی تأیید/);
});
test('unknown server state is not success', () => {
  for (const phase of ['unknown','untrusted','']) assert.equal(receiptPresentation(phase).tone,'warning');
});
for (const permitted of [false,null]) {
  test(`private child not rendered when permitted=${String(permitted)}`, () => {
    const out=renderToStaticMarkup(createElement(ImmediateAccessBoundary,{permitted},createElement('div',null,'PRIVATE_FIXTURE_ONLY')));
    assert.ok(!out.includes('PRIVATE_FIXTURE_ONLY'));
  });
}
test('explicit permission renders child; not a server authorization claim', () => {
  assert.match(renderToStaticMarkup(createElement(ImmediateAccessBoundary,{permitted:true},'VISIBLE_FIXTURE')),/VISIBLE_FIXTURE/);
});
test('receipt rendering gives a polite text status', () => {
  const out=renderToStaticMarkup(createElement(ReceiptStatusView,{phase:'pending_review'}));
  assert.match(out,/aria-live="polite"/); assert.match(out,/در انتظار بررسی انسانی/);
});
test('list SSR is visible without a zero-opacity entrance', () => {
  const out=renderToStaticMarkup(createElement(NonSensitiveList,{items:[{id:'a',label:'VISIBLE_LIST_FIXTURE'}]}));
  assert.match(out,/VISIBLE_LIST_FIXTURE/); assert.doesNotMatch(out,/opacity:0/);
});
test('empty list is explicit', () => {
  assert.match(renderToStaticMarkup(createElement(NonSensitiveList,{items:[]})),/موردی برای نمایش نیست/);
});
test('preview receipt fixtures exactly match the typed display policy', () => {
  const states=JSON.parse(readFileSync(new URL('../preview/receipt-states.json',import.meta.url),'utf8'));
  assert.deepEqual(Object.keys(states).sort(),['not_sent','submitting','pending_review','approved','rejected','unknown','offline'].sort());
  for (const [phase,view] of Object.entries(states)) assert.deepEqual(view,receiptPresentation(phase));
});
test('JSON and recipe timings have not diverged', () => {
  const t=JSON.parse(readFileSync(new URL('../TOKENS.json',import.meta.url),'utf8'));
  assert.equal(t.motion.durationMs.press,KIT_MOTION.press*1000);
  assert.equal(t.motion.durationMs.enter,KIT_MOTION.enter*1000);
  assert.equal(t.motion.durationMs.page,KIT_MOTION.page*1000);
  assert.equal(t.motion.staggerCapMs,KIT_MOTION.staggerCap*1000);
  assert.deepEqual(t.new_product_dependencies,[]);
});
